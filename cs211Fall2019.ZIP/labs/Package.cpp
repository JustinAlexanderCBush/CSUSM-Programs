#include<iostream>
#include"Package.h"
using namespace std;

Package::Package() // base/parent class default constructor to initialize and validate corresponding attributes
{
   senderName = ""; //sender information
   senderAddress = "";
   senderCity = ""; 
   senderState = ""; 
   senderZipCode = 00000;

   recipName = ""; //recipient information
   recipAddress = "";
   recipCity = ""; 
   recipState = ""; 
   recipZipCode = 00000;

   label = ""; //package label, date the package is shipped
   date = ""; 
   weight = 0.0;
   costPerOunce = 0.0; //package weight and standard shipping fee per ounce
   insuranceType = ""; //describes extra package insurance option
}

Package::Package(string sName, string sAddress, string sCity, string sState, long sZipCode, string rName, string rAddress, string rCity, string rState, long rZipCode, string pkgLabel, string pkgDate, double pkgWeight, double pkgCostPerOunce, string insType)
{
  senderName = sName;
  senderAddress = sAddress;
  senderCity = sCity;
  senderState = sState;
  senderZipCode = sZipCode;
  
  recipName = rName;
  recipAddress = rAddress;
  recipCity = rCity;
  recipState = rState;
  recipZipCode = rZipCode;
  
  label = pkgLabel;
  date = pkgDate;
  weight = pkgWeight;
  costPerOunce = pkgCostPerOunce;
  insuranceType = insType;  
}

double Package::calculateCost() //calculates and returns cost associated with shipping a certain package
{
  cost = (weight * costPerOunce) + insuranceType;
  return cost;
}

void Package::printPackage()
{
  cout << Package(string sName, string sAddress, string sCity, string sState, long sZipCode, string rName, string rAddress, string rCity, string rState, long rZipCode, string pkgLabel, string pkgDate, double pkgWeight, double pkgCostPerOunce, string insType) << endl;
}


