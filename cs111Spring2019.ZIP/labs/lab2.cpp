#include <iostream>
using namespace std;

int main()
{
  string name; //The name the user enters, when he/she is asked
  int n1, n2; //Two numbers the user will enter, when asked  
  cout << "Enter your name:" << endl;
  cin >> name;
  cout << "Hi " << name << endl;

  char ans;
  cout << "Is your major Computer Science? Enter 'Y' for yes, and 'N' for no. " << endl;
      cin >> ans;
      while(ans != 'Y' || ans!= 'N')
	{
	  switch(ans)
            {
            case 'Y': cout << "CS Major: " << ans << endl;
              break;
            case 'N': cout << "CS Major: " << ans << endl;;
              break;
            default: cout << "Invalid choice" << endl;
	      cin >> ans;	      
	    }
	}
      
      cout << "CS Major: " << ans << endl;	
      
      char mark; 
      cout << "Enter your favorite punctuation mark" << endl;
      cin >> mark;
      
      cout << "Enter two numbers" << endl;
      cin >> n1;
      cin >> n2;
      cout << (double)n1/n2 << endl;
      cout << n1/n2 << "r" << n1 % n2 << endl;
      
      return 0;
}
