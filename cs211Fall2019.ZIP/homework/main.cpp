/***********************************
HW#: 2
Name: Justin Bush
Date: 10/11/2019
Purpose of the program: To write a program that allows users to make dinner
reservations at restaurants. I'm using three classes: RestaurantReservations, Restaurant and Reservation. RestaurantReservations will use a vector, called restaurants, of type Restaurant. The Restaurant class will use a vector, called reservations, of type Reservation. 
 *********************************/
#include<iostream>
#include "Restaurant.h"
#include "Reservation.h"
#include "RestaurantReservations.h"
using namespace std;

int main()
{
  RestaurantReservations openTable;
  openTable.ProcessTransactionFile("TransactionFile.txt");


  return 0;
}
