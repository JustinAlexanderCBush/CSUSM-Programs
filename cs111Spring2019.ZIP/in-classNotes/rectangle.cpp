/**************************************
4/17/19
**************************************/
#include <iostream> 
#include "rectangle.h"
using namespace std;

rectangle:: ~rectangle()
  {
    cout << "Rectangle destructor called. " << endl;
  }

rectangle::rectangle(double initialWidth, double initialLength)
  {
    cout << "Called overloaded constructor of rectangle." << endl;
    setWidth(initialWidth); 
    setLength(initialLength);
  }

rectangle::rectangle() //default constructor
  {
    cout << "Called default constructor of rectangle. " << endl;
    width = 0;
    length = 0;
  }

void rectangle::setWidth(double passedWidth)
  {
    if(passedWidth >= 0)
      width = passedWidth;
    else
      cout << "Error. Width cannot be negative." << endl;
  }

void rectangle::setLength(double passedLength)
  {
    if(passedLength >= 0)
      length = passedLength;
    else
      cout << "Error. Length cannot be negative." << endl;
  }

double rectangle::getWidth()
  {
    return width;
  }

double rectangle::getLength()
  {
    return length;
  }

double rectangle::calcArea()
  {
    return length * width;
  }


