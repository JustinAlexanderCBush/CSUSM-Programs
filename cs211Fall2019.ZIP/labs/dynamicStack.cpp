/****************************** 
In this part, you are going to design a dynamic stack of characters implemented as a linked list. Complete the code below as specified by the comments below.
 ******************************/
#include<iostream>
using namespace std;

typedef char el_t;

class DynamicStack 
{
private:
  struct StackNode //if I didn't use this, I would have to make another class, for the stack node
  { 
    el_t element; // letter in the node
    StackNode *next; // Pointer to the next node
  };
  
  StackNode *top; // Pointer to the stack top

public:
  DynamicStack(); //default Constructor   
  ~DynamicStack(); //Destructor
 
  //other Stack operations
  void push(el_t elem);
  void pop(el_t &elem);
  void getTop(el_t &elem);
  bool isEmpty() const;
  void displayAll() const;
};

int main ()
{
  Stack s;
  el_t c;
  cout << " initial stack contents" << endl;
  s.displayAll();
  s.pop(c);
  s.push('a');
  cout << endl << " stack contents after pushing a: " << endl;
  s.displayAll();
  s.push('b');
  cout << endl << " stack contents after pushing b: " << endl;
  s.displayAll();
  s.push('c');
  s.push('d');
  s.push('e');
  s.push('f');
  s.push('g');
  cout << endl << " stack contents after pushing c-g: " << endl;
  s.displayAll();
  s.getTop(c);
  cout << endl << "top elment is " << c << endl;
  s.pop(c);
  cout << endl << c << endl;
  cout << endl << " stack contents after popping one element: " << endl;
  s.displayAll();
  s.pop(c);
  cout << endl << " popped element: " << c << endl;
  cout << endl << " stack contents after popping another element: " << endl;
  s.displayAll();
  s.pop(c);
  s.pop(c);
  if (!s.isEmpty())
    {
      s.getTop(c);
      cout << endl << "top elment is " << c << endl;
    }
  s.pop(c);
  cout << endl << " stack contents after popping 3 more elements: " << endl;
  s.displayAll();
  s.pop(c);
  s.pop(c);
  s.push('a');
  s.push('b');
  cout << endl << " final stack contents: " << endl;
  s.displayAll();
 
  return 0;
}

DynamicStack::DynamicStack() //default Constructor
{
  top = nullptr;
}

DynamicStack::~DynamicStack()
{
  if(top == NULL) //if the list is empty
      delete top; //deletes the currently top of the stack
  else
    {
      StackNode *nodePtr = top; //nodePtr points to the top of stack
      StackNode *nextNodePtr; //pointer to the next node
      while(nodePtr != NULL) //while the stack is not empty
	{
	  nextNodePtr = nodePtr->next;//points to the next stack value
	  delete nodePtr; //deletes was was the current nodePtr 
	  nodePtr = nextNodePtr; //nodePtr and nextNodePtr point to the same thing
	}
    }
}

void DynamicStack::push(el_t elem)
{
  StackNode *newNode; //*newNode points to a new node
  newNode = new StackNode; //allocate memory to a new StackNode

  //pass the parameter elem from this push func into the node
  newNode->element = elem; //store 
  newNode->next = top;
  top = newNode;
}

void DynamicStack::pop(el_t &elem)
{
  if(top == NULL) //if top of stack points to nullptr (if stack is empty)
    cout << "Cannot pop, stack is empty." << endl;
  else
    {
      element = top->elem;
      top = top->next;
    }
}

void DynamicStack::getTop(el_t &elem)
{
  elem = top->element;
}

bool DynamicStack::isEmpty() const
{
  if(top == NULL) //if stack is empty,
    return true;
  else
    return false;
}


void DynamicStack::displayAll() const
{
  StackNode *nodePtr; //to move through list
  nodePtr = top; //position nodePtr at the top of the stack
  
  if(nodePtr == nullptr)
    {

    }




  while(nodePtr) //while nodePtr points to a node, traverse the list
    {
      cout << nodePtr->element << endl; //display pho\ne numbers in this node
  nodePtr = nodePtr->next; //move to next node
    }
}


