#include<iostream>
#include<string>
#include<vector>
using namespace std;

void selSort(vector <string>& v); //sorts the vector using selection sort 
void display(const vector <string>& v); //displays the vector contents
int binSearch(const vector <string>& v, string key); //searches the vector for a key, returns the index of the key if found and -1 if the index is not found

int main()
{
  string k; //key for binary search
  vector<string> names {"Joe Garcia", "Amelia Perez", "Bob Haynes", "Tim Ducrest", "Kevin Garcia", "Suzy Walter", "Fang Yi", "Robert James", "Mary Andres"};

  display(names); //call the func display to print the vector contents
  selSort(names); //call the selSort func to sort the vector in ascending order
  display(names); //call the func display to print the sorted vector contents
  binSearch(names, k); //call the binSearch func to search for "Kevin Garcia"
  binSearch(names, k); //call the binSearch func to search for "Joe James"

  return 0;
}

void selSort(vector<string>& v)
{
  int temp; //temporary variable that holds largest value

  for(int i = 0; i < v.size(); i++)
    {
      int min = i;
      for(int j = 1; j < v.size(); j++)
	{
	  if(v[j] < v[min])
	    min = j;
	}
      temp = v[i];
      v[i] = v[min];
      v[min] = temp;
    }

}

void display(const vector<string>& v)
{
  int temp;

  for(int i = 0; i < v.size(); i++)
    {
      cout << v[i] << endl;
      v.push_back(temp);
    }
}
/*
int binSearch(const vector <string>& v, string key)
{

}
*/
