#ifndef OVERNIGHTPACKAGE_H
#define OVERNIGHTPACKAGE_H
#include"Package.h"
using namespace std;

class OvernightPackage: public Package //derived class
{
 protected:
  double overnightFee;
  
 public:
  OvernightPackage(); //default constructor to ensureweight, cost and fees are positive values
  overnightFee(double overnightFee); //represents an additional fee per ounce charged for overnight-delivery service
  calculateCost(); //returns cost associated with shipping a certain package
  //setters and getters as needed
  printOverNightPackage(); //prints package's attributes(specialized and inherited), and its shipping cost
};

#endif

