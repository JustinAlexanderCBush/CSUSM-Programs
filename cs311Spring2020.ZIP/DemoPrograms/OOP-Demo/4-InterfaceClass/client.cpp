// CS311 Yoshii - testing the girl class that inherited from Ipure 
// -----------------------------------------------------------
#include"girl.h"

int main()
{
  girl Mary;
  Mary.doit();
}
