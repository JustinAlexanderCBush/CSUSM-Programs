/********************************************************************************
Justin Bush 
CS 111
3/4/19
Have the user input a filename to read in integers from.  Print each to the screen, one per line and keep a running total.  Print the total at the end.  If the file does not exist say so and do not print the total.
Test Case 1:
File contents (ask user to enter filename, the file they enter contains this):
2 4 6 8 10
Test Case 2:
File contents (ask user to enter filename, the file they enter contains this):
1
3
5
7
9
Test Case 3:
(nonexistent file – user enters nonexistent filename)
Sample output:
Failed to open file.
********************************************************************************/
#include <iostream>
#include <fstream>
using namespace std;

int main()
{
  int integer = 0; //Integers the file will already contain; acts as a counter for the total
  int total = 0; //The added total of all the integers
  string filename;
 
  cout << "Open the filename 'lab14.txt' " << endl;
   
  ifstream fin;
  fin.open("lab14.txt");
 
  cin >> filename;

  if(!fin) //if(fin == NULL) meaning, that the file doesn't exist
      cout << "Failed to open file." << endl;
  else //The input file exists
    {
      while(fin >> integer) //while-loop, b/c there could be a lot of inputs of integers from the user
	{
	  cout << "Read " << integer << " from file." << endl;
	  total += integer; //total = total * integer
 	}
      cout << "Total is " << total << endl;
    }
  
  fin.close();
  

  return 0;
}
