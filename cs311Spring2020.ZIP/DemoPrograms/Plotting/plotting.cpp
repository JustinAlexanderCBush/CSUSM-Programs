#include<iostream>
#include<fstream>
using namespace std;
#include<vector>

int const MAX = 5;  // easily changeable to increase # of sections
vector<int> M[MAX][MAX]; // the table 



void initializeTable()  // to all 0s
{
 for (int r = 0; r <MAX; r++)
   {
     for (int c = 0; c < MAX; c++)
       for (int i = 0; i < MAX; i++) 
           M[r][c]. push_back(0);
   }
}

void displayVector(vector<int> V) // within a table slot
{
    for (int i = 0; i < MAX; i++)
      cout << V[i]<< " ";
    cout << "|";
}

void displayTable() // X is row and Y is column
{ cout << "x/y";
  for (int c = 0; c < MAX; c++)  // display column numbers
    cout << "    " << c+1 << "      ";
  cout << endl;    
  for (int r = 0; r < MAX; r++)  // one row at a time
    { cout << r+1 << ":";
      for (int c = 0; c < MAX; c++)
	displayVector(M[r][c]);
      cout << endl;
    }
}

void analyzeTable(int cutoff)
{
  cout << "Trying to find clusters based on all 3..." << endl;
  bool flag = false;
  for (int r = 0; r <MAX; r++)
    for (int c = 0; c < MAX; c++)
      for (int i = 0; i < MAX; i++) 
	{ if ( M[r][c][i] > cutoff ) 
	    { cout << "Cluster at x = " << r+1 << " y = " << c+1 << " z = " << i+1 << endl; flag = true; }      
	}
  if (flag == false) cout << "None found" << endl;

  cout << "Trying to find clusters based on x and y ..."  << endl;
  flag = false;
  for (int r = 0; r <MAX; r++)
    for (int c = 0; c < MAX; c++)
      { int sum = 0;
	for (int i = 0; i < MAX; i++) 
	  { sum = M[r][c][i] + sum; }
	if (sum > cutoff)  
	  { cout << "Cluster at x = " << r+1 << " y = " << c+1 << endl; 
	    flag = true;}
      }
  if (flag == false) cout << "None found" << endl;

  cout << "Trying to find clusters based on x and z..." << endl;
  flag = false;
  for (int r = 0; r <MAX; r++)
    for (int i = 0; i < MAX; i++)
      { int sum = 0;
	for (int c = 0; c < MAX; c++) 
	  { sum = M[r][c][i] + sum; }
	if (sum > cutoff)  
	  { cout << "Cluster at x = " << r+1 << " z = " << i+1 << endl; 
	    flag = true;}
      }
  if (flag == false) cout << "None found" << endl;
  
  cout << "Trying to find clusters based on y and z..." << endl;
  flag = false;
  for (int c = 0; c <MAX; c++)
    for (int i = 0; i < MAX; i++)
      { int sum = 0;
	for (int r = 0; r < MAX; r++) 
	  { sum = M[r][c][i] + sum; }
	if (sum > cutoff)  
	  { cout << "Cluster at y = " << c+1 << " z = " << i+1 << endl; 
	    flag = true;}
      }
  if (flag == false) cout << "None found" << endl;
}

int main()
{
 int population;
 int cutoff;
 cout << "This program will find clusters on a 3 dimensional graph." << endl;
 cout << "Each dimension is divided into " << MAX <<  " sections." << endl; 
 cout << "Data will be read from your input file which already has points" << endl;
 cout << "in terms of the sections." << endl;
 cout << "----------------------------------------------------------------" << endl; 


 initializeTable(); // to all 0s
 displayTable();   

 int x, y, z;
 string xn, yn, zn;

string fname;
cout << "Enter the input file name: ";
cin >> fname;

ifstream fin (fname.c_str(), ios::in); // declare and open 

 fin >> xn; fin >> yn; fin >> zn;

 cout << "Enter population size: " ; cin >> population;
 cout << "Filling the table..." << endl;
 for (int i = 1; i <= population; i ++)
   { 
     fin >> x;
     fin >> y;
     fin >> z;
     ((M[x-1][y-1])[z-1])++;
   }
 fin.close();

 displayTable();
 cout << "Your x-y-z dimensions are: " << xn << " and " << yn << " and " << zn << endl;
 cout << endl;
 cout << "Enter cluster (i.e. >) cutoff size: "; cin >> cutoff;
 analyzeTable(cutoff);

}
