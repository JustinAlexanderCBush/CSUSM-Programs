/************************************

 **********************************/
#include<iostream>
#include<vector>
#include<fstream>
#include<iomanip>
#include"Restaurant.h"
#include"Reservation.h"
#include"RestaurantReservations.h"
using namespace std;


RestaurantReservations::RestaurantReservations() //default constructor 
{

}

void RestaurantReservations::ProcessTransactionFile(string fileName)
{
  string command; //the command the user will 
  string restName, restAddress, restCity, restType;
  int restSeats[4], restCapacity;
  string contName, contPhone; //contact names and phone number
  int groupSize, reserveTime;
  //  vector<Restaurant> restaurants;  //declare vector of class restaurant

  ifstream fin; //ifstream object to read in the file
  fin.open(fileName); //open the file
  if(!fin) //if the file doesn't exist
    cout << "Error. The file doesn't exist." << endl;
  else //the file was readable
    {
      while(fin >> command) //while the file can read in commands
	{
	  if(command == "CreateNewRestaurant")
	    {
	      fin >> restName >> restAddress >> restCity >> restType >> restCapacity; //reads in attributes
	      CreateNewRestaurant(restName, restAddress, restCity, restType, restCapacity); //calls CreateNewRestaurant
	    }
	  else if(command == "PrintAllRestaurants")
	    {
	      PrintAllRestaurants();//calls PrintAllRestaurants
	    }
	  else if(command == "FindTable")
	    {
	      fin >> restCity >> restType >> groupSize >> reserveTime; //reads data from the file
	      FindTable(restCity, restType, groupSize, reserveTime); //calls FindTable function
	    }
	  else if(command == "MakeReservation")
	    {
	      fin >> restName >> contName >> contPhone >> groupSize >> reserveTime; //reads in attribues
	      MakeReservation(restName, contName, contPhone, groupSize, reserveTime); //calls MakeReservation function
	    }
	  else if(command == "FindTableAtRestaurant")
	    {
	      fin >> restName >> groupSize; //reads in attributes
	      FindTableAtRestaurant(restName, groupSize); //calls FindTableAtRestaurant
	    }
	  else//(command == "PrintRestaurantReservations)
	    {
	      fin >> restName; //fill atribute
	      PrintRestaurantReservations(restName); //calls PrintRestaurantReservations function
	    }
	}
    }

  fin.close(); //closes input file
}

/*****************************************************
This function uses the overloaded constructor from the Restaurant class to push back parameters passed in CreateNewRestaurant.
 ****************************************************/
void RestaurantReservations::CreateNewRestaurant(string rName, string rAddress, string rCity, string rType, int rCapacity)
{
  //call the overloaded constructor for the Restaurant class
  Restaurant temp(rName, rAddress, rCity, rType, rCapacity);   
  restaurants.push_back(temp); //add space in the restaurants vector
}

/****************************************************
This function prints all restaurants, using the restaurants vector, to access private member variables of the Restaurant class. 
*****************************************************/
void RestaurantReservations::PrintAllRestaurants() const
{
  cout << left << setw(20) << "Restaurant";
  cout << setw(20) << "Address";
  cout << setw(15) << "City";
  cout << setw(15) << "Type";
  cout << setw(15) << "Capacity" << endl;
  cout << "--------------------------------------------------------------------------------" << endl;

  //call printRestaurantInfo function from Restaurant.cpp
  for(int i = 0; i < restaurants.size(); i++)
    {
      restaurants[i].printRestaurantInfo();
    }
}


/****************************************************
This function searches for all restaurants to find a specific table.
 ***************************************************/
void RestaurantReservations::FindTable(string rCity, string rType, int rGroup, int rTime)
{
  bool tableIsAvailable = false;

  for(int i = 0; i < restaurants.size(); i++)
    {
      if(restaurants[i].getCity() == rCity)//if the city matches the city in the file
	{
	  if(restaurants[i].getType() == rType)//if the type of restaurant matches the type of restaurant in the file
	    {
	      if(restaurants[i].getSeats(rTime - 5)  >= rGroup) //if the number of available seats at a specific time is greater than or equal to the size of the group
		{
		  if(tableIsAvailable == false)
		    {
		  cout << "You may reserve a table for " << rGroup << " at " << rTime << "pm at: " << endl;
		    }
		  cout << restaurants[i].getName() << endl; //print the name of the restaurant
		  tableIsAvailable = true;
		}
	    } 
	}
      if(tableIsAvailable == false)
	cout << "No restaurant can accomodate such a group at this time, check another time" << endl;	  
    }	  
}


/***********************************************
This function searches for all restaurants in a specific city, rCity, of a specific type, rType, and having at a specific time, rTime, enough seats for a given group of people, rGroup. If such restaurants are found, the function prints the names of all such restaurants.
***********************************************/
void RestaurantReservations::FindTableAtRestaurant(string rName, int rGroup)
{
  bool tableAtRest = false;
  for(int i = 0; i < restaurants.size(); i++)//searches through the restaurants vector for the name of the restaurant and the size of the group
    {
      if(rName == restaurants[i].getName())
	{
	  for(int j = 0; j < 4; j++)
	    {
	      if(rGroup <= restaurants[i].getSeats(j))
		{
		  if(tableAtRest == false)
		    {
		  cout << "You can reserve a table for " << rGroup << " at " << rName << " at " << j+5 << ":00 pm." << endl;
		    }
		  tableAtRest = true;
		}
	    } 
	}
    }
  
  if(tableAtRest == false)
    cout << rName << " does not have such availablity." << endl;
}

/***********************************************
This function makes a reservation, given that the restaurant name, the contact name, the contact phone number, the size of the group and the time of the reservation match
 *********************************************/
void RestaurantReservations::MakeReservation(string rName, string cName, string cPhone, int rGroup, int rTime)
{
  //call ReservationInfo func from Restaurant.cpp
  Restaurant temp;
  for(int i = 0; i < restaurants.size(); i++)
    {
      if(rName == restaurants[i].getName())
	{
	  if(restaurants[i].getSeats(rTime - 5)  >= rGroup)
	    restaurants[i].ReservationInfo(cName, cPhone, rGroup, rTime);
	}
    }

}

/**************************************************************
This function prints all of the reservations for the restaurants that were read from the CreateNewRestaurant function. If a restaurant doesn't exist, it will print an error message.
 *************************************************************/
void RestaurantReservations::PrintRestaurantReservations(string rName)
{
  bool flag = false;
  for(int i = 0 ; i < restaurants.size(); i++)
    {
      if(rName == restaurants[i].getName())
      {
	restaurants[i].printReservation();
	flag = true;
      }
    }
  if(flag == false)
    {
      cout << " Error " << rName << " does not exist " << endl;
    }
}
