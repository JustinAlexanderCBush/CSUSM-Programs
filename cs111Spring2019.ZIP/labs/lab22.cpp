/*******************************************************************************
Justin Bush 
CS 111 Castillo
4/8/19
Create a program that defines a struct for a student. The following data should be part of the struct: studentID (int), gpa(double), fullName(string), units(int).Instantiate two students and have the user type in information for each, then print both back to the screen afterwards. Input validation: studentID should be positive and have 4 digits, GPA should be between 0 and 4 (inclusive), units should be positive. Have any invalid inputs reentered.

Show a test case or cases of your own design proving input validation for each case mentioned above and showing different values being stored for the two students.
********************************************************************************/
#include <iostream>
using namespace std;

struct student
{
  int ID;
  double gpa;
  string fullName;
  int units;
};

int main()
{
  student stu1, stu2;

  cout << "Enter two students' ID numbers, GPA, full names and units" << endl;
  cout << "Student 1's information: " << endl;
  cout << "ID: ";
  cin >> stu1.ID;
  while(stu1.ID < 1000 || stu1.ID > 9999)
    {
      cout << "The maximum number of digits his/her ID can be is only four. Enter the ID again." << endl; 
      cout << "ID: ";
      cin >> stu1.ID;
    }

  cout << "GPA: ";
  cin >> stu1.gpa;
  while(stu1.gpa < 0 || stu1.gpa >= 4.0)
    {
      cout << "The GPA must be between 0 and 4 inclusive. Enter their GPA again." << endl;
      cout << "GPA: ";
      cin >> stu1.gpa;
    }
	  
  cout << "Full name: ";
  cin.ignore(1000, '\n');
  getline(cin, stu1.fullName);

  cout << "Units: ";
  cin >> stu1.units;
  while(stu1.units < 0)
    {
      cout << "The student's units must be positive. Enter his/her units again." << endl;
      cout << "Units: ";
      cin >> stu1.units;
    }
  cout << endl;
  

  cout << "Student 2's information: " << endl;
  cout << "ID: ";
  cin >> stu2.ID;
  while(stu2.ID < 1000 || stu2.ID > 9999)
    {
      cout << "The maximum number of digits their ID can be is only four. Enter the ID again." << endl;
      cout << "ID: ";
      cin >> stu2.ID;
    }
  
  cout << "GPA: ";
  cin >> stu2.gpa;
  while(stu2.gpa < 0 || stu2.gpa >= 4.0);
  {
    cout << "The GPA must be between 0 and 4 inclusive. Enter their GPA again. " << endl;
    cout << "GPA: ";
    cin >> stu2.gpa;
  }

  cout << "Full name: ";
  cin.ignore(1000, '\n');
  getline(cin, stu2.fullName);
  
  cout << "Units: ";
  cin >> stu2.units;
  while(stu2.units < 0)
    {
      cout << "The student's units must be positive. Enter their units again." << endl;
      cout << "Units: ";
      cin >> stu2.units;
    }

  cout << "\nStudent 1's information" << endl;
  cout << "ID: " << stu1.ID << endl;
  cout << "GPA: " << stu1.gpa << endl;
  cout << "Full name: " << stu1.fullName << endl;
  cout << "Units: " << stu1.units << endl;

  cout << "Student 2's information" << endl;
  cout << "ID: " << stu2.ID << endl;
  cout << "GPA: " << stu2.gpa << endl;
  cout << "Full name: " << stu2.fullName << endl;
  cout << "Units: " << stu2.units << endl; 
  
  return 0;
}
