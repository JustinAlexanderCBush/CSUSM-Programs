//CS311 Yoshii dgraph.cpp 
// INSTRUCTION:
//  Complete all the functions you listed in dgraph.h
//  Comment the file completely using How to Comment file.
//  Use HW6-help.docx to finish the functions.
//-------------------------------------------------------

//======================================================
// HW#: HW6 dgraph
// Name: Justin Bush
// File Type: implementation .cpp
//========================================================

using namespace std;
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include "dgraph.h"

//Purpose: constructor
//Parameters: None
dgraph::dgraph() 
{
  // initialize vertexName (blank) and visit numbers (0)    
  // initialize countUsed to be 0
  cout << "In constructor" << endl;
  for(int i = 0; i < SIZE; i++)
    {
      Gtable[i].vertexName = ' ';
      Gtable[i].outDegree = 0;
      Gtable[i].visit = 0;
    }
  countUsed = 0;
}

//Purpose: destructor
//Parameters: None
dgraph::~dgraph()   // do we have to delete all nodes of slists in table??
// Question: If we do not do this, will the llist destructor be called automatically??? Try it.
{
  cout << "In destructor" << endl;
}

//Purpose: To read information from file and adds the data to the graph
//Parameters: None
void dgraph::fillTable()  // be sure to read from a specified file
{
  string fname;
  cout << "Enter a file name: ";
  cin >> fname;
  char x; 
  ifstream fin (fname.c_str(), ios::in); // declare and open fname
  // the rest is in HW6-help
  while(fin >> Gtable[countUsed].vertexName)
    {
      fin >> Gtable[countUsed].outDegree;
      for(int i = 0; i < Gtable[countUsed].outDegree; i++)
	{
	  fin >> x;
	  (Gtable[countUsed].adjacentOnes).addRear(x);
	}
      countUsed++;
    }
  fin.close();

}

//Purpose: To display the graph with the information read from table.txt
//Parameters: None
void dgraph::displayGraph() // be sure to display
{// in a really nice table format -- all columns but no unused rows 
  int edges = 0;
  cout << "\n" << left << "Vertex\tOut\t\t Visit\t Adj\n";
  cout << "---------------------------------------------" << endl;
  for(int i = 0; i < countUsed; i++)
    {
      edges += Gtable[i].outDegree;
      cout << Gtable[i].vertexName << "\t";
      cout << Gtable[i].outDegree << "\t\t";
      cout << Gtable[i].visit << "\t";
      (Gtable[i].adjacentOnes).displayAll();
    }
  cout << "** The number of edges is: " << edges << endl;
}

//Purpose: Returns the out degree of the vertex
//Parameters: The name (letter) of the vertex that the user enters
int dgraph::findOutDegree(char V)// throws exception
{// does not use a loop
  V = V - 'A';
  (int)V;
  if(V >= 0 && V < countUsed)
    return (Gtable[V].outDegree);
  else
    throw BadVertex();
}

//Purpose: Returns the linked list of the adjacent vertices of the vertex
//Parameters: The name (letter) of the vertex that the user enters
slist dgraph::findAdjacency(char V)// throws exception
{// does not use a loop
  V = V - 'A';
  (int)V;
  if(V >= 0 && V < countUsed)
    return (Gtable[V].adjacentOnes);
  else
    throw BadVertex();
}
