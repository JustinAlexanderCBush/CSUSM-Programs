#include <iostream>
using namespace std;

class Sprite
{
private:
  string name;
  int x, y;
  int* p; //This variable p, is a pointer. 

public:
  Sprite(string s, int a, int b); //default constructor
  ~Sprite(); //deconstructor

  void print()
  {
    cout << name << " @ (" << x << "," << y << ")\n";
  }

};


Sprite::Sprite(string s, int a , int b)
{
  name = s;
  x = a;
  y = b;
  p = new int;
  *p = 0;
}


Sprite::~Sprite()
{
  cout << "deconstructor ~Sprite\n";
  delete p; //
}


int main()
{
  Sprite s("John", 2, 3);
  s.print();

  return 0;
}

