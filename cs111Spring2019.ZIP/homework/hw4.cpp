/********************************************************************************
Justin Bush
CS 111 Castillo
5/1/19
.cpp file for Homework 4
********************************************************************************/
#include <iostream>
#include "hw4.h"
using namespace std;

void box::setLength(double passedLength)
{
  if(passedLength >= 0)
    length = passedLength;
  else
    cout << "Error. Length cannot be negative." << endl;
}
double box::getLength()
{
  return length;
}


void box::setWidth(double passedWidth)
{
  if(passedWidth >= 0)
    width = passedWidth;
  else 
    cout << "Error. Width cannot be negative." << endl;
}
double box::getWidth()
{
  return width;
}


void box::setHeight(double passedHeight)
{
  if(passedHeight >= 0)
    height = passedHeight;
}
double box::getHeight()
{
  return height;
}


void box::setWeight(double passedWeight)
{
  if(passedWeight >= 0)
    weight = passedWeight;
}
double box::getWeight()
{
  return weight; 
}


void box::setAddress(string passedAddress)
{
  address = passedAddress;
}
string box::getAddress()
{
  return address;
}


void box::setCity(string passedCity)
{
  city = passedCity;
}

string box::getCity()
{
  return city;
}

void box::setState(string passedState)
{
  if(passedState.length() == 2)
    state = passedState;
}
string box::getState()
{
  return state;
}


void box::setZipCode(int passedZipCode)
{
  if(passedZipCode <= 99999)
    zipCode = passedZipCode;
}
int box::getZipCode()
{
  return zipCode;
}


double box::calcShippingPrice()
{
  double cost;
  cost = (((length + width + height) * 0.05) + (weight * 1.00));
  return cost;
}

void box::print() 
{
  cout << "Length: " << length << endl;
  cout << "Width: " << width << endl;;
  cout << "Height: " << height << endl;
  cout << "Address: " << address << endl;
  cout << "City: " << city << endl;
  cout << "State: " << state << endl;
  cout << "Zip code: " << zipCode << endl;
  cout << "Price: $" << calcShippingPrice();
}

box::box() //default parameter with no parameters
{
  cout << "Called default constructor of the class box. Width, length, height, weight, address, city, state and zip code will be set to their default values, if applicable." << endl << endl;
  length = 0;
  width = 0;
  height = 0;
  weight = 0;
  address = "";
  city = "";
  state = "XX";
  zipCode = 0;
}

box::box(double initialLength, double initialWidth, double initialHeight, double initialWeight, string initialAddress, string initialCity, string initialState, int initialZipCode) //overloaded constructor
 {
  cout << "Called overloaded constructor of box.";
  length = initialLength;
  width = initialWidth;
  height = initialHeight;
  weight = initialWeight;
  address = initialAddress;
  city = initialCity;
  state = initialState;
  zipCode = initialZipCode;  
}


