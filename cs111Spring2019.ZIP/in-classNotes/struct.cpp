#include <iostream>
using namespace std;

struct Student //structure tag
{
  string name; //structure member
  int units;   //another structure memeber
}; //need semicolon after the closing }

int main()
{
  Student myClass[45];
  

  Student abc, def;

  abc.name = "Joe"; //dot operator is used to access members of the structure
  abc.units = 15;

  def.name = "Mary";
  def.units = 16;

  cout << abc.name << " is taking " << abc.units << " units" << endl;
  cout << def.name << " is taking " << def.units << " units" << endl;

  return 0;
}
