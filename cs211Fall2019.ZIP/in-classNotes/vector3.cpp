#include <vector>
#include <iostream>
#include <iomanip>
using namespace std;


int main()
{
  vector<int> v(10);
  //for(int i = 0; i < v.size(); i+=10)
  v[0] = 0;
  v[1] = 10;
  v[2] = 20;
  v[3] = 30;
  v[4] = 40;
  v[5] = 50;
  v[6] = 60;
  v[7] = 70;
  v[8] = 80;
  v[9] = 90;

  int x = 0;

  cout << "front value: " << v.front() << endl;
  cout << "-----------------------------------------" << endl;
  cout << "back value: " << v.back() << endl;
  cout << "-----------------------------------------" << endl;

  cout << "insert 400 into index 1: " << endl;
  v.insert(v.begin()+1, 400);
  for (int i=0;i<v.size();i++)
    cout << setw(7) << v[i];
  cout << endl;
  cout << "-----------------------------------------" << endl;

  cout << "erase the value in index 2: " << endl;
  v.erase(v.begin()+2);
  for (int i=0;i<v.size();i++)
    cout << setw(7) << v[i];
  cout << endl;
  cout << "-----------------------------------------" << endl;

  cout << "erase from index 2 to index 7 but not including 7: " << endl;
  v.erase(v.begin()+2, v.begin()+7);
  for (int i=0;i<v.size();i++)
    cout << setw(7) << v[i];
  cout << endl;
  cout << "-----------------------------------------" << endl;
}
