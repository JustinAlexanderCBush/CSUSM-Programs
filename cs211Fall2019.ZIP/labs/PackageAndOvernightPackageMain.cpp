#include<iostream>
#include"Package.h"
#include"OvernightPackage.h"
using namespace std;

int main()
{
  string senderName, senderAddress, senderCity, senderState;
  long senderZipCode;
  string recipName, recipAddress, recipCity, recipState; 
  long recipZipCode;
  string label, date;
  double weight, costPerOunce;
  string insuranceType;

  Package p1("AmyJohnson", "3465RegentsRd", "SanDiego", "CA", 92130, "EdwardJohnes", "439NWGreens", "Fayetteville", "NY", 13066, "HG9983", "06/03/2016", 10, 0.7,
"upto1000");
  p1.calculateCost();
  p1.printPackage();

  return 0;
}
