/*************************
Justin Bush
*************************/
#include<iostream>
#include"Student.h"
using namespace std;

//friend void setTuition(Student& )

int main()
{
  string stuName, stuMajor, stuClassification;
  int stuUnits;
  float stuTuition;
  
  Student s1;
  s1.print();


  Student s2(stuName, stuMajor, stuClassification, stuUnits);
  s2.setData();
  s2.print();

  return 0;
}
