#include <iostream>
using namespace std;

// Overloading : using stand alone c-function 
class ComplexNumber; //forward class declaration for ComplexNumber class
ComplexNumber operator+(const ComplexNumber&, const ComplexNumber&);

//---------------------------------------
class ComplexNumber
{
  friend ComplexNumber operator+(const ComplexNumber&, const ComplexNumber&);

private:
  float   RealPortion;
  float   ImagePortion;

public:
  ComplexNumber();
  ComplexNumber(float, float);
  float GetRealPortion()  
  {
    return(RealPortion);
  }
  float GetImagePortion() {return(ImagePortion);}
  ComplexNumber add(ComplexNumber&, ComplexNumber&);
};

//---------------------------------------
ComplexNumber::ComplexNumber()
{
  RealPortion  = 0;
  ImagePortion = 0;
}
//---------------------------------------
ComplexNumber::ComplexNumber(float r, float i)
{
  RealPortion  = r;
  ImagePortion = i;
}

//---------------------------------------
ComplexNumber ComplexNumber::add( ComplexNumber& n1, ComplexNumber& n2)
{
  ComplexNumbertmp;
  tmp.RealPortion = n1.RealPortion + n2.RealPortion;
  tmp.ImagePortion= n1.ImagePortion + n2.ImagePortion;

  return tmp;
}

//---------------------------------------
ComplexNumber operator+(const ComplexNumber& n1, const ComplexNumber& n2)
{
  ComplexNumber tmp;
  tmp.RealPortion  = n1.RealPortion + n2.RealPortion;
  tmp.ImagePortion = n1.ImagePortion + n2.ImagePortion;

  return tmp;
}


//---------------------------------------

void main()
{
  ComplexNumbern1(1,0);         
  ComplexNumbern2(1,1);
  ComplexNumbern3;
  n3 = n1 + n2;// with operator overloading

  cout << "real  part of n3 is " << n3.GetRealPortion() << endl;
  cout << "image part of n3 is " << n3.GetImagePortion() << endl;


  //ComplexNumbertmp;
  //tmp.add(n1, n2); // without operator overloading
}


