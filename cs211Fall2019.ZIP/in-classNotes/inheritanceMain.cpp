#include<iostream>
#include<string>
#include "inheritanceBaseClass.h"
#include "inheritanceDeriedClass.h"
using namespace std;

int main()
{
  //note that if name is a private memeber and not a protected member,
  // the following statement is a compile error

  Employee e("Jim", 4);
  e.print();

  return 0;
}

//THIS IS THE inheritance Main file, and these two funcs were written here ORIGINALLY. IS THIS STILL CORRECT, or 
//is it more efficient to add these two funcs to the inheritanceDerivedClass.cpp file. which is what I did??????

//-------------------------------------------------
Employee::Employee(string theName, int num)
{
  name = theName;// uses parent member
  number = num;
}
//-------------------------------------------------
void Employee::print()
{
  cout << "Employee name is:\t" << name << endl;
  cout << "Emplyee id is:   \t" << number << endl;// uses parent member
}
//-------------------------------------------------




