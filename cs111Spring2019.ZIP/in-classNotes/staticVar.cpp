#include <iostream>
using namespace std;

void printGreeting();

int main()
{
  for(int i = 0; i < 10; i++)
      printGreeting();

  return 0;
}

void printGreeting()
{
  static int numCalls = 0; //This line is ONLY CALLED ONCE    AFTER THE FIRST CALL, I CAN IGNORE THIS STATIC VARIABLE
  numCalls++; //numCalls stays the same value as it was the previous utilization
  cout << "Hello world! - printGreeting has been called " << numCalls << " time(s)." << endl;
}
