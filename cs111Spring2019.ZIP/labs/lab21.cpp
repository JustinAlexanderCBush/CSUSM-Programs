/********************************************************************************
Justin Bush
CS 111 Castillo
4/8/19
Create a function that accepts four double values as parameters.  These four double values should NOT modify the related values in main.  The function should return the minimum of the four values, maximum of the four values, and average of the four values.  Hint: Remember pass-by-reference to return multiple values – your function should have seven parameters and a return type of void.
In main, ask the user to enter the four values, and then print the minimum, maximum and average.  Your function should NOT print anything or read in anything (no cin/cout), only main.
********************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

void findMinMaxAvg(int n1, int n2, int n3, int n4, int& min, int& max, double& avg); 

int main()
{
  int num1, num2, num3, num4, minimum, maximum;
  double average;
  
  cout << "Please enter four numbers:" << endl;
  cout << "Number 1: ";
  cin >> num1;
  cout << "Number 2: ";
  cin >> num2;
  cout << "Number 3: ";
  cin >> num3;
  cout << "Number 4: ";
  cin >> num4;

  findMinMaxAvg(num1, num2, num3, num4, minimum, maximum, average);
  cout << "\nMinimum is " << minimum << endl; 
  cout << "Maximum is " << maximum;
  cout << "\nAverage is " << average << endl;
   
  return 0;
}

void findMinMaxAvg(int n1, int n2, int n3, int n4, int& min, int& max, double& avg)
{
  //finds the minimum
  if(n1 < n2) //compares the first two numbers
    min = n1;
  else if(n2 < n1)
    min = n2;
  
  if(n3 < min) 
    min = n3;
  if(n4 < min) //This must be an if-statement b/c it also checks if the fourth number can be the minimum
    min = n4;

 
  //finds the maximum
  if(n1 > n2) //compares the first two numbers
    max = n1;
  else if(n2 > n1)
    max = n2;
  
  if(n3 > max) 
    max = n3;
  if(n4 > max)//This must be an if-statment b/c it also checks if the fourth number can be the maximum
    max = n4;

  avg = (double)(n1 + n2 + n3 + n4)/4;
}
