/**************************************
4/10/19
**************************************/
#include <iostream>
using namespace std;

class rectangle
{
private: //*******THINK PRIVATE VARIABLES, AND PUBLIC FUNCTIONS
  int width = 0, length = 0;
  
public:
  void setWidth(int passedWidth)
  {
    if(passedWidth >= 0)
      width = passedWidth;
    else
      cout << "Error. Width cannot be negative." << endl;
  }

  void setLength(int passedLength)
  {
    if(passedLength >= 0)
      length = passedLength;
    else
      cout << "Error. Length cannot be negative." << endl;
  }

  int getWidth()
  {
    return width;
  }

  int getLength()
  {
    return length;
  }

  int calcArea()
  {
    return length * width;
  }
};

int main()
{
  rectangle r1;
  r1.setWidth(3);
  r1.setLength(4);

  cout << "rectangle1 has a width of " << r1.getWidth() << " and a length of " <<   r1.getLength() << ". Its area is " << r1.calcArea() << "." << endl; 


  return 0;
}
