 /********************************************************************
Justin Bush

****************************************************************/
#ifndef INSTRUCTOR_H
#define INSTRUCTOR_H
#include<iostream>
#include "Course.h"
using namespace std;

class Instructor
{
 private:
  string firstName, lastName;
  char gender; //'M' for male and 'F' for female
  long employeeID;
  string officeNum;
  Course studentCourses[3];

 public:
  Instructor();
  Instructor(string fName, string lName, char gen, long empID, string offNum, Course courses[]); 
  void setInstructor(string fName, string lName, char gen, long empID, string offNum, Course courses[]);
  void printInstructor();
};

#endif
