/*******************************************************************************
Justin Bush
CS 111 Lanier Castro 
Lab 3 
Ask the user to enter the names of three items and their prices, and the tax rate as a decimal.  After they enter this information calculate the subtotal, tax, and total, and print out a receipt as formatted below.  The item names may contain multiple words (assume they will not overflow).  The line of stars is 30 characters long.
 *******************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  string item1, item2, item3;
  double price1, price2, price3;
  double subtotal;
  const double tax_rate=0.0485; //tax rate is constant b/c it is a fixed value
  double tax;
  double total; //tax rate + subtotal

  cout << "Enter the first item: " << endl;
  getline.(cin, item1);

  cout << "Enter the second item: " << endl;
  //  cin.ignore(); //ingores the null terminator, which is after the 'e' in "Apple pie"
  getline(cin, item2); //getline also acts a cin statement (for the second item)
 
  cout << "Enter the third item: " << endl;
  getline(cin, item3);
   
  cout << "Price of the first item you entered: " << endl;
  cin >> price1;
  cout << "Price of the second item you entered: " << endl;
  cin >> price2;
  cout << "Price of the third item you entered: " << endl;
  cin >> price3;
  cout << endl;

  cout << "TAX rate " << "4.85%" << endl << endl; 
  cout << "******************************" << endl;
  cout << left << setw(20) << item1 <<"$" << right << setw(9)<< price1 << endl;
  cout << left << setw(20) << item2 <<"$" << right << setw(9)<< price2 << endl;
  cout << left << setw(20) << item3 <<"$" << right << setw(9)<< price3 << endl;

  cout << endl;

  subtotal =  price1 + price2 + price3; //This now gives the value to the subtotal when I give it it's value here, instead of initializing its value at the top
  tax = subtotal*0.0485;
  total = subtotal + tax;

  cout << left << setw(20) << "Subtotal" <<"$" << right << setw(9) << fixed << setprecision(2) << subtotal << endl;
  cout << left << setw(20) << "Tax" <<"$" <<  right << setw(9)<< fixed << setprecision(2) << tax << endl;
  cout << left << setw(20) << "Total" <<"$" << right << setw(9) << fixed << setprecision(2) << total << endl;

  cout << "******************************" << endl;
  cout << "Thank you for shopping with us" << endl;
  cout << "******************************" << endl;

  return 0;
}
