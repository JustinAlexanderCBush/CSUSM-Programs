/********************************************************************************************
Justin Bush 
CS 111
Castillo
Ask the user to enter a positive integer, or -1 to quit.  If the user enters a positive integer repeat it and tell them whether it is even or odd.  If the user enters -1 then tell them how many odd numbers they entered and how many even numbers they entered.  If they entered no numbers, tell them “no numbers were entered” instead of saying 0 even numbers and 0 odd numbers.
********************************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  int integer;
  int evenCount; //counter for the total number of even numbers entered by the user
  int oddCount;  //counter for the total number of odd numbers entered by the user

  cout << "Enter an integer (-1 to quit): " << endl;
  cin >> integer;
    
  while(integer >= 0)
    {
      if(integer % 2 == 0) //an even number
	{
	  cout << integer << " is even." << endl;
	  evenCount++; 
	}
      else if(integer % 2 == 1) //an odd number
	{
	  cout << integer << " is odd." << endl;
	  oddCount++;
	}

      cout << "Enter an integer (-1 to quit): " << endl;
      cin >> integer;
    }

  if(evenCount == 0  && oddCount == 0) //This new if-else statement is for if the user entered -1, so it comes OUT of the while loop
      cout << "No numbers were entered." << endl;
  else
    {
      cout << "Odd numbers: " << oddCount << endl;
      cout << "Even numbers: " << evenCount << endl;
    }
    
  return 0;
}
