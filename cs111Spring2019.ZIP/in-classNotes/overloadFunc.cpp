/*******
4/15
*******/
#include <iostream>
using namespace std;

double power(double base, int exp);
double power(double base);

int main()
{
  double b; //base
  int e; //exponent
  
  cout << "Enter base: ";
  cin >> b;
  cout << "Enter exponent: ";
  cin >> e;
  
  double total = power(b, e);
  cout << "Total is: " << total << endl;

  cout << "Enter a number to square: ";
  cin >> b;
  cout << b << " squared is: " << power(b) << "." << endl;

  return 0;    
}

double power(double base, int exp)
{
  cout << "** Called power with 2 parameters and custom exponent **" << endl;
  double result = 1; //anything to the zero power = 1
  for(int i = 0; i < exp; i++)
      result *= base;

  return result;
}

double power(double base)
{
  cout << "** Called power with 1 parameter to square **" << endl;
  return base * base;
}
