/**********************************

 *********************************/
#ifndef RESTAURANT_H
#define RESTAURANT_H
#include<vector>
#include<string>
#include"Reservation.h" 
using namespace std;

class Restaurant
{
 private:
  string restaurantName;    
  string restaurantAddress;
  string restaurantCity;
  string restaurantType; //type of food served
  int availableSeats[4]; //array holding number of available seats at four  
                         //possible times: 5, 6, 7 and 8 pm 
  vector<Reservation> reservations; //list of reservations at this restaurant

 public:
  Restaurant();
  Restaurant(string restName, string restAddress, string restCity, string restType, int restCapacity);
  // void setRestaurant(string restName, string restAddress, string restCity, string restType, int rSeats[]);
  void printRestaurantInfo() const;
  string getName() const;
    string getCity() const;
  string getType() const;
  int getSeats(int i) const;
  void ReservationInfo(string cName, string cPhone, int rGroup, int rTime);
  void printReservation();  
};

#endif
