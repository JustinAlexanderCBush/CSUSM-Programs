/****************************
Justin Bush 
CS 211 Lab 9 Part 2
Write a program that will read monthly sales of a certain company into a dynamically allocated array of double values.

Your program should:
-prompt the user to enter the size of the array (that is the number of monthly sales)
-dynamically allocate an array large enough to hold the number of monthly sales given by the user
-find and print the yearly sum of all the monthly sales

Note: don’t forget to deallocate memory!

Sample run:
Enter the number of monthly sales to be input: 4
Enter the monthly sales for month 1: 1290.89
Enter the monthly sales for month 2: 905.95
Enter the monthly sales for month 3: 1567.98
Enter the monthly sales for month 4: 994.83
The total sales for the year is: $4759.65
 ***************************/
#include<iostream>
using namespace std;

//double findYearlySum(double sales[], int size);

int main()
{
  int size;
  
  cout << "Enter the number of monthly sales to be input: ";
  cin >> size;
  
  //dynamically created array:
  double array[size];
  double* ptr = array;
  double total;

  ptr = new double[size];
 
  //reading monthly sales
  for(int i = 0; i < size; i ++)
    {
      cout << "Enter the monthly sales for month " << i + 1 << ": ";
      cin >> ptr[i];
      total += ptr[i]; //total = ptr[i] + total
    }
  delete [] ptr;
  ptr = nullptr;
 
  cout << "The total sales for the year is: " << total << endl;

  return 0;
}

