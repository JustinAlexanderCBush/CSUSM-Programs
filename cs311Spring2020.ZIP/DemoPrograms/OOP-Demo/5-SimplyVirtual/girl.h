// CS311 Yoshii - girl header inheriting from person
// ---------------------------------------------------
using namespace std;
#include "person.h"

class girl : public person
{
 public:
  girl();
  ~girl();
  void doit(); 
}; 
