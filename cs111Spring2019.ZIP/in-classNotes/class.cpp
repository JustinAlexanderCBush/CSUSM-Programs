/*******
4/10/19
*********/
#include <iostream>
using namespace std;

class car //classes act as a blueprint to create objects ("car" in this case) 
{        
public: //every object "car" has these variables/functions (hence "public:") 
  bool isElectric;
  string model, color;

  void Drive()
  {
    cout << "The " << color << " " << model << " goes ";
    if(isElectric)
      cout << "Whirr Whirr." << endl;
    else
      cout << "Vroom Vroom!" << endl;
  }

};

int main()
{
  car c1;
  c1.color = "Blue";
  c1.model = "F-150";
  c1.isElectric = false;
 
  car c2;
  c2.color = "Purple";
  c2.model = "Tesla";
  c2.isElectric = true;
 
  c1.Drive();
  c2.Drive();

  return 0;
}
