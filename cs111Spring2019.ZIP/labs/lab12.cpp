/********************************************************************************
Justin Bush 
CS 111  
3/4/19
Modify Lab 10 so that the full contents of the multiplication table is stored into a two-dimensional array and then printed. Store the size of the array as a named constant – test with at least two different sizes. Make your table range from 0 to the size-1
 *******************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
  const int row = 4;
  const int col = 4; //'col' is short for column

  int multTable[row][col];
  //the variable 'r' is for the numeric value of every row
  //the variable 'c' is for the numeric value of every column

  int colNum[col]; //An array for the column numbers, above the multiplication table
  cout << "      "; 
  for(int i = 0; i < col; i++)
    {
      colNum[i] = i; //stores the value of the array in the corresponding index value
      cout << right << setw(5) << colNum[i];
    }
  cout << endl;

  //The start of the multiplication table
  for(int i = 0; i < col; i++;
      cout << "-------";
    
  cout << endl;

 
 //This nested for-loop is to store the values inside the table
  for(int r = 0; r < row; r++)
    {    
      for(int c = 0; c < col; c++)	
	  multTable[r][c] = r * c; 
    }

  //This nested for loop is to output the values of the table(formating)
  for(int r = 0; r < row; r++)
    {
      cout << right << setw(5) << r << "|";
      for(int c = 0; c < col; c++)
	{
	  cout << setw(5);
	  cout << multTable[r][c];
	}
      cout << endl;
    }

  cout << "Enter row and column value" << endl;
  int userRow, userCol;

  cout << "Row: ";
  cin >> userRow; 
  cout << "Column: ";
  cin >> userCol;
  cout << "Value: " << multTable[userRow][userCol] << endl;
  
  return 0;
}
