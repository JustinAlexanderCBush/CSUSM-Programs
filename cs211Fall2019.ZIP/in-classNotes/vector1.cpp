#include <vector>
#include <iostream>
#include<fstream>
using namespace std;

int main()
{
  vector<int> V;
  int tmp;
  ifstream fin;
  fin.open("data.txt");
  fin >> tmp; 
  while (fin)
    {    
      cout << tmp << endl;
      V.push_back(tmp);
      fin >> tmp; 
    }
  cout << "File contains " << V.size() << " entries \n";
}













