//CS311 Yoshii
//INSTRUCTION:
//Look for ** to complete this program (Use control-S)
//The output should match my hw1stackDemo.out 

//=========================================================
//HW#: HW1P1 stack application (post-fix evaluation)
//Your name: Justin Bush
//Complier:  g++
//File type: client program client1.cpp
//===========================================================

using namespace std;
#include <iostream>
#include <stdlib.h>
#include <string>
#include "stack.h"

//Purpose of the program: To perform arithmetic operations using a stack
//Algorithm: To perform post-fix arithmetic, with values from a stack. 
           //Operands are pushed into a stack, until it is full. When that 
           //occurs, arithmetic will be performed, based on what numbers and 
           //operations are decided to be used by the user
int main()
{
  stack postfixstack;  // integer stack
  string expression;   // user entered expression
  
  cout << "type a postfix expression: " ;
  cin >> expression;
  
  int i = 0;  // character position within expression
  char item;  // one char out of the expression
  
  int box1;  // receive things from pop
  int box2;  // receive things from pop
  
  while (expression[i] != '\0') //while the expression at position i does not
                                //equal null terminator,
    {
      try
	{
	  item = expression[i];  // current char
	  
	  // ** do all the steps in the algorithm given in Notes-1
	  if(item >= '0' && item <= '9') //if a single number is between 0 and 9
	    {
	      postfixstack.push(item - 48); //"item - 48" for ascii values 
	    }
	  else if(item == '-' || item == '+' || item == '*')
	    {
	      postfixstack.pop(box1);  //two boxes for the two operands, which 
	      postfixstack.pop(box2);  //both have to be popped from the stack
	      
	      if(item == '-')          //if and else-if statements for each 
		box1 = box2 - box1;    //kind of operation being performed for 
	      else if(item == '+')     //the stack
		box1 = box2 + box1;
	      else if(item == '*')
		box1 = box2 * box1;

	      postfixstack.push(box1);
	    }
	  else                        //else, throw the error message 
	    throw "ERROR: Incomplete expression.";	 

	} // this closes try
      // Catch exceptions and report problems and quit the program now (exit(1))
   
      // Error messages describe what is wrong with the expression.
      catch(stack::Overflow) 
	{ 
	  cerr << "ERROR: Expression too long." << endl;
	  exit(1);
	}
      catch(stack::Underflow)
	{	    
	  cerr << "ERROR: Too few operands." << endl;
	  exit(1);
	}
      catch(char const* errormsg ) // for invalid item case
	{
	  cerr << "ERROR: Invalid element." << endl;
	  exit(1);	
	}
      
      // go back to the loop after incrementing i  
      i++;
      
    }// end of while loop
  
  // After the loop successfully completes: 
  // Pop the result and show it.      

  postfixstack.pop(box1); //pops an operand in the stack
  
  // If anything is left on the stack, an incomplete expression 
  // was found so inform the user.
   if(!postfixstack.isEmpty())
    {
      cout << "ERROR: Incomplete stack" << endl;
      postfixstack.clearIt(); //call the clearIt func, to clear the whole stack
    }
   else
     cout << "RESULT: " << box1 << endl;

   return 0;
}// end of the program
