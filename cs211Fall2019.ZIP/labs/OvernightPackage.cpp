#include<iostream>
#include"Package.h"
#include"OvernightPacakge.h"
using namespace std;

OvernightPackage::OvernightPackage():Package();
{
  overnightFee = 0;
}

OvernightPackage::overnightFee(double overnightFee); 
{
  overnightFee = overNightFee;
}

OvernightPackage::calculateCost(); 
{

}



OvernightPackage::printOverNightPackage(); 
{


}

