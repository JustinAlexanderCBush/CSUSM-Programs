/*************
The following function fills an array with numbers from an input file. The user will enter the file name from the keyboard.

Note: We do not know how many numbers we have in the input file.
Restriction: if the input file has more numbers than the size of the array, this function will fill the array up to the size.

Return: the number of numbers stored into the array.
a: integer array
s: size of the array. Restriction: s >= 1
************/
#include <iostream>
#include <fstream>
#include <cstdlib> //for exit(1) in the if-statement
using namespace std;

int fillArray(int a[], int s);

int main()
{
  const int SIZE = 5;
  int ar[SIZE];

  cout << fillArray(ar, SIZE);

  return 0;
}

int fillArray(int a[], int s)
{
  string filename;
  cout << "Enter the input file name 'fillArrayFromInputFile.txt': ";
  cin >> filename;

  ifstream fin;
  fin.open("fillArrayFromInputFile.txt"); //OR fin.open(filename.c_str()) This converts a c++ string to a c-string

  if(!fin) //OR if(fin == NULL)     //If the input file doesn't exist
    {
      cout << filename << " doesn't exist. Terminating the program." << endl;
      exit(1); //terminates program at this point and sends the error code 1 to the operating system
    }

  //If the input file is opened, the following code will be executed
  int i = 0;
  int num; //each number is read into this variable from the input file

  fin >> num;

  while(fin && i < s) //a new number was read and also there is still room in the array
    {
      a[i++] = num; //a[i] = num; then i++
      fin >> num;
    }

  fin.close();
  return i; //The number of numbers read into the array
}
