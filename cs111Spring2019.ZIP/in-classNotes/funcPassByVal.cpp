/**********************************************
pass by value type of function
 *********************************************/

#include <iostream>
using namespace std;

void printStarLine(int size); //This is a function prototype

int main() ////    ./a.out runs the main function
{
  int input;
 
  cout << "Enter length of star line" << endl;
  cin >> input;
    
  printStarLine(input); //This calls (uses) the printStarLine function
 
  cout << "In main, the input is: " << input << endl;

  return 0;
}

void printStarLine(int size) //This is a function
{
  //  int size;
  for(int i = 0; i < size; i++)
    {
      {
	cout << "*";
      }
      cout << endl;
    }

  size = 0;

  cout << "In function, size is: " << size << endl;

}
