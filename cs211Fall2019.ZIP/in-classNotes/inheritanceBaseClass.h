#ifndef INHERITANCEBASECLASS_H
#define INHERITANCEBASECLASS_H
using namespace std;

//This program shows the difference between private
//and protected member of a class.

//-------------------------------------------------
class Person
{
 public:
  Person();
  Person(string theName);

  void get_name(string theName);
  void set_name(string theName);

 protected:
  //private:
  string name;
};

#endif

