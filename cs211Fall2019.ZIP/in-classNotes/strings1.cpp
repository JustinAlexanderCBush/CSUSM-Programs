#include<iostream>
using namespace std;
string func1(string line);

int main()
{
  string line1, line2;
  line1 = "This is Adam Smith";
  line2 = func1(line1);
  cout << line2 << endl;
  // ...
  

  return 0;
}

string func1(string line)
{
  char temp;
  for(int i = 0; i < line.size()/2; i++)
    {
      temp = line[i];
      line[i] = line[line.size() - 1 - i];
      line[line.size() - 1 - i] = temp;
    }
  return line;
}
