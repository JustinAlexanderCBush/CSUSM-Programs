/*
3/8/19
 */
#include <iostream>
using namespace std;

int main()
{
  int xInt = 8;
  int yInt = 9;

  cout << "Integers: " << xInt << " + " << yInt << " = " << xInt + yInt << endl;


  char xCh = '8'; //char will assign the numeric value of 56 to the character 8
  char yCh = '9';

  cout << "Integers: " << xCh << " + " << yCh << " = " << xCh + yCh << endl;
  

  string xSt = "8";
  string ySt = "9";

  cout << "Integers: " << xSt << " + " << ySt << " = " << xInt + yInt << endl;

  return 0;
}
