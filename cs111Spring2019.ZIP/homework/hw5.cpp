/******************************************************************************
Justin Bush
CS 111 Castillo
Homework 5
5/10/19
Write a program to read in a list of exam scores from a file (integer percentages in the range 0 to 100) and to output the total number of grades as well as the number of grades in each letter-grade category (90 - 100 = A, 80 - 89 = B, 70 - 79 = C, 60 - 69 = D, and 0 - 59 = F), what percentage of the total grades each letter grade represents, and the percentage average of all of the scores, including the decimal portion (remember integer math and typecasting!).   Note that the file may contain any number of grades, and it may not be the same each time the program is run.  Use a function to read from the file and another function to print the results.  Be sure to close the file when done.  You may calculate the results anywhere you see fit.  For example, if the input is

98
85
85
63
78
66
73
72
72
87
72
70
86
50

the output could, for example, look something like this:

Total number of grades = 14
Number of A’s = 1 which is 7.1%
Number of B’s = 4 which is 28.6%
Number of C’s = 6 which is 42.9%
Number of D’s = 2 which is 14.3%
Number of F’s = 1 which is 7.1%
Average of all grades: 75.5%
******************************************************************************/
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

void readInputFileInfo(int& gradeA, int& gradeB, int& gradeC, int& gradeD, int& gradeF, int& scoreQuantity, int& scoresAddedT); 
void printResults(int gradeA, int gradeB, int gradeC, int gradeD, int gradeF, int scoreQuantity, int scoresAddedT);

//variable 'scoresAddedT' refers to the integer value of all scores added together
int main()
{
  int scoresAddedTogether = 0; //the integer value of all scores added together, and it refers to the variable 'scoresAddedT'
  int totalNumScores = 0; //total number of scores, and it refers to the variable 'scoreQuantity' 
  int gLetterA = 0, gLetterB = 0, gLetterC = 0, gLetterD = 0, gLetterF = 0; //refers to the variables 'grade[insert capital letter here]' 

  readInputFileInfo(gLetterA, gLetterB, gLetterC, gLetterD, gLetterF, totalNumScores, scoresAddedTogether);
  printResults(gLetterA, gLetterB, gLetterC, gLetterD, gLetterF, totalNumScores, scoresAddedTogether);
 
  return 0;
}

void readInputFileInfo(int& gradeA, int& gradeB, int& gradeC, int& gradeD, int& gradeF, int& scoreQuantity, int& scoresAddedT) 
{
  ifstream fin;
  fin.open("hw5InputFile.txt");

  int s = 0; //'s' is the variable I'm using to read in the scores from the 
  while(fin >> s)
    {
      //This if else-if statment checks if each score read from the input file is within each condition, and increments their respective grade letter
      if(s < 101 && s > 89)
	gradeA++; //incrementing the amount of letter grades ALSO COUNTS AS CHANGING THEM, that's why I should use pass by reference
      else if(s < 90 && s > 79)
	gradeB++;
      else if(s < 80 && s > 69)
	gradeC++;
      else if(s < 70 && s > 59)
	gradeD++;
      else if(s < 60 && s >= 0 )
	gradeF++;
      
      scoreQuantity++;  
      scoresAddedT += s; 
    }
  
  fin.close();
}

void printResults(int gradeA, int gradeB, int gradeC, int gradeD, int gradeF, int scoreQuantity, int scoresAddedT)
{
  //Since I am just dividing the amount of each grade letter by the scoreQuantity, that does NOT count as changing them (i.e. incrementing them)
  cout << "\nTotal number of grades: " << scoreQuantity;
  cout << "\nNumber of A's = " << gradeA << " which is: " << fixed << setprecision(1) << ((double)gradeA/scoreQuantity) * 100 << "%";
  cout << "\nNumber of B's = " << gradeB << " which is: " << setprecision(1) << ((double)gradeB/scoreQuantity) * 100 << "%";
  cout << "\nNumber of C's = " << gradeC << " which is: " << setprecision(1) << ((double)gradeC/scoreQuantity) * 100 << "%";
  cout << "\nNumber of D's = " << gradeD << " which is: " << setprecision(1) << ((double)gradeD/scoreQuantity) * 100 << "%";
  cout << "\nNumber of F's = " << gradeF << " which is: " << setprecision(1) << ((double)gradeF/scoreQuantity) * 100 << "%";
  cout << "\nAverage of all grades: " << fixed << setprecision(1) << ((double)(scoresAddedT)/scoreQuantity) << "%" << endl;
}


