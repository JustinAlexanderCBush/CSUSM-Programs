/***********************************************************************
Justin Bush 
CS 111 Castillo
4/20/19
//Include guards - prevents including the header more than once
***********************************************************************/
#ifndef LAB25_H //if CIRCLE_H is NOT defined
#define LAB25_H //define CIRCLE_H and include everything b/w ifndef and endif

const double pi = 3.14159;

//class goes in header (class className and everything in the braces and semicolon
class circle
{
 private:
  double radius;

 public:
  void setRadius(double passedRadius);
  double getRadius();
  double calcArea();
  circle(); //default constructor (no parameters)
  circle(double initialRadius); //constructor with a parameter for the inital radius
};

#endif //end of include guards

