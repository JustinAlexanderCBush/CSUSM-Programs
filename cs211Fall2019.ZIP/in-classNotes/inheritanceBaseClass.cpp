#include<iostream>
#include<string>
#include "inheritanceBaseClass.h"
using namespace std;

//class Person public functions

Person::Person()
{
  name = "Kevin";
}

Person::Person(string theName) 
{
  name = theName;
}

void Person::get_name(string theName) 
{
  theName = name;
}

void Person::set_name(string theName) 
{
  name = theName;
}


 
