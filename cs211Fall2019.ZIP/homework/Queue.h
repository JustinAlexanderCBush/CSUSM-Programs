#ifndef QUEUE_H
#define QUEUE_H
using namespace std;

typedef string el_t;

class Queue
{
 private:
  struct QueueNode
  {
    el_t letter; //the letters in the queue
    QueueNode *next; //pointer to the next node
  };

  //other private attributes of DynamicQueue class
  QueueNode *front; //pointer to the front of the queue
  QueueNode *rear; //pointer to the rear of the queue
  QueueNode *count; //number of items in the queue

 public:
  Queue(); //default constructor
  ~Queue(); //destructor
  void enqueue(el_t elem);
  void dequeue(el_t &elem);
  bool isEmpty();
  void displayAll();
};

#endif
