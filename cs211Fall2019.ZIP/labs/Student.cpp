/*********************************************
Justin Bush
*********************************************/
#include<iostream>
#include<string>
#include "Student.h"
using namespace std;

//declaring static member variables
int Student::totalNumofStudents = 0; 

int Student::nextStudentID = 10000;

Student::Student():studentID(nextStudentID) //initializing const long studentID
{
  name = "Unknown";
  major = "CS";
  classification = "undergraduate";
  units = 12;
  tuition = 0;
  totalNumofStudents++; 
  nextStudentID++;
}
 
Student::Student(string theName, string theMajor, string theClassification, int theUnits):studentID(nextStudentID)
{
  name = theName;
  major = theMajor;
  classification = theClassification;
  units = theUnits;
  totalNumofStudents++;
  nextStudentID++;
}

Student::~Student()//deconstructor
{
  totalNumofStudents--;
}
 
void Student::print() const
{
  cout << "Name: " << name << endl;;
  cout << "ID: " << studentID << endl;
  cout << "Major: " << major << endl;
  cout << "Classification: " << classification << endl;
  cout << "Units: " << units << endl;
}

void Student::setData()
{
  cout << "Enter a student's name: ";
  getline(cin, name);
  cout << "Enter a major: ";
  getline(cin, major); 
  cout << "classification: ";
  getline(cin,classification);
  cout << "Units: ";
  cin >> units;  
}
