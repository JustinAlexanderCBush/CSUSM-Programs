/**********************************************************************
Homework 1
Justin Bush 
9/20/19
Purpose of the program:In this assignment, you need to write a program that maintains the gradebook for a specific course. For each student registered in this course, the program keeps track of the student’s name, identification number (id), four exam grades, and final grade. The program performs several functionalities such as: enrolling a student in the course, dropping a student from the course, uploading student’s exam grades, displaying the grades of a specific student, displaying the grades of all students in the course, and printing grades summary information. 
Algorithm/Design:
**********************************************************************/
#include<iostream>
#include<iomanip>
#include<vector>
#include<fstream>
#include<string>
using namespace std;

struct Student
{
  string name;       //student first and last name
  long id;           //student ID number;
  double grades[4];  //array holding four exam grades
  double finalGrade; //student's final grade
};

void enroll(vector<Student> &students, string firstName, string lastName, long idNum);
void display(vector<Student> &students);
void searchByName(vector<Student> students);
//void dropStudentID(vector<Student> &students);
void uploadGrades(vector<Student> &students, long idNum, double grades);
//void printClassSummary(vector<Student> &students);

int main()
{
  vector<Student> students; //declared a vector of Student struct, named students
  string command; //for reading the commands from the file

  string firstName, lastName, nameSearch; //for calling functions, using the corresponding names as in the function prototypes
  long idNum; 
  double grades, finalGrade;

  ifstream fin; 
  fin.open("StudentsTrans.txt");
  if(!fin) //if the file doesn't exist, print the following message to the screen
     cout << "The file doesn't exist" << endl;
  else
    {
      while(fin >> command) //while the file can read commands
	{
	  //fin >> command;
	  if(command == "enroll")
	    {    
	      fin >> firstName;
	      fin >> lastName;
	      fin >> idNum;
	      enroll(students, firstName, lastName, idNum); 
	    }
	  else if(command == "display")
	    {
	      display(students);
	    }
	  else if(command == "searchByName")
	    {
	      fin >> nameSearch;
	      searchByName(students);    
	    }
	  else if(command == "drop");
	  //dropStudentID(students)
	  else if(command == "uploadGrades")
	    {
	      fin >> idNum;
	      fin >> grades;
	      uploadGrades(students, idNum, grades);
	    }
	  else if(command == "printClassSummary");
	  //printClassSummary(students);
	  
	}
    }

  fin.close(); //close the input file

  return 0;
}

/***************************
The function's parameters will split the struct Student's member variable of name, into firstName and lastName, and it will pass the student's id number, for the function call in main. I pass the vector students by reference because its information will change, because of the for-loop. The function's purpose is to fill the student info from the Student struct from the input file.  
 **************************/
void enroll(vector<Student> &students, string firstName, string lastName, long idNum)
{
  Student temp; //object Student variable declaration of temp
  temp.name = firstName + " " + lastName;
  
  for(int i = 0; i < students.size(); i++)
    {      
      if(idNum == students[i].id)
	{
	  cout << left << setw(17) << temp.name << " already enrolled, cannot enroll again." << endl;
	  return;
	}
    }  
  
  for(int j = 0; j < 4; j++) //setting all exam scores to zero
    temp.grades[j] = 0.0; 

  temp.finalGrade = 0.0; //set final grade to zero
  temp.id = idNum; //for the cout statement
  cout << left << setw(17) << temp.name << " " << idNum << " successfully added to students vector" << endl;
  students.push_back(temp); //so that the vector can add space, to fill each of the student's information from the struct Student
}

/*******************************
The function's purpose is to display each of the student's names, id numbers, four test scores, and final grade. Their names and ID's will be displayed, but their tests and final grade will be set to zero.
 ******************************/
void display(vector<Student> &students)
{
  Student temp; 
  
  //formatting the header for the display function
  cout << left << setw(20) << "Student" << setw(12) << "ID" << setw(8) << "Exam1" << setw(8) << "Exam2" << setw(8) << "Exam3" << setw(8) << "Exam4" << right << setw(11) << "Final Grade" << endl;
  cout << "----------------------------------------------------------------------------" << endl;
  
  //filling in the data from the file, along with the format of each student
  for(int i = 0; i < students.size(); i++)
    {
      temp = students[i]; 
      temp.finalGrade = (temp.grades[0] + temp.grades[1] + temp.grades[2] + temp.grades[3])/4;
      cout << left << setw(20) << temp.name << " " << setw(12) << temp.id << setw(8) << temp.grades[0] << setw(8) << temp.grades[1] << setw(8) << temp.grades[2] << setw(8) << temp.grades[3] << right << setw(11) << temp.finalGrade << endl;
    }
}

/*******************************
This function will search for the student's name, checking if he or she exists in the file. If they don't, a message will display, meaning that they don't exist
 *****************************/
void searchByName(vector<Student> students)
{
  Student temp;
  for(int i = 0; i < students.size(); i++)
    {      
      if(temp.name == students[i].name) //checks if the student's name matches the file
	{
	  cout << "No such student exists." << endl;
	} 
    }
}
      

/********************************
This function will read in every ID number from the vector, and it will drop the student if their ID number doesn't exist
*******************************/
/*
void dropStudentID(vector<Student> &students, long idNum)
{
  for(int i = 0; i < students.size(); i++)
    {
      if(idNum == students[i].id)
	{
	  students.erase();
	}
    }
  
}
*/

/*********************************
This function will read in the grades from the file, and upload them for each student.
 ********************************/
void uploadGrades(vector<Student> &students, long idNum, double grades)
{
  Student temp;
  for(int i = 0; i < students.size(); i++)
    {
      if(idNum == students[i].id)
	{
	  temp = students[i];
	  cout << temp.name << " grades successfully uploaded." << endl;
	}
      else
	cout << "No such student exists, grades cannot be uploaded." << endl;
    }
}  


/**********************************
This function will print the class summary.
 *********************************/

/*
void printClassSummary(vector<Student> &students)
{
  for(int i = 0; i < students[i].size(); i++)
    {
      
    }


}

*/
