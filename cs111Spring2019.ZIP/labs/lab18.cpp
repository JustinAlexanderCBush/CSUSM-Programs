/********************************************************************************
Justin Bush
CS 111 Castillo
3/20/19
Write a function called dist that takes two double values as parameters and returns the absolute value of the difference of the two numbers (i.e. how far apart the numbers would be on a number line).  Do NOT use cmath/math.h for this lab.
In main ask the user to enter the two values, then print out the numbers and result in a sentence.
The function dist should NOT print anything or receive any input from the user (no cin or cout in this function).
*******************************************************************************/
#include <iostream>
using namespace std;
 
double dist(double num1, double num2);

int main()
{
  double n1, n2, ans;  //ans = answer

  cout << "Input a number: ";
  cin >> n1;
  cout << "Input another number: ";
  cin >> n2;

  ans = dist(n1, n2);

  cout << "The distance between " << n1 << " and " << n2 << " is " << ans;
  cout << endl;
  return 0;
}

double dist(double num1, double num2)
{
  double answer = num1 - num2;
  
  if(answer < 0)
    return (-1) * answer;
  else //answer is positive
    return answer;
}
