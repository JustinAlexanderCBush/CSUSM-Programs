/********************************************
Justin Bush
HW: 4
12/4/19
Purpose of the program: To check if the user's input has correctly balanced delimiters. It will check to see if there are too many delimiters, if there are any m\
issing delimiters, or if there aren't enough delimiters. I used the push and pop
methods for the stack to place and remove delimiters in the stack, when neccessar
y. I have used a dynamic stack of characters for each of the input brackets.
*********************************************/
#include<iostream>
#include"Stack.h"
using namespace std;

bool ProperlyBalanced(string input);

int main()
{
  bool result = false; //for test cases
  string redo; //to leave the while loop condition
  string userInput; //the characters the user will input

  while(result == false)
    {
      cout << "Enter a string: " << endl;
      cin >> userInput;
      ProperlyBalanced(userInput); //calling ProperlyBalanced func
      cout << "Continue entering strings? Enter Yes or No: ";
      cin >> redo;
      cout << endl; //to space out the results

      if(redo == "No")
	result = true; //do not leave the while loop condition
      else
	result = false; //redone, so ask the question again
    }
  cout << "Finished." << endl;

  return 0;
}

/*
This function will check if there is a correctly balanced amount of bracket delimiters. The parameter used is "input", the string that the user will input.
 */
bool ProperlyBalanced(string input)
{
  Stack S; //a BalancedStack object with an instant of the S variable
  for(int i = 0; i < input.length(); i++)
    {
      if(input[i] == '[' || input[i] == '(' || input[i] == '{')
	S.push(input[i]); //push the three opening delimiters in the if statment into the stack

      if(S.isEmpty() && (input[i] == ']' || input[i] == ')' || input[i] == '}'))
	{
	  cout << "Error. Extra closing delimiter." << endl;
	  return false;
	}

      if(input[i] == ']') //if user input includes a closing square bracket, pop.
	{
	  S.pop(input[i]);

	  if(input[i] == '(' || input[i] == '{')
	    {
	      cout << "Error. Mismatch between delimiters." << endl;
	      return false;
	    }
	}
      else if(input[i] == ')') //if user input includes a closing parenthesis, pop
	{
	  S.pop(input[i]);
	  if(input[i] == '[' || input[i] == '{')
	    {
	      cout << "Error. Mismatch between delimiters." << endl;
	      return false;
	    }
	  else if(input[i] == '}')
	    {
	      S.pop(input[i]);
	      if(input[i] == '[' || input[i] == '(')
		{
		  cout << "Error. Mismatch between delimiters." << endl;
		  return false;
		}
	    }
	}
    }
  if(S.isEmpty()) //if the stack is empty
    {
      cout << "The stack is empty." << endl;
      return true; 
    }
  else
    {
      cout << "Error. The right delimiter is missing." << endl;
      return false;
    }
}

