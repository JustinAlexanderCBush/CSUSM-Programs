/*******************************************************************************
Justin Bush
CS 111
Castillo
2/13/19
Write a program that asks the user to enter the size of a triangle to write to a
textfile (an integer from 1 to 50), then print the triangle into a file by printing a series of
lines consisting of asterisks. Print “Triangle saved to file” to the screen, but do NOT
print the triangle itself to the screen, only to the file. Name the output file triangle.txt
Input Validation: If the user enters an integer less than 1 or more than 50 tell
them it is out of range and have them re-enter it (do not print the triangle for the invalid
input, only for the final value in the range of 1-50 inclusive: 1 and 50 are both ok).
The first line will have one asterisk, the next two, and so on, with each line having
one more asterisk than the previous line, up to the number entered by the user. On the
next line print one less asterisk and continue by decreasing the number of asterisks by
1 for each successive line until only one asterisk is printed. Hint: Use nested for loops;
the outside loop controls the number of lines to print, and the inside loop controls the
number of asterisks to print on a line.
For example, if the user enters 5, the output to the file would be:
*
**
***
****
*****
****
***
**
*

********************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  char letter_grade; //the letter grade that the user can input, and for the switch statement
  char answer; //either 'Y,' 'y,' 'N' or 'n,' for if they are taking a class

  cout << "Are you taking a class?: ";
  cin >> answer;
  
  if(answer == 'Y' || answer == 'y') //If the user only enters 'Y' or 'y'
    {
      cout << "Please enter a grade: ";
      cin >> letter_grade;

      switch(letter_grade) //switch statement for all the possible answers that the user may or may not input 
	{
	case 'A': 
	case 'a': cout << "Great Job!" << endl; 
	  break;
	case 'B': 
        case 'b': cout << "Great Job!" << endl;
	  break;
	case 'C':
	case 'c': cout << "You're doing alright." << endl;
	  break;
	case 'D':
	case 'd': cout << "You can improve." << endl;
	  break;
	case 'F':
       	case 'f': cout << "You can improve." << endl;
	default: cout << "Invalid grade." << endl;
	}
    }
  else if(answer == 'N' || answer == 'n') //If the user is not taking a class  
    {
      cout << "Thank you for using the system." << endl;
    }
  else //If the user inputs any character other than Y, y, N or n
    {
      cout << "Invalid input." << endl;
    }

  cout << endl;

  return 0;
}


