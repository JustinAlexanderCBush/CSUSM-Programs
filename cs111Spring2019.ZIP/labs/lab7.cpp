/********************************************************************************
Justin Bush 
CS 111
2/13/19
Write a program that prints the numbers from 1 to 100, one per line, but for multiples of three print “Fizz” instead of the number and for multiples of 5 print “Buzz” instead of the number.  For numbers which are multiples of both three and five instead print “FizzBuzz”.
********************************************************************************/
#include <iostream> 
using namespace std;

int main()
{  
  for(int x = 1; x <= 100; x++)
    {
      if((x % 3 == 0) && (x % 5 == 0))
          cout << "FizzBuzz" << endl;
      else if(x % 5 == 0)
          cout << "Buzz" << endl;
      else if((x % 3 == 0) || (x % 5 == 0))//One of the answers is true, in this case, it's when the x%3 is equivalent to 0 
	  cout << "Fizz" << endl;
      else
	cout << x << endl; 
    }

return 0;
}
