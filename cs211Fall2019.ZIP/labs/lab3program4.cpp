/*****************************

 ***************************/
#include<iostream>
#include<iomanip>
#include<fstream>
#include<vector>
#include<string>
using namespace std;

struct Person
{
  string firstName, lastName, phoneNumber;
};

int main()
{
  Person p;
  //string fName, lName, pNumber;
  vector<Person> directory; //declared a vector of the struct Person, called directory
  ifstream fin;
 
  cout << left << setw(16) << "Name" << setw(10) << "Telephone" << endl;
  cout << "-------------------------------" << endl;
  
  fin.open("telephoneData.txt");
  if(!fin)
    cout << "File doesn't exist." << endl;
  else //file does exist
    {
      while(fin >> p.firstName >> p.lastName >> p.phoneNumber) //the file can read in data	  
	directory.push_back(p);
      for(int i = 0; i < directory.size(); i++)
	cout << directory[i].firstName << " " << directory[i].lastName << right << setw(15) << directory[i].phoneNumber << endl; 
    }
  
  fin.close();
  
  return 0;
}
