/************
Justin Bush 
CS 211 Castillo
9/13/19
Write a function ReplaceSubString that takes three strings as parameters: string1 string2, and string3 and modifies one or more substrings of string1. The function should search string1 for all occurrences of string2. When it finds an occurrence of string2, it should replace it with string3 and save the result in a new string string4.

For example, suppose the three strings have the following values:
String1: “the dog jumped over the fence”
String2: “the”
String3: “that”
The new string object will have the value “that dog jumped over that fence”.

Write a main program to test your function. Your main program should:
- read three strings from the user: string1, string2, and string3 (You may use the string values provided above)
- call the function ReplaceSubString to modify string1
- display the new string.

Note:
- You should make sure string2 and string3 are not the same.
- You may use string member functions such as find, replace…
************/
#include<iostream>
#include<string> //defines a C++ string variable
#include<iomanip>
using namespace std;

void replaceSubString(string& string1, string string2, string string3); 

int main()
{
  //*******A variable ISN'T of TYPE string; It's an INSTANCE of CLASS string
  string s1, s2, s3;

  cout << "Enter a sentence." << endl;
  getline(cin, s1); 
  cout << "Enter a word to replace one of the words in your sentence: ";
  cin >> s2;
  cout << "Enter a word to replace your second entry with: ";
  cin >> s3;
  cout << endl;

  if(s2 == s3)
    cout << "Error - find and replace strings match!" << endl;
  else
    {
      replaceSubString(s1, s2, s3);
      cout << s1 << endl;
    }
  return 0;
}

void replaceSubString(string& string1, string string2, string string3)
{
  //the result of replacing string1 with string2 is stored in string4 
  int string4 = string1.find(string2, 0); //returns the first position at or beyond position 0 where string2 is found in string1 

  while(string4 != string1.npos) //while string4 != if pattern not found in string1 at or after position pos
    {
      //replaces the length of string2 beginning at position string4 with the characters in string3
      string1.replace(string4, string2.size(), string3);
      
      //string4 = the return of the position
      string4 = string1.find(string2, string4 + string3.size());
    }
} 
