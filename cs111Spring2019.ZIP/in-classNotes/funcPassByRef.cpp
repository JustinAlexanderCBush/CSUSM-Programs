//Pass by reference saves computation time and gives more space to the code
#include <iostream>
using namespace std;

void squareIt(int input1, int& input2); //input1 = pass by value 
                                        //input2 = pass by reference
int main()
{
  int x = 5;
  int y = 7;

  squareIt(x, y);

  cout << "x is " << x << " and y is " << y << endl; //x is 5 and y is 49

  return 0;
}

void squareIt(int input1, int& input2)
{
  input1 = input1 * input1; //or input1 *= input1;
  input2 = input2 * input2; //or input2 *= input2;
}

//since the void function doesn't return anything, and because  input1 is pass by value, 
//the function call 'x' and the function parameter 'input1' are not equivalent to each other.
