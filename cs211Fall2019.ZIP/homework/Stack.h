#ifndef STACK_H
#define STACK_H

typedef char el_t; //character elements of the dynamic stack

class Stack
{
 private:
  struct StackNode //This is so I don't have to use another class declaration for the Stack information  
  {
    StackNode *next; //pointer to the next node
    el_t element; //for the bracket characters in the StackNode struct
  };
  
  StackNode *top; //pointer to the top of the stack

 public:  
  Stack(); //default constructor
  void push(el_t elem); 
  void pop(el_t &elem);
  bool isEmpty() const;
};

#endif
