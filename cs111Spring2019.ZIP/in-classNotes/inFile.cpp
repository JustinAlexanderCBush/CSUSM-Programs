/********************************
Read 2 integers from a file and print to the screen.
*********************************/
#include <iostream>
#include <fstream> //needed for ifstream
using namespace std;
int main()
{
  string fileName;
  ifstream fin; //create input file stream object named fin
  int num1 = 0;
  int num2 = 0;

  cin >> fileName;

  fin.open("inFile.txt"); //open the file test.txt for input (reading)

  fin >> num1; //read first number from file and store in num1
  fin >> num2; //read second number from file and store in num2
  fin.close(); // close the file

  cout << "The two numbers are " << num1 << " and " << num2 << endl;

  return 0;
}

