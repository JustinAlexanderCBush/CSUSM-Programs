#include<iostream>
#include"LinkedList.h"
#include"Node.h"
using namespace std;

int main()
{
  LinkedList list1; //create an empty list, list1

  //call the function insertAtBegin to add a node with the value:
  list1.insertAtBegin("Nancy Garcia", "617-227-5454");
 
  //call the function append to add a node with the values:
  list1.append("Adam James", "202-872-1010"); 
  list1.append("Jim Meyer", "337-465-2345"); 
  
  //call the function insertAtBegin to add a node with the values:
   list1.insertAtBegin("Joe Didier", "352-654-1983");
  
  //call the function append to add a node with the value:
  list1.append("Mayssaa Najjar", "878-635-1234"); 

  //call the function print to display all nodes in list1
   list1.print();

  //call the function searchByName 3 times to search for the following persons:
   list1.searchByName("Nancy Garcia");
   list1.searchByName("Mayssaa Najjar");
   list1.searchByName("Jamie Garcia");
  
  //instantiate another list, list2, using the copy constructor so that list2 is a copy of list1
  LinkedList list2(list1);

  //use the overloaded == operator to check if list1 and list2 hold the same set of data. If they do, print a message that they are the same and call the function print to display the data of either one of them. Otherwise, display a message that they are different and print both lists
  if(list1 == list2)
    {
      cout << "Both lists are the same." << endl;
      list1.print();
    }
  else //list1 != list2
    {
      cout << "Both lists are different" << endl << endl;
      cout << "list 1:" << endl;
      list1.print();
      cout << "list 2:" << endl; 
      list2.print();
    }

  //modify list1 by adding an entry at the beginning with the value:
  list1.insertAtBegin("Michel Delgado", "327-165-2345");
  
  //check if list1 and list2 hold are the same. If they are, print a message that they are the same. Otherwise, display a message that they are different and print both lists
   if(list1 == list2)
     {
       cout << "Both lists are the same." << endl;
       list1.print();
     }
   else //list1 != list2
     {
       cout << "Both lists are different" << endl << endl;
       cout << "list 1:" << endl;
       list1.print();
       cout << "liist 2:" << endl;
       list2.print();
     }   

  return 0;
}
