#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  int ar[3][4] = { {0,0,0,0}, {1,1,1,1}, {2,2,2,2} }; //creates 4 x 3 integer 2-dimensional array
  
  for(int row = 0; row < 3; row++) //'col' is short for column
    {
      cout << setw(5)  << ar[row] << endl;
      for(int col = 0; col < 4; col++)
	cout << setw(5) << ar[col];
      cout << endl;
    }
  
  return 0;
}
