// CS311 Yoshii
// HW6 Client file 
//INSTRUCTION: Complete this file and comment using How to Comment file.
//---------------------------------------------

// ================================================
// HW#: HW6 dgraph client 
// Name: Justin Bush
// File type:  client (tester)
// ================================================

#include<iostream>
#include<stdlib.h>
#include "dgraph.h"
using namespace std;

int main()
{
  char key; //vertex we're looking for
  int degree; //the out degree 
  slist adjacency; //declare adjacency object
  dgraph TableObj; //declare table object

  TableObj.fillTable(); //fill table
  TableObj.displayGraph(); //display graph

  cout << "Enter a vertex name or press Q to exit" << endl;
  cin >> key; //User specifies which vertex
  while(key != 'Q') //The user doesn't want to stop
    { 
      try
	{
	  degree = TableObj.findOutDegree(key);    //findOutDegree of vertex 
	  adjacency = TableObj.findAdjacency(key); //findAdjacency of vertex 
	  if(degree == 1)                       
	    cout << degree << " edges comes out to: ";
	  else
	    cout << degree << " edges comes out to: ";

	  adjacency.displayAll();
	  cout << endl;
	}

      catch(dgraph::BadVertex) //catch exception to display error message
	{
	  cerr << "Error. Vertex does NOT exist." << endl;
	}
      cout << "Enter a vertex name or press Q to exit" << endl;
      cin >> key;
    }

  return 0;
}


/* **
  0.Declare table object
  1.fillTable()
  2.displayGraph()
  while (the user does not want to stop)
    a.the user will specify which vertex
    b.findOutDegree of the vertex and display the result
    b.findAdjacency of the vertex and display the result (see Hint)
    c.catch exception to display error mesg but do not exit

Hint:
  slist l1;
  l1 = G.findAdjacency('a');
  // how do you display l1?  Hint: it is an slist from HW3.
  */
