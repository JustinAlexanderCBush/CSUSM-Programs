#include <iostream>
using namespace std;

void add(int &x);

int main()
{
  int data = 10;
  add(data);

  cout << "Value in data = " << data << endl;

  return 0;
}

void add(int &x)
{
  int input;
  
  cout << "Enter the value to be added in data: ";
  cin >> input;
  x += input; //x = x + input;
}
