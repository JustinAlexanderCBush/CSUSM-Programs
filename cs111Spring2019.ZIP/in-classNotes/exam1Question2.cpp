/****
Make an array with 100 slots, print out five times the value of the index into its corresponding index. Fill the array and then print out the array, one line at a time.
*****/
#include <iostream>
using namespace std;

int main()
{
  int ar[100];

  for(int i = 0; i < 100; i++)
    {
      ar[i] = i * 5;
      cout << ar[i] << endl;
    }

  return 0;
}
