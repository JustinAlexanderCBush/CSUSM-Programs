/******************************
Justin Bush
*******************************/
#include<iostream>
#include<iomanip>
#include<vector>
#include"Reservation.h"
using namespace std;

//declaring static member variables
long Reservation::nextReservationNum = 100;

//initializing const long reservationNum
//sets reservationNum to the value of nextReservationNum
Reservation::Reservation():reservationNum(nextReservationNum) 
{
  contactName = "";
  contactPhone = "";
  groupSize = 0;
  reservationTime = 0; 
  nextReservationNum += 10;
}

Reservation::Reservation(string cName, string cPhone, int gSize, int reserveTime):reservationNum(nextReservationNum) //overloaded constructor for the Reservation class
{
  contactName = cName;
  contactPhone = cPhone;
  groupSize = gSize;
  reservationTime = reserveTime;
  nextReservationNum += 10;
}

long Reservation::getReservationNum() //can't be constant
{
  return reservationNum;
}

/******************************************
I will use this getter function to compare the times that are read from the file, for the array. 
 ******************************************/
int Reservation::getReservationTime() const
{
  return reservationTime;
}

/*********************************
I will use this print function with the reservations vector, using the public functions from the Reservation class
 *******************************/
void Reservation::printReservationInfo() 
{
  cout << left << setw(12) << reservationNum;
  cout << left << setw(11) << contactName;
  cout << left << setw(14) << contactPhone;
  cout << left << setw(7) << groupSize;
  cout << left << setw(7) << reservationTime;
  cout << endl;
}

