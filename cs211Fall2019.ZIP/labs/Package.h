/******************
Justin Bush
******************/
#ifndef PACKAGE_H
#define PACKAGE_H
#include<iostream>
using namespace std;

class Package // base/parent class
{
 protected:
  string senderName, senderAddress, senderCity, senderState; //sender information
  long senderZipCode;
  string recipName, recipAddress, recipCity, recipState; //recipient information
  long recipZipCode;
  string label, date; //package label, date the package is shipped
  double weight, costPerOunce; //package weight and standard shipping fee per ounce
  string insuranceType; //describes extra package insurance option

 public:
  Package();//default constructor to initialize and validate all corresponding attributes
  calculateCost();//should determine cost by multiplying weight by costPerOunce and adding insurance fees if applicable
  void setSender(string sName, string sAddress, string sCity, string sState, long sZipCode);
  void setRecipient(string rName, string rAddress, string rCity, string rState, long rZipCode);
  void setPackageAndInsurance(string pkgLabel, string pkgDate, double pkgWeight, double pkgCostPerOunce, string insType);

    

};

#endif
