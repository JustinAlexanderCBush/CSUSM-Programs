#ifndef INHERITANCEDERIVEDCLASS_H
#define INHERITANCEDERIVEDCLASS_H
using namespace std;

//This program shows the difference between private and protected members of a class
//IMPORTANT: This is the derived class of the base class called Person

//-------------------------------------------------
class Employee: public Person
{
 public:
  Employee();
  Employee(string theName, int num);

  // adds new functionality, BUT, WHAT DOES THIS DO??????????
  int get_number();
  void set_number(int num);
  void print();

  //protected:
 private:
  intnumber;
};

#endif
