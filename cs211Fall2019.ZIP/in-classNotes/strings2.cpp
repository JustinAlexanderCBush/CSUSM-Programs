#include<iostream>
using namespace std;
void func2(string& line);

int main()
{
  string line1, line2;
  line1 = "This is Mr. Brown";
  cout << line1 << endl;
  func2(line1);
  cout << line1 << endl;
  // ...

  return 0;
}

void func2(string& line)
{
  int i;
  char temp;
  for(i = 0; i < line.size()/2; i++)
    {
      temp = line[i];
      line[i] = line[line.size() - 1 - i];
      line[line.size() - 1 - i] = temp;
    }

}
