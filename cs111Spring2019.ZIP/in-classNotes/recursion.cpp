/**********
4/29
Recursion is when a function calls itself
We use recursive cases to eventually reach our base case
*********/
#include <iostream>
using namespace std;

int rFact(int x); //r factorial

int main()
{
  int num;
  
  cout << "enter a number: ";
  cin >> num;
  cout << num << "! is " << rFact(num) << endl << endl;

  return 0;
}

int rFact(int x)
{
  if(x == 1) //base case
    return 1;
  else //recursive case
    return x * rFact(x-1);
}

//stack overflow means infinite recursion function calls; seen as a segmentation fault error
