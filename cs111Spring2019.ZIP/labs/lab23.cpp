/******************************************************************************
Justin Bush
CS 111 Castillo
4/10/19
Create a program that defines a class called circle. Circle should have a member variable called radius that is used to store the radius of the circle. Circle should also have a member method called calcArea that calculates the area of the circle using the formula area = pi*r^2. Area should NOT be stored in a member variable of circle to avoid stale data.

Use the value 3.14 for PI.

For now, make radius public and access it directly using the dot operator. Do not worry about input validation for now.  In main instantiate two objects of class circle and have the user enter a radius for each. Store the radii in the appropriate objects' member variables, then print the radius and area of each circle using the member variable and function.
*******************************************************************************/
#include <iostream>
using namespace std;

class circle
{
public:
  double radius;     
  double calcArea()
  {
    double pi = 3.14;
    return pi * (radius * radius); 
  }
};

int main()
{
  circle c1, c2; //c1 and c2 are objects of the class "circle" 
 
  cout << "Enter the radius for the first circle: ";
  cin >> c1.radius;
  cout << "The radius is " << c1.radius << " and the area is " << c1.calcArea() << ".";

  cout << "\nEnter the radius for the second circle: ";
  cin >> c2.radius;
  cout << "The radius is " << c2.radius << " and the area is " << c2.calcArea() << "." << endl;

  return 0;
}
