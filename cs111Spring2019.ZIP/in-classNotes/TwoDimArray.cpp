#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  int ar[3][4] = { {0,0,0,0}, {1,1,1,1}, {2,2,2,2} }; //creates 3 x 4 integer 2-dimensional array (3 rows and 4 columns)
  
  for(int row = 0; row < 3; row++) //'col' is short for column
    {
      for(int col = 0; col < 4; col++)
	cout << setw(5) << ar[row][col] << endl;
    }
  
  return 0;
}
