#include <iostream>
using namespace std;

int main()
{
  cout << "2+2=" << 2+2 << endl;
}

