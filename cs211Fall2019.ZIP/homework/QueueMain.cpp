#include<iostream>
#include"Queue.h"
using namespace std;

int main()
{
  Queue q;
  string c;

  //add the letters A, B and C into the queue
  q.enqueue("A"); 
  q.enqueue("B");
  q.enqueue("C");
  // q.displayAll();

  for(int i = 0; i < 3; i++)
    {
      q.dequeue(c);
      cout << c << endl;
      q.enqueue(c);
    }
  for(int i = 0; i < 12; i++)
    {
      q.dequeue(c);
      cout << c + "A" << endl;
      q.enqueue(c + "A");
      cout << c + "B" << endl;
      q.enqueue(c + "B");
      cout << c + "C" << endl;
      q.enqueue(c + "C");
    }

 return 0;
}
