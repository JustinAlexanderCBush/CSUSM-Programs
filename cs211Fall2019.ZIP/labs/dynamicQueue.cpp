/***************************************
In this part, you are going to design a dynamic queue of characters implemented as a linked list. Complete the code below as specified by the comments in bold.
***************************************/
#include<iostream>
using namespace std;

typedef char el_t;

class Queue 
{
private:
  struct QueueNode
  { 
    el_t letter; // letter in the node
    Node* next; // Pointer to the next node
  };

  Node* front; // Pointer to the front of the Queue
  Node* rear;// Pointer to the rear of the Queue
  int count;// Number of items in Queue

public:
  Queue(); // Constructor
  ~Queue(); // Destructor
  // Queue operations
  void enqueue(el_t);
  void dequeue(el_t &);
  void displayAll() const;
  //  bool isFull() const;
  bool isEmpty() const;
};

int main ()
{
  Queue q;
  el_t c;
  cout << " initial Queue contents: " << endl;
  q.displayAll();
  q.dequeue(c);
  q.enqueue('a');
  cout << endl << " Queue contents after adding a: " << endl;
  q.displayAll();
  q.enqueue('b');
  q.enqueue('c');
  q.enqueue('d');
  q.enqueue('e');
  q.enqueue('f');
  cout << endl << " Queue contents after adding b-f: " << endl;
  q.displayAll();
  q.dequeue(c);
  cout << endl << c << endl;
  cout << endl << " Queue contents after removing one element: " << endl;
  q.displayAll();
  q.dequeue(c);
  cout << endl << " Removed element: " << c << endl;
  cout << endl << " Queue contents after removing another element: " << endl;
  q.displayAll();
  q.enqueue('g');
  q.enqueue('h');
  q.enqueue('i');
  cout << endl << " Queue contents after adding g, h, i: " << endl;
  q.displayAll();
  q.dequeue(c);
  q.dequeue(c);
  q.dequeue(c);
  q.dequeue(c);
  cout << endl << " Queue contents after removing 4 elements: " << endl;
  q.displayAll();
  q.dequeue(c);
  q.dequeue(c);
  cout << endl << " final Queue contents: " << endl;
  q.displayAll();
 
  return 0;
}

Queue::Queue() // Constructor
{
  rear = nullptr;
  front = nullptr;
  count  = 0; 
}

Queue::~Queue() // Destructor
{
  Node *nodePtr;
  Node *nextNode;
  nodePtr = front;
  while(nodePtr != NULL)
    {
      nextNode = nodePtr->next;
      delete nodePtr;
      nodePtr = nextNode;
    }
  front = NULL;
  rear = NULL;
  count = 0;
 
}

void Queue::enqueue(el_t elm)
{
  Node *newNode = new Node;
  newNode->letter = elm;
  if(front == NULL)
    {
      front = newNode;
      rear = newNode;
      count++;
    }
  else
    {
      rear->next = newNode;
      rear = newNode;
      count++;
    }
}

void Queue::dequeue(el_t &elm)
{
  if(isEmpty())
    cout << "The queue is empty." << endl;
  else
    {
      if(front = rear)
	{
	  delete front;
	  front = rear = NULL;
	  count--;
	}
      else
	{
	  Node* nodePtr = front;
	  front = front->next;
	  elm = nodePtr->letter;
	  delete nodePtr;
	  count--;
	}
    }
}

void Queue::displayAll() const
{
  Node* nodePtr = front;
  while(nodePtr != NULL)
    {
      cout << nodePtr->letter << endl;
      nodePtr = nodePtr->next;
    }

}

/*
bool Queue::isFull() const
{
  if(front == 0 && rear == MAX - 1)
    return true;
  else
    return false;
}
*/
bool Queue::isEmpty() const
{
  if(count == 0)
    return true;
  else
    return false;
}
