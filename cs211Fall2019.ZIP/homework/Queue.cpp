/*******************************************************
Justin Bush
HW: 4
12/4/19
Purpose of the program: To a queue to generate all 1-character, 2-character, and 3-character strings
that can be formed using the letters A, B, and C. 

 ******************************************************/
#include<iostream>
#include"Queue.h"
using namespace std;

Queue::Queue() //default constructor
{
  front = nullptr; //sets front pointer to nullptr
  rear = nullptr; //sets rear pointer to nullptr
  count = 0; 
}

Queue::~Queue() //destructor
{
  if(front == nullptr) //if front is pointing to nullptr
    delete front; //deletes front node
  else
    {
      QueueNode *nodePtr = front; //position nodePtr to front 
      QueueNode *nextPtr; //to point to the next node
      while(nodePtr != nullptr) //while nodePtr is not at the end of the queue
	{
	  nextPtr = nodePtr->next; //traverse the queue
	  delete nodePtr; //deletes current node
	  nodePtr = nextPtr; //nodePtr points to the next node
	}
    }
}

/*
The enqueue method addes values to the rear of the queue. If the queue is full and the enqueue function is implemented, then overflow will occur, causing a seg fault. The parameter elem is used to assign node values
*/
void Queue::enqueue(el_t elem)
{
  QueueNode *newNode;
  QueueNode *nodePtr = front;
  newNode = new QueueNode; //allocate memory to a new node, called QueueNode
  newNode->letter = elem; //elem gets the value of the newNode's letter 
  newNode->next = nullptr; //newNode points to nullptr

  if(isEmpty()) //if the queue is empty
    {
      front = newNode; //front and rear of the queue are assigned to a newNode
      rear = newNode;
    }
  else
    {
      while(nodePtr->next != nullptr) //the pointer to the next node is not NULL
	{
	  nodePtr = nodePtr->next; //traverse the queue
	}
      nodePtr->next = newNode; //nodePtr points to newNode
      rear = newNode; //newNode is assigned to the rear of the queue
    }
  count++; //increment number of items in the queue
}

/*
The dequeue method means to remove a value from the front of the queue. If the queue is empty and it's being dequeued, underflow will occur. The parameter elem is used to get the value of the front element in the queue 
 */
void Queue::dequeue(el_t &elem)
{
  if(isEmpty())
    {
      cout << "Queue is empty." << endl;
      return; //return to main
    }
  else
    {
      QueueNode *nodePtr = front; //nodePtr points to the front of the queue
      elem = front->letter; //elem gets the value of the front letter in the queue
      front = front->next; //the current front value is assigned to the next element
      --count; //pre-decrement the counter
      delete nodePtr; //deletes the nodePtr
    }
}

/*
The isEmpty method is used to test if the queue is empty or not
 */
bool Queue::isEmpty()
{
  if(front == nullptr && rear == nullptr) //if both the front and rear of the queue is pointing to nullptr
    return true;
  else
    return false;
}

/*
The displayAll method is used to display everything in the queue
 */
void Queue::displayAll()
{
  QueueNode *nodePtr = front; //nodePtr points to front of the queue
  if(nodePtr == nullptr) //if nodePtr points to nullptr
    {
      cout << "Queue is empty." << endl;
    }
  while(nodePtr != nullptr) //while nodePtr isn't pointing to nullptr
    {
      cout << nodePtr->letter << " "; //cout the letter that the nodePtr is pointing to
      nodePtr = nodePtr->next; //traverses the queue
    }
  cout << endl;
}



