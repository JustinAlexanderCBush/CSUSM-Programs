/************************************
Justin Bush
***********************************/
#include<iostream>
#include"RationalNumber.h"
using namespace std;

RationalNumber::RationalNumber(int n, int d) //overloaded constructor
{
  numerator = n;
  denominator = d;
}

RationalNumber RationalNumber::operator-(const RationalNumber& r)
{
  RationalNumber temp;
  temp.numerator = (numerator * r.denominator) - (denominator * r.numerator);
  temp.denominator = denominator * r.denominator;
  return temp;
}
