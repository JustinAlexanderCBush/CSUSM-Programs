/*******************
Justin Bush
*******************/
#include<iostream>
#include"Course.h"
#include"Instructor.h" 
using namespace std;

int main()
{
  const int NUM_COURSES = 3;

  string courseName;
  long courseNum;
  int creditNum; //num of credits

  cout << "Enter course number: ";
  cin >> courseNum;
  cin.ignore(1000, '\n');
  cout << "Enter course name: ";
  getline(cin, courseName);
  cout << "Enter number of credits: ";
  cin >> creditNum;

  Course c1(courseNum, courseName, creditNum);
  c1.printCourse();

  Course c2;
  c2.printCourse();

  cout << "Enter course number: ";
  cin >> courseNum;
  cin.ignore(1000,'\n');
  cout << "Enter course name: ";
  getline(cin, courseName);
  cout << "Enter number of credits: ";
  cin >> creditNum;

  c2.setCourse(courseNum, courseName, creditNum);
  c2.printCourse();


  string firstName = "Mayssa";
  string lastName = "Najjar";
  char gender = 'F';
  long employeeID = 2390876;
  string officeNum = "ACD324";

  Course course[NUM_COURSES];
  course[0].setCourse(21540, "CS211", 3);
  course[1].setCourse(21531, "CS211", 1);
  course[2].setCourse(21531, "CS331", 3);

  Instructor i1(firstName, lastName, gender, employeeID, officeNum, course);
  i1.printInstructor();
  cout << endl;

  Instructor i2;
  i2.printInstructor();
  
  Course course2;
  cout << endl;

  firstName = "Michelle";
  lastName = "James";
  gender = 'F';
  employeeID = 2390878;
  officeNum = "SBSB3024";
  course[0].setCourse(24520, "CS111", 3);
  course[1].setCourse(24541, "CS111", 1);
  course[2].setCourse(22275, "CS351", 3);

  i2.setInstructor(firstName, lastName, gender, employeeID, officeNum, course);
  i2.printInstructor();

  return 0;
}
