#include <iostream>
using namespace std;

int main()
{
  int total = 0;
  int odd = 0;
  int input;

 cout << "Enter five integers" << endl;

 for(int i = 1; i <=5; i++)
   {
     {   
       cin >> input;
       total += input;
     }
     if(input % 2 == 1)
       {
	 odd++; //keeps track of the number of odd numbers entered
       }
   }
 cout << "Sum " << " = " << total << endl;
 cout << "There were " << odd_count << " odd numbers entered" << endl;

  return 0;
}
