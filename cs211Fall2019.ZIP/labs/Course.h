/******************************
Justin Bush
9/20/19
*****************************/
#ifndef COURSE_H //include guards for the header file
#define COURSE_H
#include<iostream>
//#include"Instructor.h"
using namespace std;

//class declaration
class Course
{
  friend class Instructor;

 private:
  long courseNumber;
  string courseName;
  int numberOfCredits;

 public:
  Course(); //default constructor
  Course(long cNum, string cName, int numCredits); //overloaded constructor to initialize the three attributes 
  void setCourse(long cNum, string cName, int numCredits);
  void printCourse() const; //accessor function, or const method
};

#endif


