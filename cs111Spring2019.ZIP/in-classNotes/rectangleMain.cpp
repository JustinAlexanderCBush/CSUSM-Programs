/************************************************
4/17/19
*************************************************/
#include <iostream>
#include "rectangle.h"
using namespace std;

int main()
{
  rectangle r1(3,5);
  cout << "Area of rectangle1: " << r1.calcArea() << endl;

  return 0;
}
