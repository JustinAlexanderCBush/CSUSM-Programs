/***********************************
Justin Bush
CS 111 Castillo
Create an array of 10 integers containing the following values (in this order): 12, -7, 3, 17, 42, 6, 18, -15, 0, 1. Create a function called seqSearch that takes a const array and an integer key as parameters, and returns the array slot number that the key was found in. If the key was not found, the function should return -1. Main should use the function to have the user enter a number and print the array slot it was found in, or that it was not found.
Test Case 1:
Enter a number to search for: <17>
17 was found in array slot 3.
Test Case 2:
Enter a number to search for: <12>
12 was found in array slot 0.
Test Case 3:
Enter a number to search for: <1>
1 was found in array slot 9.
Test Case 4:
Enter a number to search for: <40>
40 was not found.  ****Note: Should NOT say 40 was found in array slot -1!****
***********************************/
#include <iostream>
using namespace std;

int seqSearch(const int array[], int key); 

int main()
{
  int ar[] = {12, -7, 3, 17, 42, 6, 18, -15, 0, 1};
  int k = 0;    //'k' refers to the key, 
   
  cout << "Enter a number to search for: ";
  cin >> k;

  if(seqSearch(ar, k) != -1) //call the function with an if-statment and check if it is not equal to -1 b/c  
    cout << k << " was found in array slot " << seqSearch(ar, k) << endl;
  else
    cout << k << " was not found." << endl;

  return 0;
}

int seqSearch(const int array[], int key) //'key' uses pass by reference
{
  for(int i = 0; i < 10; i++)
    {
      if(array[i] == key) //if the index value is equivalent to the key value
	{
	  return i; //returns the index number that the key was found in
	}
    } 

  return -1; 
}


