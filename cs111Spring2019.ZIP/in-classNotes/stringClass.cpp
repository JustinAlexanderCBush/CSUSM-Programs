/*****************************
4/24/19
the string datatype is also technically considered as a class
 ****************************/
#include <iostream>
using namespace std;

int main()
{
  string x = "Hello World!";

  cout << x.length() << endl; //gives a numerical value of the total amount of characters and white space characters in the string x. In this case, it's 12

  return 0;
}
