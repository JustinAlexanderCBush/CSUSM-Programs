/****************************************************
Justin Bush
HW: 4
CS 211 
12/4/19
 ***************************************************/
#include<iostream>
#include"Stack.h"
using namespace std;

Stack::Stack() //default constructor
{
  top = nullptr; //top of the stack points to nullptr
}

/*
The push method adds a value onto the top of the stack. If the stack is full, a piece of data can't be placed in the stack, otherwise overflow will occur. The parameter elem will be used to pass arguments into nodes  
*/
void Stack::push(el_t elem)
{
  StackNode *newNode; //points to a new node
  newNode = new StackNode; //allocate a new node
  
  newNode->element = elem; //pass arguments into node
  newNode->next = top; //set next node to the top of the stack
  top = newNode; //newNode is assiged as the top of the stack
}

/*
The pop method removes a value from the top of the stack. The parameter elem is used to help traverse the stack
*/
void Stack::pop(el_t &elem)
{
  if(top == nullptr) //if top of the stack points to nullptr 
    {
      cout << "Error. Stack is empty, so there is nothing to pop." << endl;
    }
  else
    {
      elem = top->element; //elem is assigned as the top of the stack
      top = top->next; //traverses the stack
    }
}

/*
The isEmpty function is used to check if the stack is currently empty
*/
bool Stack::isEmpty() const
{
  if(top == nullptr) //if top points to nullptr, the stack is empty
    return true;
  else
    return false;
}



