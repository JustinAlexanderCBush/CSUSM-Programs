
#include <iostream>
using namespace std;



// Overloading : using stand alone c-function 

class ComplexNumber;
ostream& operator<<(ostream& os, const ComplexNumber& c);
istream& operator>>(istream& is,  ComplexNumber& c);

//---------------------------------------
class ComplexNumber
{
  friend ostream& operator<<(ostream& os, const ComplexNumber& c);
  friend istream& operator>>(istream& is,  ComplexNumber& c);

private:
  float   RealPortion;
  float   ImagePortion;

public:
  ComplexNumber();
  ComplexNumber(float, float);
  float GetRealPortion()  {return(RealPortion);}
  float GetImagePortion() {return(ImagePortion);}
  ComplexNumber add(ComplexNumber&, ComplexNumber&);

};

//---------------------------------------
ComplexNumber::ComplexNumber()
{
  RealPortion  = 0;
  ImagePortion = 0;

}
//---------------------------------------
ComplexNumber::ComplexNumber(float r, float i)
{
  RealPortion  = r;
  ImagePortion = i;
}

//---------------------------------------
ostream& operator<<(ostream& os, const ComplexNumber& c)
{
  os << "The value is " << "(" << c.RealPortion << "," << c.ImagePortion << ")" << endl;
  return os;
}

//---------------------------------------
istream& operator>>(istream& is,  ComplexNumber& c)
{
  is >> c.RealPortion ;
  is >> c.ImagePortion;
  return is;
}

//---------------------------------------

void main()
{
  ComplexNumbern1(1,0);         
  ComplexNumbern2(1,1);
  ComplexNumbern3;
  cout << "Exter a value of real portion ad image portion "<< endl;
  cin >> n3;
  cout << n3;
  
}


