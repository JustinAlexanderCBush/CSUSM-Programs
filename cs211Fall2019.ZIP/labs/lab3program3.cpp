/********************

 *******************/
#include<iostream>
#include<string>
#include<sstream>
using namespace std;

string removeSpace(string string1);

int main()
{
  string userInput;

  cout << "Please enter a phrase: " << endl;
  getline(cin, userInput);

  userInput = removeSpace(userInput);
  cout << "The resulting phrase is: " << userInput << endl;

  return 0;
}

string removeSpace(string string1)
{
  stringstream str1; //stringstream is an object, and str1 is a 
  string s;

  str1 << string1;
  string1 = "";

  while(!str1.eof()) //.eof, a member func
    {
      str1 >> s;
      string1 += s;
    }
  return string1;
}
