#include<iostream>
#include<vector>
#include<iomanip>
#include "Restaurant.h"
#include "Reservation.h"
using namespace std;

Restaurant::Restaurant() //default constructor for Restaurant class
{
  restaurantName = "";
  restaurantAddress = "";
  restaurantCity = "";
  for(int i = 0; i < 4; i++)
    availableSeats[i] = 0;  
}

/**************************************
Use this for the CreateNewRestaurant func in RestaurantReservatsions
***************************************/
Restaurant::Restaurant(string restName, string restAddress, string restCity, string restType, int restCapacity) //overloaded constructor for Restaurant class
{
  restaurantName = restName;
  restaurantAddress = restAddress;
  restaurantCity = restCity;
  restaurantType = restType;
  for(int i = 0; i < 4; i++) 
    availableSeats[i] = restCapacity; 
}
/************************************
I will use this printRestaurantInfo function by calling it in RestaurantReservations, and I will use the restaurants vector to print the restaurant's info
 **********************************/
void Restaurant::printRestaurantInfo() const
{
  cout << left << setw(20) << restaurantName;  
  cout << setw(20) << restaurantAddress;
  cout << setw(15) << restaurantCity;
  cout << setw(15) << restaurantType;
  cout << setw(15) << availableSeats[0] << endl;
}

/************************************
This will be used to get the name of the restaurant, that is read from the file
************************************/
string Restaurant::getName() const
{
  return restaurantName;
}

/**********************************
This will be used to get the city of the restaurant, read from the file
*********************************/
string Restaurant::getCity() const
{
  return restaurantCity;
}

/*********************************
This getter function will be used to get the type of restaurant, from the file
 ********************************/
string Restaurant::getType() const
{
  return restaurantType;
}

/************************************
This getter function will be used to get the number of seats, read from the file
 ***********************************/
int Restaurant::getSeats(int i) const
{  
  return availableSeats[i];
}

/**************************
I will use this function's information to call in in the MakeReservation function in the RestaurantReservations class. 
***************************/
void Restaurant::ReservationInfo(string cName, string cPhone, int rGroup, int rTime)
{
  Reservation temp(cName, cPhone, rGroup, rTime);  
  reservations.push_back(temp);
}

/************************************
I will call this function in the RestaurantReservations function .cpp file, to pass this information to the PrintRestaurantReservations function in the RestaurantReservations class
 ***********************************/
void Restaurant::printReservation() 
{

  cout << left << setw(12) << "Reservation";
  cout << setw(11) << "Contact";
  cout << setw(14) << "Phone";
  cout << setw(7) << "Group";
  cout << setw(7) << "Time" << endl;
  cout << "-----------------------------------------------------" << endl;

  for(int i = 0; i < reservations.size(); i++)
    reservations[i].printReservationInfo(); //printReservationInfo is in Reservation.cpp
}

