/******************
5/13/19
******************/
#include <iostream>
using namespace std;

int func1(int& n1, int& n2);

int main()
{
  int num1 = 0, num2 = 0;

  cout << "num1 and num2 are " << num1 << " " << num2 << endl;
  
  cout << "\nThe function, int func1(int& n1, int& n2) is now called, which also returns n1 + n2" << endl;
  cout << func1(num1, num2) << endl;

  cout << "num1 is now " << num1 << " and num2 is now " << num2 << endl;

  return 0;
}

int func1(int& n1, int& n2)
{
  cout << "Enter values for n1 and n2." << endl;
  cin >> n1;
  cin >> n2;
  return n1 + n2;
}
