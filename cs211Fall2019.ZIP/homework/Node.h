/*******************************************
HW 3
Justin Bush 
11/18/19

 *******************************************/
#ifndef NODE_H
#define NODE_H
using namespace std;

class LL; //forward class declaration. I can use this so I wouldn't have to include the LL.h file at the top of Node.h

class Node
{
  friend class LL; //declare class LL as a friend of class Node so public functions of LL can access a node's private attributes without having to write getters and setters for class Node

 private:
  Node *next; //ptr to the next node in the linked list
  string name, phoneNumber; //attributes of each node in the list
};

#endif
