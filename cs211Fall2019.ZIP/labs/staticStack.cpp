/***********************
In this part, you are going to design a stack of characters. Assume a simple static array implementation. Complete the code below as specified by the comments below.
 ***********************/
#include<iostream>
using namespace std;

const int MAX = 5;
typedef char el_t;// define an alias for the element type, which will be char

class Stack 
{
private:
  el_t array[MAX];// declare an array of chars with MAX slots
  int top;// and an integer to hold the index of the top element
public:
  Stack();// Write the prototype of the following public methods
  void push(el_t element);
  void pop(el_t &element);
  bool isEmpty();
  bool isFull();
  void displayAll();
};

int main()
{
  Stack s;
  char c;
  cout << " initial stack contents" << endl;
  s.displayAll();
  s.pop(c);
  s.push('a');
  cout << endl << " stack contents after pushing a: " << endl;
  s.displayAll();
  s.push('b');
  cout << endl << " stack contents after pushing b: " << endl;
  s.displayAll(); 
  s.push('c');
  s.push('d');
  s.push('e');
  s.push('f');
  s.push('g');
  cout << endl << " stack contents after pushing c-g: " << endl;
  s.displayAll();
  s.pop(c);
  cout << endl << c << endl;
  cout << endl << " stack contents after popping one element: " << endl;
  s.displayAll();
  s.pop(c);
  cout << endl << " popped element: " << c << endl;
  cout << endl << " stack contents after popping another element: " << endl;
  s.displayAll();
  s.pop(c);
  s.pop(c);
  s.pop(c);
  cout << endl << " stack contents after popping 3 more elements: " << endl;
  s.displayAll();
  s.pop(c);
  s.push('a');
  s.push('b');
  cout << endl << " final stack contents: " << endl;
  s.displayAll();
  return 0;
}

Stack::Stack() //default constructor
{
  top = -1;
}

void Stack::push(el_t element) //pushes elements into the stack
{
  if(isFull())
    cout << "Error: Overflow(can't push " << element << ")" << endl;
  else
    {
      top++; //increment top
      array[top] = element; //add element to el_t
    }
}

void Stack::pop(el_t &element)
{
  if(isEmpty())
    cout << "Error: Underflow(can't pop)" << endl;
  else
    {
      element = array[top]; //remove top element
      top--; //decrement top
    }
}

bool Stack::isEmpty()
{
  if(top == -1)
    return true;

  return false; //else
}

bool Stack::isFull()
{
  if(top >= MAX)
    {
      return true;
    }

  return false; //else
}

void Stack::displayAll()
{
  if(isEmpty())
    cout << "[ empty ]" << endl;
  else
    {
      for(int i = top; i >= 0; i--)
	cout << array[i] << endl;
    }
}
