#include<iostream>
#include<cmath> //for the floor func
using namespace std;

//--------------------------------------------
// CS311 HW2P1 Binary Search
// Name: Justin Bush
// Compiler: g++ -std=c++11
// --------------------------------------------

// x is what we are looking for in L; first and last are slot numbers 
int binarySearch(int L[], int x, int first, int last); 

int main()
{ 
  int A[10]; //MAX = 10
  int e;  // to look for this, the KEY
  int firstElem = 0;
  int lastElem = 9; //MAX - 1, or 9

  // fixed elements for A, SORTED 
  A[0] = 1; A[1]= 3; A[2]=5; A[3]= 7; A[4]=9; A[5]=11; A[6]=13;
  A[7] =15; A[8]= 17; A[9]= 19;

  cout << "What do you want to look for? ";
  cin >> e;

  // Call binarySearch here to look for e in A
  int respos = binarySearch(A, e, firstElem, lastElem);
  
  if(respos == -1) //if the element being looked for is NOT in the array 
    cout << "Element not found" << endl; 
  else 
    cout << "Found it in position " << respos + 1 << endl;
  
  return 0;  
}









int binarySearch(int L[], int x, int first, int last)
{
  int middle = floor( (first + last)/2 ); //middle of the array; average also

  if(x == L[middle]) 
    {
      cout << "comparing against an element in slot " << middle << endl;
      return middle;     
    }
  else if(x < L[middle]) 
    {
      cout << "comparing against an element in slot " << middle << endl;
      last = middle - 1; //splits the array to search for x, to closer and 
    }                    //eventually reaches x if applicable
  else if(x > L[middle]) 			
    {
      cout << "comparing against an element in slot " << middle << endl;
      first = middle + 1; //splits the array to search for x, to closer and 
    }                     //eventually reaches x if applicable 
  
   
  if(first == last && x!= L[first]) //if the first and last elements are 
    return -1;                      //equivalent, and x is NOT equal to the 
                                    //value of the first element in the array
             
  return binarySearch(L, x, first, last); //recursively call the binarySearch   
}                                         //once both if statements are finished
