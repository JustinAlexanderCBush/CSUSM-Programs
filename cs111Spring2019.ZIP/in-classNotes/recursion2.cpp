#include <iostream>
using namespace std;

int func(int n);

int main()
{
  cout << func(4) << endl;

  return 0;
}

int func(int n)
{
  if(n == 0)
    return 0;
  else
    return func(n - 1) + n;
}
/***********
func(3) + 4;
func(2) + 3;
func(1) + 2;
func(0) + 1;
func(0) -> return 0;

*Then, since func(0) returns 0, 
when n = 1, func(0) + n;        returns 0 + 1
when n = 2, func(1) + n;        returns 1 + 2

***********/
