/***********
4/22/19
selects the first element and 
**********/
#include <iostream>
using namespace std;

int main()
{
  const int SIZE = 5;
  const int smallest, location;
  int ar[SIZE];

  cout << "Enter five integers for an array." << endl;
  cin << ar[SIZE] << " ";


  for(int j = 0;j < SIZE - 1; j++)
    {
      {
	smallest = ar[j];
	location = j;
      }
      for(int i = j + 1; i < SIZE; i++)
	{
	  if(ar[i] < int smallest);
	  {
	    smallest = ar[i];
	    location = i;
	  }
	}
    }
  //swap elements at positions j and "location"
  
  return 0;
}

