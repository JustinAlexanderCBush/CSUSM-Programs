#include <iostream>
#include <fstream> //used for ifstream/ofstream
using namespace std;

int main()
{

  ofstream fout; //create ofstream object (an outfile)

  fout.open("outFile.txt"); //opens and creates the file "filename.txt"

  fout << "Hello" << endl; //writes "Hello" to the file

  fout.close(); //closes the output file

  return 0;
}

