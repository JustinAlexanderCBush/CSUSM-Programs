/******************
 Fill in the code below as indicated in the comments. This program finds the area of a rectangle using pointer variables. It also prints the rectangle dimension (length and width) in ascending order.
 *****************/
#include <iostream>
using namespace std;
int main()
{
  int length; // holds length
  int width; // holds width
  int area; // holds area
  int *lengthPtr = nullptr; // int pointer to point to length
  int *widthPtr = nullptr; // int pointer to point to width

  // prompt the user to enter length and width
  cout << "Enter the length and width of the rectangle: " << endl;
  cin >> length;
  cin >> width;

  // then make lengthPtr and widthPtr point to length & width respectively
  lengthPtr = &length;
  widthPtr = &width;

  // find and print the area using only the pointer variables
  area = *lengthPtr * *widthPtr; //here, I am multiplying the 
  cout << "Area: " << area << endl;
 
  // compare length and width using only the pointer variables
  // and print them in ascending order
  if(*lengthPtr < *widthPtr)
    cout << "Length: " << *lengthPtr << " and width: " << *widthPtr << endl;
  else 
    cout <<  "Width: " << *widthPtr << " and length: " << *lengthPtr << endl;

  return 0;
}
