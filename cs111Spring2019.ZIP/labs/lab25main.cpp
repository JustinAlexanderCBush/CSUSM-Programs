/********
Justin Bush
CS 111 Castillo
4/20/10
Modify Lab 24 to split it into 3 files, main.cpp, circle.cpp and circle.h.  Show me the statement you use to compile the program and your test runs still working.
*******/
#include <iostream>
#include "lab25.h" //includes the header file so that we know what a circle is
using namespace std;

int main()
{
  circle c1, c2; //the default constructor is called twice, because two objects, c1 and c2 were made from the "object", circle
  double r; //radius, for pass by value
  
  cout << "Enter the radius for the first circle: ";
  cin >> r;
  c1.setRadius(r);
  cout << "The radius is " << c1.getRadius() << " and the area is " << c1.calcArea()<< endl;
  
  cout << "\nEnter the radius for the second circle: ";
  cin >> r;
  c2.setRadius(r);
  cout << "The radius is " << c2.getRadius() << " and the area is " << c2.calcArea() << endl;
  
  cout << "\nHere, I have made a third circle, c3, and called it with the overloaded constructor as follows: 'circle c3(5.5)" << endl;
  //Just for how to use the overloaded constructor:
  circle c3(5.5); //c3 uses the circle(double initialRadius) function, to be usable
  cout << "The radius for c3 is passed by value, with 5: " << c3.getRadius() << " and the area of the third circle is: " << c3.calcArea() << endl;
  
  return 0;
}
