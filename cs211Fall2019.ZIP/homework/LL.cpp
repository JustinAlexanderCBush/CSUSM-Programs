/**************************************************************************
HW 3
Justin Bush
11/20/19
Purpose of the program: To manage, add, remove and print the names and phone numbers of a telephone directory. I will use a linked list and nodes to contain one name and one phone number.
 *************************************************************************/
#include<iostream>
#include"LL.h"
#include"Node.h"
using namespace std;

/*
The default constructor sets the head to nullptr. The variable head is from the LL class, and it is used to point to the beginning of the list 
*/
LL::LL() 
{
  head = nullptr; //sets the head to nullptr, or the end of the linked list (used to indicate an empty list)
}

/*
This function creates a node, sets its data to the values sent as arguments, and inserts the new node at the beginning of the linked list (before the first node). The parameters will pass the name and phone number of the people.
 */
void LL::append(string pName, string phone) 
{
  Node *newNode; //to point to a new node
  Node *nodePtr; //to move through the list

  //allocate a new node and store pName and phone there
  newNode = new Node;
  newNode->name = pName; //initialize the contents of the node with a passed name from the function
  newNode->phoneNumber = phone; //initialized the node with a passed phone number from the function
  newNode->next = nullptr; //set the pointer field to nullptr

  if(!head) //if there are no nodes in the list
    head = newNode; //head is assigned as the newNode
  else //otherwise, insert newNode at end
    {
      nodePtr = head; //initialize nodePtr to head of list
      while(nodePtr->next) //find last node in list
        nodePtr = nodePtr->next; //nodePtr points to the next node

      nodePtr->next = newNode; //insert newNode as last node
    }
}

/*
This function reads data from two different arrays, with information including names and phone numbers. It will then place a name and phone number into a corresponding node. The parameters are both of the arrays, to pass the information to the node, and the size variable is used to pass the size of the for loop.
 */
void LL::readFromArrays(string nArr[], string pArr[], int size)
{
  Node *nodePtr; //to move through the list
  nodePtr = head;

  for(int i = 0; i < size; i++) //reads through both arrays
    append(nArr[i], pArr[i]); //call append function, passing the name array and phone array information
}

/*
This function creates a node, initializes its data to the values sent as arguments, and inserts it to properly manage the order of the linked list. I declare three pointers: newNode, nodePtr and nodePtr2. The newNode pointer is used to insert the newly declared data into the linked list. The nodePtr is used to traverse the linked list, and the nodePtr2 is to be compared to the newNode. 
 */
void LL::insert(string pName, string phone)
{
  Node *newNode; //new node to be inserted
  Node *nodePtr; //to traverse the list  
  Node *nodePtr2; //to be compared to the newNode

  nodePtr = head->next; //move to the next node
  nodePtr2 = head; //position nodePtr2 at the head of the list
  newNode = new Node;//allocate memory for a new node
  newNode->name = pName; //initialize contents of the node to pName
  newNode->phoneNumber = phone; //initialize contents of the node to phone
  newNode->next = nullptr; //set pointer field to nullptr

  if(head == nullptr) //if there aren't nodes in list, make newNode first
    {
      head = newNode; //set head to the newNode
      newNode->next = nullptr; //set pointer field to nullptr
    }
  else if(newNode->name < nodePtr2->name) //else if, the name in the node is positioned alphabetically lower than nodePtr2's name
    {
      head = newNode; //position nodePtr at head of list
      newNode->next = nodePtr2; //initialize newNode to nodePtr2
    }
  else
    {
      while(nodePtr) //while nodePtr points to a node
	{
	  if(newNode->name < nodePtr->name) //if, the name in the node is positioned alphabetically lower than nodePtr2's name
	    {
	      nodePtr2->next = newNode;
	      newNode->next = nodePtr;
	    }
	  nodePtr = nodePtr->next;
	  nodePtr2 = nodePtr2->next;
	  if(nodePtr2->next == nullptr) //if nodePtr2 is pointing at NULL
	    append(pName, phone); //call append function with pName and phone as parameters
	}
    }
}

/*
This function creates a node, initializes its data to the values sent as arguments, and inserts it at position, denoted by the pos variable, in the list. If the position is 1, insert it as the first node. The strings pName and phone are used to pass the the values from main.
 */
void LL::insertAtPos(string pName, string phone, int pos)
{
  Node *newNode;
  Node *nodePtr;  
 
  //allocate a new node and store pName and phone
  newNode = new Node;
  newNode->name = pName; //store the value of pName in the node
  newNode->phoneNumber = phone; //store the value of phone in the node
  newNode->next = nullptr; //the newNode points to nullptr

  if(pos == 1) //if position is equivalent to one,
    {
      newNode->next = head; 
      head = newNode; //the first node is newNode
      return; //return to main
    }

  nodePtr = head; //position nodePtr at the head, or first node of the list
  for(int i = 1; i < pos - 1; i++)
    nodePtr = nodePtr->next;

  newNode->next = nodePtr->next; //traverse the list
  nodePtr->next = newNode; //next node gets the value of newNode
}

/*
//This function prints out the linked list
 */
void LL::print() 
{
  Node *nodePtr; //to move through list
  nodePtr = head; //position nodePtr at head of list

  int i = 0; //
  while(nodePtr) //while nodePtr points to a node, traverse the list
    {
      i++; //increment i
      //display phone numbers in this node     
      cout << i << " " <<  nodePtr->name << " " << nodePtr->phoneNumber << endl;
      nodePtr = nodePtr->next; //move to next node
    } 
}

/*
This func prints each node's data in reverse order
 */
void LL::printReverse() 
{
  reverse(); //call reverse function

  int i = 0;
  while(head) //while head pointer can point to a node
    {
      i++; //increment the nth number of the node's information
      cout << i << " " << head->name << " " << head->phoneNumber << endl;
      head = head->next; //the head points to the next node
    }
}

/*
This function searches for a particular person’s record in the list, whose name is pName. If it finds a record, and prints the node number in the list. The variable pName is used to pass the names of the nodes of the list as they are being traversed */
void LL::searchByName(string pName) 
{
  bool search = false;
  Node *nodePtr = head; //to move through list

  while(nodePtr != nullptr) //while nodePtr doesn't point to the end of the list, traverse the list
    {
      if(nodePtr->name == pName) //if 
	{
	  int i = 0;
	  while(nodePtr) //while nodePtr points to a node
	    {
	      i++;
	      cout << i <<  pName << " " << nodePtr ->phoneNumber << endl;
	      search = true;
	    }
	  nodePtr = nodePtr->next; //increments to next node
	}
      if(search == false)
    cout << "Error. " << pName << " couldn't be found." << endl; 
    }
}

/*
This function updates a specific person's record. The strings pName and newPhone are used to check if one's name is equivalent to name, from the Node class, and newPhone is the updated number of the corresponding person. 
 */
void LL::updateNumber(string pName, string newPhone)
{
  bool search = false;
  Node *nodePtr; //node pointer, to move through the list
  Node *previousNode;
  Node *newNode;
  
  previousNode = nullptr;

  nodePtr = head; //position nodePtr at the head of the list
  while(nodePtr != nullptr) //while nodePtr doesn't point to the end of the list, 
    {
      if(nodePtr->name == pName) //if the name in the node is equialent to the name passed,
	{
	  nodePtr->phoneNumber = newPhone; //nodePtr points to newPhone
	  search = true;
	}
      nodePtr = nodePtr->next; //nodePtr points to the next node in the list
    }

  if(search == false)
    cout << "Error. " << pName << " was not found." << endl;
}

/*
This function searches for a specific person’s record, whose name is pName, and removes it from the list if it exists. 
 */
void LL::removeRecord(string pName)
{
  Node *currentNode;
  Node *previousNode;
  
  currentNode = head->next; //
  previousNode = head; //
 
  if(head == nullptr) //if head doesn't point to any nodes
    {
      cout << "List is empty." << endl;
      return; //return to main
    }

  if(head->name == pName)
	{
	  head = currentNode; //the current node is now the starting node in the linked list
	  delete previousNode; // deletes the previous node in the list
	  return; //return to main
	}

  while(currentNode)
    {
      if(currentNode->name == pName)
	{
	  previousNode->next = currentNode->next;
	  delete currentNode;
	  return;
	}
      previousNode = currentNode;
      currentNode = currentNode->next;
    }
  cout << "Error." << pName << " was not found." << endl;
}

/*
The destructor deletes all nodes in the list and assigns the head to equal NULL. It will also call the destory() function, which actually performs the deleting
 */
LL::~LL()
{
  destroy(); //called destroy() function
}

/*
To be called inside of the destructor
 */
void LL::destroy()
{
  Node *nodePtr; //to traverse the list
  Node *nextNode; //to point to the next node
  Node *previousNode; //to point to the previous node 

  nodePtr = head; //position nodePtr at head of list

  while(nodePtr != nullptr) //while nodePtr is not at the end of list
    {
      nextNode = nodePtr->next; //save a point to next node
      delete nodePtr; //delete current node
      nodePtr = nextNode; //position nodePtr at next node
    }
}

/*
This is a copy constructor, which performs a deep copy of list, named source
 */
LL::LL(const LL &source) 
{
  Node *nodePtr; 
  nodePtr = nullptr; //nodePtr
  head = nullptr;
  nodePtr = source.head;

  while(nodePtr) //while nodePtr exists
    {
      append(nodePtr->name, nodePtr->phoneNumber);
      nodePtr = nodePtr->next; //nodePtr points to next node in the linked list
    }
}

/*
Overloads the assignment operator to perform a deep copy of the list, named source.
 */
LL& LL::operator=(const LL &source)
{
  Node *nodePtr;// = head;
  Node *nodePtr2; //= source.head;
  Node *newNode;

  destroy(); //call destory() func
  head = nullptr;
  nodePtr = source.head;

  while(nodePtr) //while nodePtr2 can point to a node in the linked list
    {
      append(nodePtr->name, nodePtr->phoneNumber);
      nodePtr = nodePtr->next;
    }
}

/*
This function rearranges all nodes in list so their order is reversed, in descending order.
 */
void LL::reverse()
{
  Node *currentNode = nullptr;
  Node *previousNode = nullptr;
  Node *nextNode = nullptr;

  currentNode = head;

  if(head == nullptr);
  while(currentNode != nullptr) //while currentNode is not equal to nullptr
    {
      nextNode = currentNode->next;
      currentNode->next = previousNode;
      previousNode = currentNode;
      currentNode = nextNode;
    }
  head = previousNode;
}


