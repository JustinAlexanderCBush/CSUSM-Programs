/******************************
5/12/19
*****************************/
#include <iostream>
using namespace std;

int x = 5;

int func1(int n1);
void func2(int& n1, int n2);

int main()
{
  int num1, num2;
  num1 = 2;
  num2 = func1(3);

  cout << "num1 is " << num1 << " and num2 is " << num2 << endl;

  func2(num1, num2);

  x++;

  cout << "num1 is " << num1 << ", num2 is " << num2 << " and x is " << x << endl;

  return 0;
}

int func1(int n1)
{
  return n1 * 3;
}

void func2(int& n1, int n2)
{
  int x = 0;

  n2++;
  n1 = 5 + n2;
  x++;

  cout << "n1 is " << n1 << ", n2 is " << n2 << " and x is " << x << endl << endl;
}
