/***************************************************

 ******************************************/
#ifndef RESTAURANTRESERVATIONS_H
#define RESTAURANTRESERVATIONS_H
#include<vector>
#include"Restaurant.h"
#include"Reservation.h"
using namespace std;

class RestaurantReservations
{
 private:
  vector<Restaurant> restaurants; //list of local restaurants

 public:
  RestaurantReservations();
  void ProcessTransactionFile(string fileName);
  void CreateNewRestaurant(string rName, string rAddress, string rCity, string rType, int rCapacity);
  void PrintAllRestaurants() const;
  void FindTable(string rCity, string rType, int rGroup, int rTime);
  void FindTableAtRestaurant(string rName, int rGroup);
  void MakeReservation(string rName, string cName, string cPhone, int rGroup, int rTime);
  void PrintRestaurantReservations(string rName);
};

#endif
