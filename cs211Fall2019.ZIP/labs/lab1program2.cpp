/********************************************************************************
Justin Bush 
CS 211 8/28/19

Modify program 1 to include a function getEndBalance that computes the ending balance of a savings account. The function takes three arguments that hold the starting balance, total deposits, total withdrawals and returns the ending balance. The ending balance is printed in main. 
********************************************************************************/
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

double getEndBalance(string acctType, double startBal, double totalDeposited, double totalWithdrawals);

int main()
{
  const double premiumIntRate = 0.05;
  const double choiceIntRate = 0.03;
  const double basicIntRate = 0.01;

  string accountNum, accountType;
  double startBalance, deposited, withdrawn, endBalance; 

  ifstream fin;
  ofstream fout;

  fin.open("accounts.txt");

  if(!fin) //OR if(fin == NULL)   means, if the file doesn't exist
    cout << "Cannot open the input file" << endl;
  else //the input file exists
    {
      fout.open("accountsOutfile.txt"); //*** THIS IS IMPORTANT TO HAVE!!!!!!!!
      fout << left << setw(10) << "Account" << setw(10) << "Type" << setw(15) << "StartBalance" << setw(10) << "Deposit" << setw(15) << "Withdrawal" << setw(15) << "EndBalance" << endl;
      fout << "------------------------------------------------------------------------" << endl;
      
      fin >> accountNum >> accountType >> startBalance >> deposited >> withdrawn; //reads the first pieces of data  
      
      while(fin) //data was read successfully
	{
	  endBalance =  getEndBalance(accountType, startBalance, deposited, withdrawn); //REMEBER: to use a function with a data type, initialize a variable in main - 'endBalance' in this case, and set it equal to the function call
	 
	  fout << left << setw(10) << accountNum << setw(10) << accountType << setw(15) << fixed << setprecision(2) << startBalance << setw(10) << deposited << setw(15) << withdrawn << setw(15) << fixed << setprecision(2) << endBalance << endl;

	  fin >> accountNum >> accountType >> startBalance >> deposited >> withdrawn; //reads the next pieces of data. When the file can't read anymore data, the while loop stops and exits
	}      
    }

  fin.close();      
  fout.close();

  return 0;
}

double getEndBalance(string acctType, double startBal, double totalDeposited, double totalWithdrawals)
{
  double calculatedEndBalance = 0;
  if(acctType == "Premium")
    calculatedEndBalance = (startBal + totalDeposited - totalWithdrawals) * (1 + premiumIntRate);
  else if(acctType == "Choice")
    calculatedEndBalance = (startBal + totalDeposited - totalWithdrawals) * (1 + choiceIntRate);
  else //accoutType == "Basic"
    calculatedEndBalance = (startBal + totalDeposited - totalWithdrawals) * (1 + basicIntRate);

  return calculatedEndBalance;
}
