/*************************************
Justin Bush
CS 211 Castillo
Write a program that creates an empty vector of strings called V. Vector V grows and shrinks as the user processes commands from a data file called “vectorData.txt”. Each line in the transaction file contains a command and the corresponding data. 

The transaction file can only include three types of commands: Insert, Delete, and Print.
• Insert command inserts a string value in the vector at a specific position. So the Insert command comes with two more information, the string you need to insert and the position it should be inserted at. For example, the first line indicates that the word “Hello” should be inserted in V[4]. You should check if this insert is possible. It is possible if the position you are attempting to insert the element is a positive number not beyond the size of the vector.
• Delete command deletes the element at the specified position. So Delete comes with one more information that indicates which element (index) should be deleted. For example, The second line means V[5] should be removed. Again this operation should only be allowed if the index is positive and not beyond the current size of the vector.
• Print command prints the contents of the vector on the screen.

Sample Output:
Welcome CS211 Students Very Good Job
Note: Each command must be implemented in a separate function.
*************************************************/
#include<iostream>
#include<vector>
#include<fstream>
#include<string>
using namespace std;
void print(vector<string> V);

int main()
{
  vector<string> V; //declared an empty string vector named "V"
  string command; //what we need to do with the vector
  string output; //refers to a certain command's corresponding data, such as "Student" or "CS211"
  int position;  //the number after every command and/or output

  ifstream fin; //object oriented class
  fin.open("vectorData.txt");

  if(!fin)
    cout << "The file doesn't exist.";
  else
    {
      while(fin>>command) //while the file exists, and can read the data
	{
	  if(command == "Delete")
	    {
	      fin >> position;
	      if(position < 0 || position > V.size());
	      else
		V.erase(V.begin() + position); //checks from beginning of vector to the position given
	    }
	  else if(command == "Insert")
	    {
	      fin >> output >> position;
	      if(position < 0 || position > V.size());
	      else
		V.insert(V.begin() + position, output);  
	    }
	  else if (command == "Print")
	    {
		{
		  print(V); 
		}
	      cout << endl;
	    }
	   
	}
    }
  
  fin.close(); //closes the input file "vectorData.txt"
  
  return 0;
}

void print(vector<string> V)
{
  for(int i = 0; i < V.size(); i++)
    cout << V[i] << " "; //this outputs the output variable, which is already stored in the vector 
  cout << endl;
}
