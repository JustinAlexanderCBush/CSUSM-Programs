/********
Justin Bush
CS 111 Castillo
4/20/10
Modify Lab 24 to split it into 3 files, main.cpp, circle.cpp and circle.h.  Show me the statement you use to compile the program and your test runs still working.
*******/
#include <iostream> 
#include "lab25.h"
using namespace std;

void circle::setRadius(double passedRadius)
{
  if(passedRadius >= 0)
    radius = passedRadius;
  else
    cout << "Error. Radius cannot be negative." << endl;
}

double circle::getRadius()
{
  return radius;
}

double circle::calcArea()
{
  return pi * (radius * radius);
}

circle::circle() //default constructor (no parameters)
{
  cout << "Called default constructor of the circle; means two objects from the class 'circle' was used in the main." << endl;
  cout << "Also, radius = 0" << endl;
  radius = 0;
}

circle::circle(double initialRadius) //constructor with a parameter for the initial radius
{
  cout << "Called overloaded constructor of rectangle, and setRadius(initialRadius) is called now." << endl;
  setRadius(initialRadius);
}

