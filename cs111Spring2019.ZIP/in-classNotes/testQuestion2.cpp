/*****************************************************************
1                      
2   4  
3   6   9
4   8   12  16
5   10  15  20  25   Make a complete c++ program that will print this information
***************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  int ar[5][5];

  for(int row = 1; row <= 5; row++)
    {
      for(int col = 1; col <= row; col++) //'col' refers to the column
	{
	  cout << left << setw(3) << row * col;
	}
      cout << endl;
    }
  
  return 0;
}
