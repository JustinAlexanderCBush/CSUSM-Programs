/**************************************
4/15/19
**************************************/
#include <iostream>
using namespace std;

class rectangle
{
private: //*******THINK PRIVATE VARIABLES, AND PUBLIC FUNCTIONS
  int width, length;
  
public:

  ~rectangle()
  {
    cout << "Rectangle destructor called. " << endl;
  }

  rectangle(int initialWidth, int initialLength)
  {
    cout << "Called overloaded constructor of rectangle." << endl;
    setWidth(initialWidth); 
    setLength(initialLength);
  }

  rectangle() //default constructor
  {
    cout << "Called default constructor of rectangle. " << endl;
    width = 0;
    length = 0;
  }

  void setWidth(int passedWidth)
  {
    if(passedWidth >= 0)
      width = passedWidth;
    else
      cout << "Error. Width cannot be negative." << endl;
  }

  void setLength(int passedLength)
  {
    if(passedLength >= 0)
      length = passedLength;
    else
      cout << "Error. Length cannot be negative." << endl;
  }

  int getWidth()
  {
    return width;
  }

  int getLength()
  {
    return length;
  }

  int calcArea()
  {
    return length * width;
  }
};

int main()
{
  rectangle r1(3,5);
  cout << "Area of rectangle1: " << r1.calcArea() << endl;

  return 0;
 }
