/**********
4/22/19
Bubble sort compares two things, and sees if they're in order or not 
It goes through the whole array, and we use a boolean variable to 
*********/
#include <iostream>
using namespace std;

const int SIZE = 5;

int main()
{
  int ar[SIZE];

  cout << "Enter five numbers into an array." << endl;
  for(int i = 0; i < SIZE; i++)
    {
      cin >> ar[SIZE];
      //cout << " ";
    }

  bool flag = true;
  while(flag == true) //OR while(flag)
    {
      flag = false;
      {
	for(int i = 0; i < SIZE - 1; i++)
	  {
	    if(ar[i] > ar[i+1])
	      {
		//supplement ar[i] with element ar[i+1]
		flag = true;
	      }
	  }
      }
    }
  
  return 0;
}
