#include <iostream>
using namespace std;

int add(int x);

int main()
{
  int data = 10;
  
  data = add(data); //passing data in add func
  cout << "Value in data = " << data << endl;

  return 0;
}

int add(int x)
{
  int input; //variable to store the input number

  cout << "Enter the value to be added in data: ";
  cin >> input;
  x += input; //same thing as x = x + input
  return x;
}
