// CS311 Yoshii - girl header with doit function
// ---------------------------------------------------
using namespace std;

class girl
{
 private: 
   int g_id;

 public:
  girl();
  ~girl();
  void doit();  // girl's doit
}; 
