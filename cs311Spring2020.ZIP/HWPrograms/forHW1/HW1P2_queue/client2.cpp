//CS311 Yoshii
//INSTRUCTION:
//Look for ** to complete this program 
//The string output should match my hw1queueDemo.out 

//=========================================================
//HW#: HW1P2 queue application (generate all strings)
//Your name: Justin Bush
//Complier:  g++ -std=c++11
//File type: client program client2.cpp
//===========================================================

using namespace std;
#include <iostream>
#include <stdlib.h>
#include <string>
#include "queue.h"

//Purpose of the program: To display different combinations of the strings "A", 
//"B" and "C" using the data structure of a queue 
//Algorithm: First, I made an instantiation of the queue class with the instance of the queue class called theQueue. I used the add function in the queue.h header file to add the elements A, B and C. While the queue is indefinite, if the queue is NOT empty, remove the front element in the queue, display that most recently removed element, and then add the strings, "A", "B" and then finally "C" to said element. Then, use the Overflow class in the queue.h header file to display the 
//error message, when the queue eventually gets full.  

int main()
{ 
  // ** "A", "B", "C" in the queue
  queue theQueue;     //instantiation of the queue class 
  theQueue.add("A");  //theQueue is the instance of the queue class
  theQueue.add("B");  //adding the strings, "A", "B" and "C"
  theQueue.add("C");

  while(0 == 0) //while loop -- indefinitely 
    {           
      try
	{  
	  el_t anElem; //an element of the queue, using the typedef alias, el_t
	  if(!theQueue.isEmpty())     //if the queue is NOT empty
	    theQueue.remove(anElem);  //remove the first element from the 
	                              //front of the queue
	  cout << anElem << endl; //display the front element that was removed
      
	  if(!theQueue.isFull()) //if the queue is NOT full,
	    {
	      theQueue.add(anElem + "A"); //add the recently removed string 
	      theQueue.add(anElem + "B"); //to the strings "A", "B" and "C"
	      theQueue.add(anElem + "C");
	    }
	}
      
      catch(queue::Overflow)
	{
	  cerr << "ERROR: The queue has too many elements." << endl;
	  exit(1); // reports the operating system that the program is not 
	           //successfully executed, or it is aborted in between the 
	           //execution due to some or the other error.
	}

    }// end of loop
  
  return 0;
}

