#include <iostream>
using namespace std;

int main()
{
  int x = 3;
  int y = 6;
  int z = 0;

  cout << "x" << is << x << ", y is " << y << " and z is " << z << endl;

  x = x + 3;
  cout << "Now, x = x + 3, so x is" << x << endl;

  

  return 0;
}
