#include<iostream>
#include"Course.h"
using namespace std;

int main()
{
  Course *courseptr[3];
  for(int i = 0; i < 3; i++)
    courseptr[i] = new Course; //

  cout << "Course 1\n" << "---------------------------------" << endl;
  courseptr[0]->setCourse(70503, "CS211", 4); //-> (arrow) operator are used to reference individual members of classes, structures, and unions
  courseptr[0]-> printCourse();

  cout << "Course 2\n" << "---------------------------------" << endl;
  courseptr[1]->setCourse(70507, "CS231", 4);
  courseptr[1]-> printCourse();

  cout << "Course 3\n" << "---------------------------------" << endl;
  courseptr[2]->setCourse(70509, "CS331", 3);
  courseptr[2]-> printCourse();
  cout << endl;

  for(int i = 0; i < 3; i++)
    {
      delete courseptr[i];
      courseptr[i] = NULL;
    }

  return 0;
}
