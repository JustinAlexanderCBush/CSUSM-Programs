/********************************************************************************
Justin Bush
CS 111 Castillo
This program will ask the user to enter two integer numbers, then tells the user: the sum of the numbers, the difference of the numbers (first minus second), the product of the numbers, and the quotient of the numbers with remainder.  
 *******************************************************************************/
#include <iostream> 
using namespace std;

int main ()
{
  int n1, n2; //"n1" and "n2" represents the first and second integers
  cout << "Enter an integer: ";
  cin >> n1;
  cout << "Enter another integer: ";
  cin >> n2;

  int sum = n1 + n2;
  cout << n1 << "+" << n2 << "=" << sum << endl;
  
  int subtraction = n1 - n2;
  cout << n1 << "-" << n2 << "=" << subtraction << endl; 

  int multiplication = n1 * n2;
  cout << n1 << "*" << n2 << "=" << multiplication << endl;

  int division = n1 / n2, remainder = n1 % n2;    
  cout << n1 << "/" << n2 << "=" << division << "r" << remainder << endl;

  return 0;
}
