//Include guards - prevents including the header more than once
#ifndef RECTANGLE_H //if RECTANGLE_H is NOT defined
#define RECTANGLE_H //#define RECTANGLE_H  and include everything between 
                    //#ifndef and #endif.

class rectangle //ONLY EVERYTHING IN CLASS BRACKETS IS THE HEADER file(rectangle.h)
{
 private: //*******THINK PRIVATE VARIABLES, AND PUBLIC FUNCTIONS
  double width, length;

 public:
  ~rectangle();
  rectangle(double initialWidth, double initialLength); //constructor with parameters for length and width
  rectangle(); //default constructor
  void setWidth(double passedWidth);
  void setLength(double passedLength);
  double getWidth();
  double getLength();
  double calcArea();

};

#endif //end of the include guards
