#include <iostream>
using namespace std;

int main()
{
  int ar[5];

  for(int i = 0; i < 5; i++)
    {
      ar[i]= i + 1;
      cout << ar[i] << " " << endl;
    }

  return 0;
}
