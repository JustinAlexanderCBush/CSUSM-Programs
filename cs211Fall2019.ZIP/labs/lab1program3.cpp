
/********************************************************************************
Justin Bush 
CS 211 8/28/19

Write a function minMaxAvg that calculates and returns the minimum, maximum, and average of three integers. Then write a main program to test your function.

Your main program should:
- ask the user to enter three integers,
- calls the function minMaxAvg to compute the minimum, maximum and average of the three entered integer values,
- print the minimum, maximum, and average (minimum, maximum, average need to be sent by reference). 

Sample run:

Please enter 3 numbers: 100 80 92
The average is: 90.66
The min is: 80
The max is: 100
********************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

void minMaxAvg(int num1, int num2, int num3, double& avg, int& min, int& max); 

int main()
{
  int n1, n2, n3; //numbers the user will enter
  int minimum, maximum;
  double average;

  cout << "Please enter 3 numbers: ";
  cin >> n1 >> n2 >> n3;
 
  minMaxAvg(n1, n2, n3, average, minimum, maximum);
  cout << "The average is: " << fixed << setprecision(2) << average << endl;
  cout << "The min is: " << minimum << endl;
  cout << "The max is: " << maximum << endl;
  
    
  return 0;
}

void minMaxAvg(int num1, int num2, int num3, double& avg, int& min, int& max)
{
  if(num1 < num2)
    min = num1;
  else
    min = num2;
  
  if(num3 < min) //this if statement FORCES the compiler to check said statement, and see if it is true or not
    min = num3;
  


  if(num1 > num2)
    max = num1;
  else
    max = num2;

  if(num3 > max) //this if statement FORCES the compiler to check said statement, and see if it is true or not
    max = num3;

  avg = (double)(num1 + num2 + num3)/3;
} 
