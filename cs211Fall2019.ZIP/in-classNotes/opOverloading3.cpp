#include<iostream>
using namespace std;


class MyIncreEx;
istream& operator>>(istream& is, MyIncreEx& s);
ostream& operator<<(ostream &os, MyIncreEx& s);
MyIncreEx operator++(MyIncreEx& d, int dummy);
MyIncreEx operator++(MyIncreEx& d);

class MyIncreEx
{
  friend istream& operator>>(istream& is, MyIncreEx s);
  friend ostream& operator<<(ostream& os, MyIncreEx s);
  friend MyIncreEx operator++(MyIncreEx& d, int dummy); //post-fix ex: x++;
  friend MyIncreEx operator++(MyIncreEx& d); //pre-fix ex: ++x;

public:
  MyIncreEx(){num1=0; num2=0; num3=0;};

  int num1;
  int num2;
  int num3;
};

//------------------------------------------------
istream& operator>>(istream& is, MyIncreEx& s)
{ 
  is >> s.num1;
  is >> s.num2;
  is >> s.num3;
  return is; 
};

//------------------------------------------------
ostream& operator<<(ostream &os, MyIncreEx& s) 
{ 
  os << "(" << s.num1 <<"," <<s.num2 << "," << s.num3 <<")"<< endl;
  return os; 
};

//------------------------------------------------
MyIncreEx operator++(MyIncreEx& d) //pre-fixex: ++x;
{ 
  d.num1=d.num1+1;
  d.num2=d.num2+1;
  d.num3=d.num3+1;

  return d; 
};
//------------------------------------------------

MyIncreEx operator++(MyIncreEx& d, int dummy) //post-fix ex: x++;
{ 
  d.num1=d.num1+1;
  d.num2=d.num2+1;
  d.num3=d.num3+1;
  return d; 
};

//------------------------------------------------
void main()
{
  MyIncreEx obj;

  cout << "please enter three numbers: ";
  cin  >> obj;
  cout << "The original value are: ";
  cout << obj;
  cout << endl;
  obj++;
  cout << "The new values after obj++ are: ";
  cout <<  obj;
  cout << endl;
  ++obj;
  cout << "The new values after ++obj are: ";
  cout << obj;
  cout << endl;

}
//------------------------------------------------
