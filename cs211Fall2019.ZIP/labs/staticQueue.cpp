//In this part, you are going to design a static queue of characters implemented as an array of 5 characters. Complete the code below as specified by the comments in bold.
#include<iostream>
using namespace std;

// define aliases for element type and queue size
const int MAX = 5; //max num of elements
typedef char el_t; //el_t is an alias for int for now

class Queue 
{
private:
  el_t el[MAX]; // declare array to hold queue elements,
  int front, rear; // integers to hold front and rear positions,
  int count; // and another integer to keep track of the number of items in Queue
public:
  // Write the prototype of the Constructor, enqueue, dequeue, isFull, isEmpty, displayAll
  Queue(); //default constructor
  void enqueue(el_t elem);
  void dequeue(el_t &elem);
  bool isFull()const;
  bool isEmpty()const;
  void displayAll()const;
};

int main ()
{
  Queue q;
  el_t c;
  cout << " initial Queue contents" << endl;
  q.displayAll();
  q.dequeue(c);
  q.enqueue('a');
  cout << endl << " Queue contents after adding a: " << endl;
  q.displayAll();
  q.enqueue('b');
  q.enqueue('c');
  q.enqueue('d');
  q.enqueue('e');
  q.enqueue('f');
  cout << endl << " Queue contents after adding b-f: " << endl;
  q.displayAll();
  q.dequeue(c);
  cout << endl << c << endl;
  cout << endl << " Queue contents after removing one element: " << endl;
  q.displayAll();
  q.dequeue(c);
  cout << endl << " Removed element: " << c << endl;
  cout << endl << " Queue contents after removing another element: " << endl;
  q.displayAll();
  q.enqueue('g');
  q.enqueue('h');
  q.enqueue('i');
  cout << endl << " Queue contents after adding g, h, i: " << endl;
  q.displayAll();
  q.dequeue(c);
  q.dequeue(c);
  q.dequeue(c);
  q.dequeue(c);
  cout << endl << " Queue contents after removing 4 elements: " << endl;
  q.displayAll();
  q.dequeue(c);
  q.dequeue(c);
  cout << endl << " final Queue contents: " << endl;
  q.displayAll();
  
  return 0;
}

Queue::Queue()
{
  rear = -1;
  front = -1;
  count = 0;
}

void Queue::enqueue(el_t elem)
{
  if(isFull())
    cout << "Error: Overflow - cannot enqueue " << endl;
  else if(isEmpty())
    {
      front = (front + 1) % MAX;
      rear = (rear+1) % MAX;
      el[rear] = elem;
      count++;
    }
  else
    {
      rear = (rear + 1) % MAX; //calculate new rear position
      el[rear] = elem; //insert new item
      count++; //update item count
    }
}

void Queue::dequeue(el_t &elem)
{
  if(isEmpty())
    cout << "Error: Underflow - cannot deqeue" << endl;
  else
    {
      elem = el[front]; //retrieve the front item
      front = (front+1) % MAX;
      count--; //update item count
    }
}

bool Queue::isFull()const
{
  if(count == MAX)
    return true;
  else
    return false;  
}

bool Queue::isEmpty()const
{
  if(count == 0)
    return true;
  else
    return false;
}
  
void Queue::displayAll()const
{
  if(!isEmpty())
    {
      int i=front%MAX;
      while(i!=rear)
	{
	  cout << el[i] << endl;
	  i = (i+1) % MAX;
	}
      cout << el[i] << endl;
    }
  else
    cout << "[empty]" << endl;
}
