/************************
Justin Bush
************************/
#include<iostream>
#include"RationalNumber.h"
using namespace std;

int main()
{
  RationalNumber r1(7,3), r2(3,9), r3, r4;

  r3 = r1 - r2;
  cout << r3 << endl;
  r3 = r1++;
  cout << r3 << endl;
  cout << r1 << endl;
  cout << "Enter r4" << endl;
  cin >> r4;
  cout << r4 << " is the number entered" << endl;

  return 0;
}

ostream& operator <<(ostream& os, const RationalNumber& r)
{
  os << "this is the fraction: " << r.numerator << "/" << r.denominator; 
  return os;
}


istream& operator >> (istream& is, RationalNumber& r)
{
  is >> r.numerator;
  is >> r.denominator;
  return is;
}

RationalNumber operator++(RationalNumber& r, int dummy) //dummy means the function knows prefix vs postfix
{
  RationalNumber r3;
  r3 = r; 
  r.numerator += r.denominator; //because the overloaded operator++ adds 1 to the rational number
  return r3;
}




