#include <iostream>
using namespace std;

int main()
{
  int x = 3;
  int y = 4;
  int z = 5;

  cout << "x equals 3, y equals 4, and z equals 5." << endl;
  cout << "Now, I will set x as:  x = x + y  OR   x += y" << endl;
  x += y;
  cout << "x equals: " << x;

  cout << "\nNow, I will set z as:  z = x + y + 6" << endl;
  z = x + y + 6;

  cout << "Now, I will print the z variable to the screen. Z equals " << z << endl;  

  return 0;
}
