#include <iostream>
using namespace std;

void triple_ar(const int x[]);

int main()
{
  int y[5] = {2, 4, 6, 8, 10};
  triple_ar(y); //just provide the name of the array, NOT the data type and/or the "[]"s 

  for(int i = 0; i < 5; i++)
    cout << y[i] << endl;

  return 0;
}

void triple_ar(const int x[]); //arrays are automatically passed by reference, & not needed 
{
  for(int i = 0; i < 5; i++)
    cout << 3 * x[i] << endl;
}
