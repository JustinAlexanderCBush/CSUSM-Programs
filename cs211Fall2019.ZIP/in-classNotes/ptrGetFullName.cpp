#include<iostream>
#include<string>
string *getFullName (string fullName[]);

int main()
{
string 

  string *getFullName (string fullName[]);

  return 0;
}

string *getFullName (string fullName[])
{
  cout << “Enter first Name”;
  getline (cin, fullName[0]);
  cout << “Enter first Name”;
  getline (cin, fullName[1]);
  cout << “Enter first Name”;
  getline (cin, fullName[2]);
  return fullName;
}
