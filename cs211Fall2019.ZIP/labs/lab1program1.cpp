/********************************************************************************
Justin Bush 
CS 211 8/28/19

Write a program that calculates the ending balance of several savings accounts. The program reads information about different customers’ accounts from an input file, “accounts.txt”. Each row in the file contains account information for one customer. This includes: the account number, account type (premium, choice, or basic account), starting balance, total amount deposited, and total amount withdrawn.

Your program should:
- open the file and check for successful open,
- then calculate the ending balance for each customer account. The calculated data must be saved in an output file, “accountsOut.txt”, in a neat format as shown below. You may assume that the interest is 5% for premium accounts, 3% for choice accounts, and 1% for basic accounts. 

You MUST use a named constant for the interest rates. Since the results displayed are monetary values, your output must be displayed with two decimal places of precision. Be sure decimals “line up” when you output the final accounts information. And do not forget to close
the files when done with them.
********************************************************************************/
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

int main()
{
  const double premiumIntRate = 0.05;
  const double choiceIntRate = 0.03;
  const double basicIntRate = 0.01;

  string accountNum; 
  string accountType;
  double startBalance, deposited, withdrawn, endBalance; 
 
  ifstream fin;
  ofstream fout; 

  fin.open("accounts.txt");

  if(!fin) //OR if(fin == NULL)   means, if the file doesn't exist
    cout << "Cannot open the input file" << endl;
  else //the input file exists
    {
      fout.open("accountsOutfile.txt"); //opens the output file only if the input file opened
      fout << left << setw(10) << "Account" << setw(10) << "Type" << setw(15) << "StartBalance" << setw(10) << "Deposit"; 
      fout  << setw(15) << "Withdrawal" << setw(15) << "EndBalance" << endl;
      fout << "------------------------------------------------------------------------" << endl;
      
      fin >> accountNum >> accountType >> startBalance >> deposited >> withdrawn; //reads the first pieces of data 

      while(fin) //data was read successfully
	{
	  if(accountType == "Premium")
	    endBalance = (startBalance + deposited - withdrawn) * (1 + premiumIntRate);
	  else if(accountType == "Choice")
	    endBalance = (startBalance + deposited - withdrawn) * (1 + choiceIntRate);
	  else //accoutType == "Basic"
	    endBalance = (startBalance + deposited - withdrawn) * (1 + basicIntRate);

	  fout << left << setw(10) << accountNum << setw(10) << accountType << setw(15) << fixed << setprecision(2) << startBalance; 
	  fout << setw(10) << deposited << setw(15) << withdrawn << setw(15) << fixed << setprecision(2) << endBalance << endl;

	  fin >> accountNum >> accountType >> startBalance >> deposited >> withdrawn; //reads the next pieces of data. 
	                                                                       //When the file can't read anymore data, the while loop stops and exits
	}      
      
    }

  fin.close();      
  fout.close();
    
  return 0;
}
