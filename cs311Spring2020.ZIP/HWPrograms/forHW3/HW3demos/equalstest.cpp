// CS311 Demo: Try this
// == is used. Does this compile and run?? 

using namespace std;
#include <iostream>
#include "rlist.h"

int main()
{
  llist A;
  llist B;

  if (A == B) cout << "hi" << endl;

  
}


