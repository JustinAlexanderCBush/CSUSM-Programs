/********************************************************************************
Justin Bush
CS 111 
Create a program that simulates a vending machine – your program will ask the user to enter a price for an item first, then enter the amount of money deposited. Your program should print the change that is given to the user to a text file, as a number of quarters, dimes, nickels, and pennies. Format the file as in the example given. Change should be given using the smallest number of coins possible (change higher than 1 dollar can be given in quarters). If the user will receive no change, say “no change” instead of 0 quarters, 0 dimes, 0 nickels and 0 pennies. If the user enters less money than the price of the item then give an error message on the screen stating “not enough money inserted” and print nothing to the file. After each transaction, whether enough money or not, ask the user if they have
another transaction (enter capital or lowercase Y or N), and repeat if so. Note: You can assume that the user will type the price as a decimal number without a dollar sign. Rounding issues within one penny are OK.
 *******************************************************************************/
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

int main()
{
  double price;
  double paid; //What the person paid
  int q, d, n, p; //short for quarters, dimes, nickels and pennies
  double change =0.0;
  double remainder =0.0;
  char ans; //The answer the user will give when they're asked if they want to buy another item 

  ofstream fout;
  fout.open("lab16and17.txt");

  do
    {
      cout << "Enter price of item: $";
      cin >> price;
      cout << endl;
  
      fout << "Price:$ " << fixed << setprecision(2) << price << endl;

      cout << "Enter amount of money inserted: $";
      cin >> paid;
      cout << endl;
      
      fout << "** Money inserted:$ " << fixed << setprecision(2) << paid << endl;

      if(paid < price)
	fout << "Error. Not enough money." << endl;
      else if(paid == price)
	fout << "No change" << endl;
      else //(paid > price)
	{
	  change = (paid - price) * 100.00;
	  fout << "Change: " << endl;
	  
	  q = change / 25;  //(int)(0.25 * 100);
	  fout << "Quarters: " << q << endl;
	  remainder = change - (q * 25);
	  
	  d = (int)remainder / 10;
	  fout << "Dimes: " << d << endl;
	  
	  remainder -=  (d* 10);
	  n = (int)remainder / 5;
	  fout << "Nickels: " << n << endl;
	  
	  remainder -= (n * 5);
	  p = (int)remainder / 1;
	  fout << "Pennies: " << p << endl;
	  
	  fout << "********************" << endl;
	}
      
      cout << "Do you have another entry?: ";
      cin >> ans;

    }while(ans == 'Y' || ans == 'y');
  
  cout << "Open the file 'lab16and17.txt' to see your amount of change" << endl;
   
  return 0;
}




