#include <iostream>
using namespace std;

void fillArray(int ar[], int size);
bool find(const int ar[], int size, int key);

int main()
{
  const int SIZE = 10;
  int ar[SIZE];
  int key;

  fillArray(ar, SIZE);
  cout << "Enter the number you are looking for: ";
  cin >> key;
  
  if(find(ar, SIZE, key) == true) //OR bool ans == find(ar, SIZE, key) OR if(ans == true)
    cout << key << " was found in the array.";        
  else                                                   
    cout << key << " was not found in the array.";   
  
  return 0;
}

void fillArray(int ar[], int size)
{
  for(int i = 0; i < size; i++)
    {
      cout << "Enter a number: ";
      cin >> ar[i];
    }
}
bool find(const int ar[], int size, int key)
{
  for(int i = 0; i< size; i++)
    {
      if(ar[i] == key)
	return true;
    }
  return false; //Why outside the for-loop? Because it the for-loop checked all of the index values, and the key was not in the array. It has the check all of the index values before it can return 'false' 
}
