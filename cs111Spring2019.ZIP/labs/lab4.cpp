/********************************************************************************
Justin Bush
CS 111
Castillo
2/8/19
This program will as the user to enter an integer. If it is even, print whether or not it is divisible by both 5 and 3. If it is odd, print whether or not it is negative. Whether it is even or odd print whether it is between -100 and 100 inclusive (-100 and 100 are in the range). Note: treat zero as even and positive.
********************************************************************************/
#include <iostream>
using namespace std;

int main()
{
  int integer; //the integer the user inputs

  cout << "Enter one integer" << endl;
  cin >> integer;

  while(integer < -100 || integer > 100)//if the user keeps entering values not inclusive between -100 OR 100, it will keep looping the cout statement below
    {
      cout << "Enter an integer inclusive from -100 to 100" << endl;
      cin >> integer; //allows the user to enter another integer 
    }

  if(integer >= -100 && integer <= 100)
    {
      if(integer % 2 == 0) //This integer is even
	{
	  if(integer % 3 == 0 && integer % 5 == 0)
	      cout << "This integer is divisible by both 5 and 3" << endl;
	  else
	    cout << "This integer is not divisible by both 5 and 3" << endl;
	}
      
      else if(integer % 2 == 1) //This integer is odd
	{
	  if(integer < 0)
	      cout << "This integer is negative" << endl;
	  else
	      cout << "This integer is positive" << endl;
	}
    }  
  return 0;
}
  
