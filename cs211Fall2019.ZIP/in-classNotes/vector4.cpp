
#include<iostream>
#include<fstream>
#include<iomanip>
#include<vector>

using namespace std;

vector<float>GetInfo();
void PrintVectors(vector<int>,vector<float> fMarks);
int GetOccur(float,int,vector<float>&);

//--------------------------------
int main()
{
  vector<float> fMarks;
  vector<int> iCount;

  fMarks = GetInfo();
  int iI = 0;
  while (iI < fMarks.size())
    {
      int iElem = GetOccur(fMarks[iI], iI, fMarks);
      iCount.push_back(iElem);
      iI++;
    }
  PrintVectors(iCount,fMarks);

}
//--------------------------------
vector<float> GetInfo()
{
  float iElement;
  vector<float> iX;
  ifstream fin;
  fin.open("data.txt");
  fin >> iElement;
  while (fin)
    {
      iX.push_back(iElement);
      fin >> iElement;
    }
  fin.close();
  return(iX);

}
//--------------------------------
void PrintVectors(vector<int>iCounts,vector<float> fMarks)
{
  cout << endl;
  cout << endl;
  cout << setw(40) << "Marks" << setw(20) << " Occurrance" << endl;
  cout << setw(40) << "-----" << setw(20) << " ----------" << endl;
  for (int iI = 0; iI<fMarks.size(); iI++)
    cout << setw(38) << fMarks[iI] << 
      setw(18) << iCounts[iI] << endl;
}
//--------------------------------
int GetOccur(float fMark, int pos, vector<float>& fMarks)
{
  int iCount = 1;
  for (int iI = pos+1; iI<fMarks.size(); iI++)
    {
      while (fMarks[iI]==fMark)
	{
	  fMarks.erase(fMarks.begin()+iI);
	  iCount++;
	  if (iI >= fMarks.size()) 
	    break;
	}
    }
  return(iCount);
}
//--------------------------------
