/********************************************************************************
Justin Bush
CS 111 Castillo
5/1/19
Header file for Homework 4
********************************************************************************/
#ifndef BOX_H
#define BOX_H
#include <string>
using namespace std;

class box
{
 private:
  double length, width, height, weight; //height is in inches
  int zipCode;
  string address, city, state; 
 
 public:
  void setLength(double passedLength); 
  double getLength();

  void setWidth(double passedWidth);
  double getWidth();

  void setHeight(double passedHeight);
  double getHeight();

  void setWeight(double passedWeight);
  double getWeight();

  void setAddress(string passedAddress);
  string getAddress();

  void setCity(string passedCity);
  string getCity();

  void setState(string passedState);
  string getState();

  void setZipCode(int passedZipCode);
  int getZipCode();

  double calcShippingPrice();

  void print();

  box(); //default parameter with no parameters
  box(double initialLength, double initialWidth, double initialHeight, double initialWeight, string initialAddress, string initialCity, string initialState, int initialZipCode); //overloaded constructor 
};

#endif

