//CS311 Yoshii Linked List class

//INSTRUCTION:
//Must use the provided HW3P1_help.doc to create llist.cpp
//It helps to first create if-then-else structure to fill in later.
//- Make sure PURPOSE and PARAMETER comments are given in detail
//- Make sure all if-then-else are commented describing which case it is
//- Make sure all local variables are described fully with their purposes

//EMACS HINT:
//  You can copy from a Word document to emacs (contrl-right click)
//  cntr-K cuts and cntr-Y pastes
//  Esc x replace-str does string replacements
//  Esc > goes to the end of the file; Esc < to the beginning
//  Tab on each line will indent perfectly for C++

// ====================================================
//HW#: HW3P1 llist
//Your name: Justin Bush
//Complier:  g++ -std=c++11
//File type: llist.cpp implementation file
//=====================================================
using namespace std;
#include<iostream>
#include"llist.h" 

//default constructor, to set the front and rear pointers, to nullptr, and sets
//the count = 0
llist::llist()
{ 
  cout << "... in llist constructor ..." << endl; 
  Front = NULL;
  Rear = NULL;
  Count = 0;
}

//destructor, to delete all of the pointers
llist::~llist()
{ 
  int oldNum; //to be deleted and it's the old number
  cout << "... in llist constructor ..." << endl;
  
  while(!isEmpty() ) //while the list is NOT empty,
    deleteFront(oldNum);  //delete the front pointer

}

//PURPOSE: Checks if the list is empty
//PARAMETER: None
bool llist::isEmpty() // be sure to check all 3 data members
{ 
  if(Front == NULL && Rear == NULL && Count == 0)
    return true;
  else 
    return false;
} 

//PURPOSE: Displays all elements in the list
//PARAMETER: None
void llist::displayAll()  // be sure to display horizontally in [  ] with
// blanks between elements
{
  if( isEmpty() )
    cout << "[ empty ]" << endl;
  else
    {
      Node* ptr = Front; //ptr (local variable) points to Front pointer
      cout << "[ ";
      while(ptr != NULL) //to traverse list
	{
	  cout << (char)ptr->Elem << " "; 
	  ptr = ptr->Next; //moves the pointer P, to the next node
	}
      cout << " ]" << endl;
    }
}


//PURPOSE: Appends a newly allocated node to list
//PARAMETER: New data, which is going to be added to list
void llist::addRear(el_t NewNum)  // comment the 2 cases
{
  if( isEmpty() )
    {
      Front = new Node;
      Rear = Front;
      Front->Elem = NewNum;
      Front->Next = NULL;
      Count++;
    }
  else
    {
      Rear->Next = new Node;
      Rear = Rear->Next;
      Rear->Elem = NewNum;
      Rear->Next = NULL;
      Count++;
    }
}

//PURPOSE: Adds a newly allocated node to front ot list
//PARAMETER: New data, which is going to be added to list
void llist::addFront(el_t NewNum) // comment the 2 cases
{
  if( isEmpty() )
    {
      Front = new Node;
      Rear = Front;
      Front->Elem = NewNum;
      Front->Next = NULL;
      Count++;
    }
  else
    {
      Node* nodePtr; //nodePtr is a temp pointer
      nodePtr = new Node;
      nodePtr->Next = Front;
      Front = nodePtr;
      Front->Elem = NewNum;
      Count++;
    }
}

//PURPOSE: Deletes front node in list
//PARAMETER: Old number, which is going to be deleted
void llist::deleteFront(el_t& OldNum)  // comment the 3 cases
{
  if( isEmpty() )
    throw Underflow();
  else if(Count == 1)
    {
      OldNum = Front->Elem;
      delete Front;
      Count--;
      Front = NULL;
      Rear = NULL;      
    }    
  else //else, there is more than one element and/or node
    {
      OldNum = Front->Elem;
      Node* Third; //temp pointer for the third case
      Third = Front->Next;
      delete Front;
      Front = Third;
      Count--;
    }
}

//PURPOSE: Deletes very last node in list
//PARAMETER: Old number, that is going to be deleted
void llist::deleteRear(el_t& OldNum)  // comment the 3 cases
{
  if(isEmpty() )
    {
      throw Underflow();
    }
  else if(Count == 1)
    {
      OldNum = Rear->Elem;
      delete Rear;
      Front = NULL;
      Rear = NULL;
      Count--;
    }
  else
    {
      OldNum = Rear->Elem;
      Node* ptr = Front; 
      while(ptr->Next != Rear)
	ptr = ptr->Next;
      
      delete Rear;
      Rear = ptr;
      Rear->Next = NULL;
      Count--;
    }      
}


/* harder ones follow */

// Utility Function to move a local pointer to the Ith node
void llist::moveTo(int J, Node*& temp)
{ // moves temp J-1 times
  for(int K = 1; (J-1) > K; K++) 
    temp = temp->Next;
}

//PURPOSE: Deletes node at the Ith pointer
//PARAMETER: Number of Ith pointer and the old number, that will be deleted
void llist::deleteIth(int I, el_t& OldNum) // use moveTo to move local pointers.
//Be sure to comment to which node you are moving them.
{
  if(I < 1 || I > Count)
    throw OutOfRange();
  else if(I == 1)
    {
      cout << "Front: " << endl;
      deleteFront(OldNum);
    }  
  else if(I == Count)
    {
      cout << "Rear: " << endl;
      deleteRear(OldNum);
    } 
  else
    {
      cout << "Position: " << endl;
      Node* nodePtr = Front; 
      moveTo(I, nodePtr);
      
      Node* temp = nodePtr->Next;
      nodePtr->Next = temp->Next;
      OldNum = temp->Elem;
      delete temp;
      Count--;
    }
}

//PURPOSE: Inserts a newly allocated node at Ith pointer
//PARAMETER: Number for Ith pointer, which is to be added
void llist::insertIth(int I, el_t newNum) // use moveTo to move local pointers.
//Be sure to comment to which node you are moving them.
{
  if(I > (Count + 1) || I < 1)
    throw OutOfRange();
  else if(I == 1)
    addFront(newNum);
  else if(I == Count + 1)
    addRear(newNum);
  else
    {
      Node* nodePtr = Front;
      moveTo(I, nodePtr);

      Node* temp = nodePtr->Next;
      nodePtr->Next = new Node;
      nodePtr = nodePtr->Next;
      nodePtr->Next = temp;
      nodePtr->Elem = newNum;
      Count++;
    }
}


//PURPOSE: Copy constructor
//PARAMETER: Passes list to make a copy of it
llist::llist(const llist& Original) // use my code
{
  cout << "Original" << endl;
  Front = NULL;
  Rear = NULL;
  Count = 0;

  Node* P; //local pointer for OtherOne
  P = Original.Front;
  while(P != NULL)
    {
      this->addRear(P->Elem);
      P = P->Next;
    }
  //Nothing to return b/c this is a constructor
}

//PURPOSE: Overloaded = operator
//PARAMETER: Passes list to compare the two lists
llist& llist::operator=(const llist& OtherOne) // use my code
{
  el_t x;

  if(&OtherOne != this)
    {
      while( !this->isEmpty() )
	this->deleteRear(x);
      
      Node* P; //local pointer for OtherOne
      P = OtherOne.Front;
      while(P != NULL)
	{
	  this->addRear(P->Elem);
	  P = P->Next;
	}
    }//end of if statment
  return* this; //return the result unconditionally. Not that the result is
}               //returned by reference
