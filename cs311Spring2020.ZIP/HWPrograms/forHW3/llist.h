//CS311 Yoshii
//INSTRUCTION:
//Llist class - header file template 
//You must complete the ** parts and then complete llist.cpp
//Don't forget PURPOSE and PARAMETERS 

// =======================================================
// HW#: HW3P1 llist
// Your name: Justin Bush
// Compiler:  g++ 
// File type: headher file  llist.h
//=======================================================

// alias el_t : element type definition
typedef int el_t;

//a list node is defined here as a struct Node for now
struct Node
{
  el_t Elem;   // elem is the element stored
  Node *Next;  // next is the pointer to the next node
};
//---------------------------------------------------------

class llist
{
  
 protected: //for the inheritance of slist
  Node *Front;       // pointer to the front node
  Node *Rear;        // pointer to the rear node
  int  Count;        // counter for the number of nodes

  // untility function to move to a specified node position
  void moveTo(int, Node*&);
  
 public:

  // Exception handling classes 
  class Underflow{}; //thrown when underflow occurs in the linked list
  class OutOfRange{};  // thrown when the specified Node is out of range

  llist ();     // constructor to create a list object
  ~llist();     // destructor to destroy all nodes
  
  //Purpose: To check if the list is empty, if the front and rear pointers are 
  //pointing to nullptr, and if the Count = 0
  bool isEmpty();
    
  //Purpose: To display all elements in the nodes
  void displayAll();

  //Purpose: To append (add to the end of the list) a newly allocated node with
  //an element.
  //Parameters: New element that is to be appended to the end of the list 
  void addFront(el_t);
    
  //Purpose: To add an element to the front
  //Parameters: Element that is to be added to the front
  void addRear(el_t);

  //Purpose: To delete the front node and its corresponding element
  //Parameters: Variable that is to be passing the previous element to, that will
  //be deleted
  void deleteFront(el_t&);
    
  //Purpose: To delete the rear element, and pass said element back
  //Parameters: Variable that is to receive the previous element
  void deleteRear(el_t&);
    
  //Purpose: To delete the designated element and/or node
  //Parameters: Node that we want to delete, and the variable that will receive
  //the previous element
  void deleteIth(int, el_t&);  // calls moveTo

  //Purpose: To add an element before the designated element
  //Parameters: Designated element, and the variable to send the previous 
  //element to   
  void insertIth(int, el_t);   // calls moveTo

  //Copy Constructor to allow pass by value and return by value of a llist
  llist(const llist&);
  
  //Overloading of = (returns a reference to a llist)
  llist& operator=(const llist&); 

};
