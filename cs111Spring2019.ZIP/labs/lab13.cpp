/********************************************************************************
Justin Bush
CS 111 
Castillo
2/25/19
Create a file named sentence.txt and write a sentence the user enters to it using ofstream.

Test case 1:
Enter a sentence: <user enters a sentence>

File Contents: 
sentence.txt contains the user’s sentence after the program is run.  Show this by typing “cat sentence.txt” after you run your program.
********************************************************************************/
#include <iostream>
#include <fstream>
using namespace std;

int main()
{

  ofstream fout; 
  string sentence; //The sentence the user enters

  fout.open("lab13.txt");

  cout << "Enter a sentence: ";
  getline(cin, sentence); //gets the whole sentence, "This is a sentence" from the screen and 

  cout << "Open the file 'lab13.txt' to see your output" << endl;

  fout << sentence << endl; //This shows up in the file, sentence.txt
  
  fout.close(); //closes the file
    
  return 0;
}
