/******
4/19/19
Binary search ONLY works with a sorted array. (ascending order)
*******/
#include <iostream>
using namespace std;

int main()
{
  

  return 0;
}
