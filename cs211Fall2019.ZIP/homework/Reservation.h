/***************************************

 *************************************/
#ifndef RESERVATION_H
#define RESERVATION_H
#include<iostream>
using namespace std;

class Reservation
{
private:
  const long reservationNum; //reservation num, set to the value of 
                             //nextReservationNum
  string contactName; //name of person making reservation         
  string contactPhone; //person phone number
  int groupSize; //number of persons in their reservation
  int reservationTime; //reservation time, which could be 5, 6, 7 or 8
  static long nextReservationNum; //initialize it to 100 and increment it by 10
                                  //as you create a new Reservation object
    
public:
  Reservation(); //default constructor
  Reservation(string cName, string cPhone, int gSize, int reserveTime); //overloaded constructor
  long getReservationNum();
  int getReservationTime() const;
  void printReservationInfo(); 
};

#endif
