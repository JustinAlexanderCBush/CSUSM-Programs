/*******************************************************************************
This program will swap the values of x and y. This should work even if the values of x and y were modified (i.e. DO NOT hard code y = 5 and x = 10). Hint: You need a third integer to act as a temporary holding place for one of the value.  
 ******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
  int x = 5;
  int y = 10;
  int temp; //temporary holding variable

  temp = x; //temp gets the value of x, or 5. So, temp = 5.
  x = y;    //x gets the value of y, or 10. So, x = 10.
  y = temp; //y gets the value of temp, or 5. So, y = 5.

  cout << "x = " << x << ", and y = " << y << endl;

  return 0;
}
