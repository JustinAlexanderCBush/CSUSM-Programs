/********************************************************************************
Justin Bush
CS111
Castillo
2/13/29
Ask the user to enter an integer (positive or negative does not matter). Repeat the integer given by the user and tell them whether it is even or odd. After the user enters the first integer, and after each subsequent integer entered, ask the user if they wish to enter another integer. If they answer ‘Y’ or ‘y’ then repeat, if they answer ‘N’ , ‘n’ , or any other character then tell them how many odd numbers they entered and how many even numbers they entered. Note that the user should always enter at least one integer – only ask them if they have another after the first entry.
********************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  int integer; //the integer that the user will enter
  int evenCounter; //the amount of times an even number was entered
  int oddCounter; //the amount of times an odd number was entered
  char ans; //the user's answer: whether or not he/she wants to keep entering integers
  do
    {  
      cout << "Enter an integer (positive or negative):  ";
      cin >> integer;
      if(integer % 2 == 0) //the integer is even
	{
	  cout << integer << " is even." << endl;
	  cout << "Do you want to enter another integer?" << endl;
	  evenCounter++;
	  cin >> ans;
	}
      else //The integer is odd
	{
	  cout << integer << " is odd." << endl;
	  cout << "Do you want to enter another integer?" << endl;
	  oddCounter++;
	  cin >> ans;
	}
    } while(ans == 'y' || ans == 'Y');
          {
            cout << "Even numbers entered: " << evenCounter << endl;
            cout << "Odd numbers entered: " << oddCounter << endl;
	  }  
  
  return 0;
}

