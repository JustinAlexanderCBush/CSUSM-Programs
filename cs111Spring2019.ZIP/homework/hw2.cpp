/*******************************************************************************
Justin Bush
CS 111 Castillo
3/11/19
Create four functions for addition, subtraction, multiplication, and division that each accept an array of doubles (remember that arrays are always passed by reference without needing an &) as well as an operand of type double passed by value.  Each function will perform its’ operation on each element of the array using the operand.
Example: Operation is addition, array contents are [2.5, 4.5, 6.5, 8.5, 10.5], operand is 7, the array would be changed to contain [9.5, 11.5, 13.5, 15.5, 17.5].
Hint: Remember that arrays are always passed by reference, so your return types for these functions should be void.
Create a fifth function that prints the contents of the array to the screen, one element per line.  This function should accept an array of doubles as its’ only argument.  The print function should not modify the contents of the array in any way – declare the parameter as const to ensure that this is the case (note that you could not do this with the four other functions since they need to modify the array).  The print function should also return void.
In main ask the user to enter the values to store in the array.  Print the array using your print function.  Have the user select an operation to perform on the array by typing +, - , * or /, then enter an operand.  Perform the given function on the array using the given operand and then print the array contents using your print function again.
Use a global int constant for the size of the array – set it to 5.  If the global constant is changed in the code your program should still work properly.
Make sure nothing in your code results in junk values or causes a segmentation fault.
********************************************************************************/
#include <iostream>
#include <fstream>
using namespace std;

int main()
{
  int triangle; 

  cout << "Enter the size of a triangle. (An integer from 1 to 50)" << endl;
  cin >> triangle;
 
  ofstream fout; //for an output file
  fout.open("triangle.txt");

  while(triangle < 1 || triangle > 50)
    {
      cout << triangle << " is out of range. Re-enter a value." << endl;
      cin >> triangle;
    }
  
  //Else, if the user enters a value inclusive between 1 and 50:
  cout << "Triangle saved to file. Now open the 'triangle.txt' file to see your output." << endl;
  
  //This nested for-loop prints the full first half of the triangle
  for(int row = 1; row <= triangle; row++) //This for-loop controls the number of lines to print 
    {
      for(int asterisk = 1; asterisk <= row; asterisk++) //This for-loop controls the number of asterisks to print on a line
	fout << "*";
      
      fout << endl << endl;
    }
  
  //This nested for-loop does the same thing as the previous nested for-loop, but it prints one less asterick for every line, that the size of the triangle is equal to
  for(int row = triangle - 1; row >= 1; row--)
    {
      for(int asterisk = row; asterisk >= 1; asterisk--)
	  fout << "*";
      
      fout << endl << endl;
    }     
  
  fout.close(); 
  
  return 0;
}











