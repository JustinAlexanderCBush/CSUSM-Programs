/*************************************

 ************************************/
#include<iostream>
#include<fstream>
#include<vector>
#include<iomanip>
using namespace std;

//prototypes
//-----------------------------------------------
vector<float> GetInformation1();
vector<float> GetInformation2();
void MakeEqual(vector<float>& x, vector<float>& y);
vector<float> AddVectors(const vector<float>& x, const vector<float>& y);
vector<float> MultVectors(const vector<float>& x, const vector<float>& y);
vector<float> SubVectors(const vector<float>& x, const vector<float>& y);
vector<float> DivVectors(const vector<float>& x, const vector<float>& y);
void PrintVector(vector<float> X);

int main()
{
  vector<float> X;
  vector<float> Y;
  vector<float> Z;
  

  X = GetInformation1();
  Y = GetInformation2();

  cout << "The vectors are : " << endl;
  cout << " X is ";
  PrintVector(X);
  cout << endl;

  cout << " Y is ";
  PrintVector(Y);
  cout << endl;

  MakeEqual(X, Y);
  cout << "After pruning, the vectors are: " << endl;
  cout << " X is ";
  PrintVector(X);
  cout << endl;

  cout << " Y is ";
  PrintVector(Y);
  cout << endl;


  Z = AddVectors(X, Y);
  cout << "The result of adding two vectors is: " << endl;
  PrintVector(Z);
  cout << endl;

  Z = SubVectors(X, Y);
  cout << "The result of subtracting two vectors is: " << endl;
  PrintVector(Z);
  cout << endl;

  Z = MultVectors(X, Y);
  cout << "The result of multiplying two vectors is: " << endl;
  PrintVector(Z);
  cout << endl;

  Z = DivVectors(X, Y);
  cout << "The result of dividing two vectors is: " << endl;
  PrintVector(Z);
  cout << endl;
}


//------------------------------------------------
vector<float> GetInformation1()
{
  float Element;
  vector<float> X;
  ifstream fin;
  fin.open("data1.txt");
  fin >> Element;
  while (fin)
    {
      X.push_back(Element);
      fin >> Element;
    }
  fin.close();
  return(X);
}

//------------------------------------------------
vector<float> GetInformation2()
{
  float Element;
  vector<float> X;
  ifstream fin;
  fin.open("data2.txt");
  fin >> Element;
  while (fin)
    {
      X.push_back(Element);
      fin >> Element;
    }
  fin.close();
  return(X);
}

//------------------------------------------------
void MakeEqual(vector<float>& X, vector<float>& Y)
{
  int Diff =0;
  if (X.size() > Y.size())
    {
      Diff = X.size() - Y.size();
      for (int I=0; I<Diff; I++)
	X.pop_back();
    }
  else
    {
      Diff = Y.size() - X.size();
      for (int I=0; I<Diff; I++)
	Y.pop_back();
    }

}

//------------------------------------------------
vector<float> AddVectors(const vector<float>& X, const vector<float>& Y)
{
  vector<float> Z;
  for (int I=0; I<X.size(); I++)
    Z.push_back(X[I]+Y[I]);
  return(Z);
}

//------------------------------------------------
vector<float> MultVectors(const vector<float>& X, const vector<float>& Y)
{
  vector<float> Z;
  for (int I=0; I<X.size(); I++)
    Z.push_back(X[I]*Y[I]);
  return(Z);
}

//------------------------------------------------
vector<float> SubVectors(const vector<float>& X, const vector<float>& Y)
{
  vector<float> Z;
  for (int I=0; I<X.size(); I++)
    Z.push_back(X[I]-Y[I]);
  return(Z);

}

//------------------------------------------------
vector<float> DivVectors(const vector<float>& X, const vector<float>& Y)
{
  vector<float> Z;
  for (int I=0; I<X.size(); I++)
    Z.push_back(X[I]/Y[I]);
  return(Z);
}

//------------------------------------------------
void PrintVector(vector<float> X)
{
  for (int I=0; I<X.size(); I++)
    cout << setw(7) << X[I];
  cout << endl;
}


