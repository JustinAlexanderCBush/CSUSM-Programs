//IMPORTANT: This Node.h file will be used with the LinkedList.h file

#ifndef NODE_H
#define NODE_H
using namespace std;

class LinkedList; //forward class declaration. I COULD use this if I didn't want to write "#include "LinkedList.h" at the top 

class Node
{
  friend class LinkedList; //declare class LinkedList as a friend of class Node
 
 private:
  Node *next; //ptr to next 
  string name, phoneNumber; 
};

#endif
