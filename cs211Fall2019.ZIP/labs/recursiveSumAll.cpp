/****************************************
Justin Bush
CS 211 Lab 8 Part 4
Write a recursive function sumAll that accepts an integer argument and returns the sum of all the integers from 1 up to the number passed as an argument. For example, if 50 is passed as an argument, the function will turn the sum of 1, 2, 3, 4, ..50.
****************************************/
#include<iostream>
using namespace std;

int sumAll(int n);

int main()
{
  int num;
  cout << "Enter a positive number: ";
  cin >> num;
  cout << "Sum of all integers from 1 until " << num << " is: " << sumAll(num); 
  cout << endl;

  return 0;
}
 
int sumAll(int n)
{
  if(n == 1) 
    return 1;
  else if(n > 1) //n = 2;
    return n + sumAll(n - 1); //return 2 + sumAll(1), then return 2 + 1, or 3    
}

 
  
  
  

  
