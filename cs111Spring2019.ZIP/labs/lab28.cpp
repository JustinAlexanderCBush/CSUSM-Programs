/*************************************************************
Justin Bush 
CS 111 Castillo
5/6/19

Write a recursive Fibonacci function to calculate the nth Fibonacci number.  In main, ask the user to enter which Fibonacci number they want, then print it (i.e. if they enter 5 provide the 5th Fibonacci number).  The function will return the result, and main will print it.

The user will provide an integer with a value of 1 or greater.
Fibonacci Sequence:
Fib(1) = 1
Fib(2) = 1
Fib(n) = Fib(n-1) + Fib(n-2)  (if n is greater than 2)

1   1   2   3   5   8   13   21   34   55   …

Test Case 1:
Enter a number: <1>
1
Test Case 2:
Enter a number: <2>
1
Test Case 3:
Enter a number: <6>
8
Test Case 4:
Enter a number: <10>
55
******************************************************/
#include <iostream>
using namespace std;

int fibonacci(int n);

int main()
{
  int nValue; //the nth term for the fibonacci number the user wants to find
  
  cout << "Enter a number: ";
  cin >> nValue;
    
  cout << fibonacci(nValue) << endl;
    
  return 0;
}

int fibonacci(int n)
{
  if(n == 1 || n == 2)
    {
      return 1;
    }
  else if(n > 2)
    {
      return fibonacci(n-1) + fibonacci(n-2);
    }
}
