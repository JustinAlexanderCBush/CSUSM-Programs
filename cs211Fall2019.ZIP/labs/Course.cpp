#include<iostream>
#include "Course.h"
using namespace std;

Course::Course() //Class name:: Class func  **Default constructor
{
  courseNumber = 0;
  courseName = ""; //courseName is blank
  numberOfCredits = 0;
}
 
Course::Course(long cNum, string cName, int numCredits)
{
  courseNumber = cNum; 
  courseName = cName;
  numberOfCredits = numCredits; 
}

void Course::setCourse(long cNum, string cName, int numCredits)
{
  courseNumber = cNum;
  courseName = cName;
  numberOfCredits = numCredits;
}

void Course::printCourse() const
{
  cout << "Course Number: " << courseNumber << endl; 
  cout << "Course Name: " << courseName << endl; 
  cout << "Course Number of Credits: " << numberOfCredits << endl; 
}


