/********************************************************************************
Justin Bush 
CS 111
Castillo 
2/11/19
********************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  int integer; //The integer the user will enter
  
  cout << "Enter an integer between 0 and 10" << endl;
  cin >> integer;
  
  while(integer < 0 || integer > 10)
    {
      cout << "Enter an integer inclusive between 0 and 10" << endl;
      cin >> integer;
    }
  switch(integer)
    {
    case 0: 
      cout << "zero" << endl;
      break;
    case 1:
      cout << "one" << endl;
      break;
    case 2:
      cout << "two" << endl;
      break;
    case 3:
      cout << "three" << endl;
      break;
    case 4:
      cout << "four" << endl;
      break;
    case 5:
      cout << "five" << endl;
      break;
    case 6:
      cout << "six" << endl;
      break;
    case 7:
      cout << "seven" << endl;
      break;
    case 8:
      cout << "eight" << endl;
      break;
    case 9:
      cout << "nine" << endl;
      break;
    case 10:
      cout << "ten" << endl;
      break;
      
    default:
      cout << "Enter an integer inclusive between 0 and 10" << endl;
      break;
    }
  
  return 0;
}
