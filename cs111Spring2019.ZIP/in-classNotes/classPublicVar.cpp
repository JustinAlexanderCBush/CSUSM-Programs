/*********
4/10/19
*********/
#include <iostream>
using namespace std;

class Rectangle //class definition
{
public: //access specifier
  double length; //variable to store length
  double width; //variable to store width
  double calcArea(); //function that returns area of rectangle
};

double Rectangle::calcArea() //member function of class Rectangle
{
  return length * width;
}

int main()
{
  cout << "Creating myRec (5*-4 rectangle)" << endl;
  Rectangle myRec; //instantiates (creates) a rectangle object
  
  //these directly set the length and width variables of the Rectangle
  //object called myRec.  This ONLY WORKS here if these variables are
  //PUBLIC!  Otherwise it can only be done in the member functions of the class
  myRec.length = 5;
  myRec.width = -4;

  //these directly get the length and width variables of the Rectangle
  //object called myRec.  This ONLY WORKS here if these variables are
  //PUBLIC!  Otherwise it can only be done in the member functions of the class
  cout << "Length of myRec is " << myRec.length << endl;
  cout << "Width of myRec is " << myRec.width << endl;

  //this calls the calcArea function of object myRec, which calculates
  //and returns its' area.
  cout << "Area of myRec is " << myRec.calcArea() << endl;
  
  cout << endl << endl;
  cout << "Modifying myRec to be a 3*10 rectangle" << endl;
  myRec.length = 3;
  myRec.width = 10;

  cout << "Length of myRec is " << myRec.length << endl;
  cout << "Width of myRec is " << myRec.width << endl;
  cout << "Area of myRec is " << myRec.calcArea() << endl;

  cout << "Creating r2 (2x2 rectangle)" << endl;

  //r2 is a second Rectangle object - completely separate from myRec
  Rectangle r2;

  //r2's length, width, and area are completely separate from myRec's
  r2.length = 2;
  r2.width = 2;

  cout << endl << endl;
  cout << "Length of r2 is " << r2.length << endl;
  cout << "Width of r2 is " << r2.width << endl;
  cout << "Area of r2 is " << r2.calcArea() << endl;
  cout << endl << endl;
  cout << "Length of myRec is " << myRec.length << endl;
  cout << "Width of myRec is " << myRec.width << endl;
  cout << "Area of myRec is " << myRec.calcArea() << endl;
 
  return 0;
}
