#include<iostream>
#include<string>
#include "inheritanceDerivedClass.h"
using namespace std;

//class Employee: public Person functions    basically, the class Employee

Employee::Employee()
{
  number = 0;
}

Employee::Employee(string theName, int num) //ORIGINALLY, the function was ONLY written in the main.cpp file, so 
                                            //is it still correct if the function is written here, in .cpp?????
{
  name = theName; //uses parent member
  number = num;
}

// adds new functionality
int Employee::get_number()
{
  return number;
}
void Employee::set_number(int num)
{
  number = num;
}

void Employee::print()
{
  cout << "Employee name is:\t" << name << endl;
  cout << "Emplyee id is:   \t" << number << endl;// uses parent member
}
