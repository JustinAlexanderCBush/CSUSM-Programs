/********************************************************************************
Justin Bush 
CS 111 Castillo
5/13/19
 *******************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;
const int SIZE_STU = 5;
const int SIZE_TEST = 3; //ß This one definitely needs to be declared before the prototypes
void fillArray(int scores[ ][SIZE_TEST]);
void printArray(const int scores[ ][SIZE_TEST]);

int main()
{
  int scores[SIZE_STU] [SIZE_TEST];

  fillArray(scores); //just the array name without [][]
  printArray(scores);

  return 0;
}

//fill the array vertically with scores entered from the keyboard
void fillArray(int scores[ ][SIZE_TEST]) //blank inside the 1st [], but need to specify the size inside the 2nd[]
{
  for(int stu = 0; stu < SIZE_STU; stu++) //going through each student
    {
      cout << "\nEnter the test scores for student #" << stu + 1 << endl;
      for(int test = 0; test < SIZE_TEST; test++) //for each student, go through all the tests
	{
	  cout << "\tEnter the score for test#" << test + 1 << " :";
	  cin >> scores[stu][test];
	}
    }
} 
                           //same order as how the array was declared in main().
                           //stu first then test

//Show the contents of the array
void printArray(const int scores[ ][SIZE_TEST])
{
  cout << endl << setw(10) << "Test#" << setw(6) << "1" << setw(6) << "2" << setw(6) << "3" << endl;
  for(int stu = 0; stu < SIZE_STU; stu++) //going through each student
    {
      cout << "Student #" << stu + 1; //10 spaces = ”Student #” has 9 characters + 1 for a student number
      for(int test = 0; test < SIZE_TEST; test++) //for each student, go through all the tests
	cout << setw(6) << scores[stu][test]; //show each student’s score
      cout << endl; //same order as how the array was declared in main().
    } //stu first then test
}
