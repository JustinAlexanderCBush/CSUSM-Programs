#include <iostream>
#include <string>
using namespace std;

void countdown(string list[], int length); 
void rank_difference(int list[], int previous_week_rank); 


const int SIZE = 10;

int main()
{
  
  string songs[SIZE] = {"Someone You Loved", "Truth Hurts", "Senorita", "Circles", "No Guidance", "Panini", "Highest in the Room", "Ran$om", "Bad Guy", "10,000 Hours"};
  string artists[SIZE] = {"Lewis Capaldi", "Lizzo", "Shawn Mendes & Camila Cabello", "Post Malone", "Chris Brown Featuring Drake", "Lil Nas X", "Travis Scott", "Lil Tecca", "Billie Ellish",  "Dan + Shay & Justin Bieber"};
  int ranks_last_week[SIZE] = {3, 1, 2, 4, 5, 9, 6, 7, 8, 11};
  int previous_week_rank;
  /*countdown(songs, SIZE);*/
  rank_difference(ranks_last_week, previous_week_rank);

  return 0;
} //end of main


/*
void countdown(string list[], int length) 
{
  cout << "Top " << length << " countdown:" << endl;
  for (int i = length - 1; i >= 0; i--) 
    cout << list[i] << endl;
} //end of countdown
*/

void rank_difference(int list[], int previous_week_rank) 
{
 
  cout << "Enter a rank from last week:\t";
  cin >> previous_week_rank;
  cout << "You entered Rank #" << previous_week_rank << " from last week.\n";
  for (int i = 0; i < SIZE; i++)
    {
      if(previous_week_rank > list[i + 1])
        cout << "The song moved up in rank this week.\n";    
      else if(previous_week_rank < list[i + 1])
        cout << "The song moved down in rank this week.\n";
      else if(previous_week_rank == list[i + 1])
        cout << "The song is ranked the same this week.\n";
      else //(previous_week_rank != list[i + 1])
        cout << "The song was not on the Top 10 List last week.\n";
    }
} // end rank_difference
//Find the index in ranks_last_week, where the value matches previous_week_rank

