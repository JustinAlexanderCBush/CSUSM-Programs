/******************

 ****************/
#include<iostream>
#include<string>
#include<sstream>
using namespace std;

bool isPalindrome(string sentence);
void reverseArray(string& array);
string deleteSpace(string string1);

int main()
{
  string userInput;
  cout << "Enter a string." << endl;
  getline(cin, userInput); //gets entire string  

  if(isPalindrome(userInput) == true)
    cout << userInput << " is a palindrome." << endl;
  else
    cout << userInput << " is not a palindrome." << endl;

  return 0;
}

bool isPalindrome(string sentence)
{
  
 
  //deleteSpace(temp);
   sentence = deleteSpace(sentence);
string temp = sentence;  
reverseArray(temp);

  if(temp == sentence)
    return true;
  else
    return false;

}

void reverseArray(string& array)
{
  char temp;
  int  r = array.size() - 1;

  for(int i = 0; i < r/2; i++)
    {
      temp = array[i];
      array[i] = array[r];
      array[r] = temp;
      r--;
    }

}

/*
string deleteSpace(string s1)
{
  stringstream ss1;
  string s;

  ss1 << s1;
  s1 = " ";

  while(!ss1.eof())
    {
      ss1 >> s;
      s1 += s;
    }
  return s1;
}
*/

string deleteSpace(string string1)
{
  stringstream str1; //stringstream is an object, and str1 is a
  string s;

  str1 << string1;
  string1 = "";

  while(!str1.eof())
    {
      str1 >> s;
      string1 += s;
    }
  return string1;
}

