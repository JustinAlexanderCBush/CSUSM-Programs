#include <iostream>
using namespace std;

int main()
{
  for(int a = 0; a < 5; a++)
    {
      cout << "Loop a!" << endl;

      for(int b = 0; b <= 10; b++)
	{
	  cout << "Loop b!" << endl;
	}
      for(int c = 1; c < 3; c++)
	{
	  cout << "Loop c!" << endl;
	}
    }
  for(int d = 10; d < 0; d = d - 2)
    {
      cout << "Loop d!" << endl;
    }
    

  return 0;
}
