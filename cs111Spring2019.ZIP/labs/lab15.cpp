/********************************************************************************
Justin Bush
CS 111
3/4/19
Create a program that rolls 2 six-sided dice and prints the total of the two dice to the screen.  Be sure to separate each result somehow (spaces, commas, new lines, etc.).  Have this repeat one million times, and keep a running total of sevens and twelves rolled.  Print out the total of each at the end.
********************************************************************************/
#include <cmath> //needed for random
#include <cstdlib> //needed for time
#include <iostream>
using namespace std;

int main()
{
  int totalRoll, total7, total12, dice1, dice2;
  srand(time(0));
  
  for(int i = 0; i < 1000000; i++)
    {
      dice1 =((rand()%6)+1);
      dice2 =((rand()%6)+1);
      total_roll = dice1 + dice2;
      
      if(totalRoll == 7)
	{
	  total7++;
	}
      else if(totalRoll == 12)
	{
	  total12++;
	}
	
      cout << "[ " << dice1 << "," << dice2 << " ]" << endl;
    }
  
  cout << "Total number of sevens rolled: " << total7 << endl; 
  cout << "Total number of twelves rolled: " << total12 << endl;

  return 0;
}
