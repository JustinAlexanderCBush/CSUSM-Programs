/******
4/19/19
Correctly sorts an unorganized array
*******/
#include <iostream>
using namespace std;

void selectionSort(int ar[], int N);

  int main()
{
  ar[] = 5;
  cout << "Enter 5 values in put into an array" << endl;
  for(int i = 0; i < 5; i++)
    cin >> ar[i];
    
  return 0;
}

void selectionSort(int ar[], int N)
{
  int lrgIndx; //the index of the largest value
  int temp; //temporary variable that holds the largest value
  
  //last is the last index in unsorted portion
  for(int last = N-1; last >= 1; last--)
    {
      lrgIndx = 0; //assume the first item is the largest
      
      //find the largest in unsorted portion ([0..last])
      for(int i = 1; i <= last; i++)
	{
	  if(array[i] > array[lrgIndx]) //The current item is larger
	    lrgIndx = i;	  
	}

      //swap the largest with the last item in the unsorted portion
      temp = array[lrgIndx];
      array[lrgIndx] = array[last];
      array[last] = temp;
    }
}
