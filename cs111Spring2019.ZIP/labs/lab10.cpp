/********************************************************************************
Justin Bush
CS 111
Castillo
2/15/19
Print the multiplication table from 1-9 similarly to what is shown below, including the legend on the top and sides. Calculate the values and use nested loops to complete this lab. Your table should line up nicely (remember setw!)
********************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
   
  cout << "         1    2    3    4    5    6    7    8    9" << endl;
  cout << "-----------------------------------------------------" << endl;
  
  for(int row = 1; row <= 9; row++)
    {
      {
	cout << right << setw(4) << row << "|";	
      }
      for(int col = 1; col <=9; col++)
	{
	  cout << right << setw(5) << row * col;
	}
      cout << endl;
    }
  
  return 0;
}
