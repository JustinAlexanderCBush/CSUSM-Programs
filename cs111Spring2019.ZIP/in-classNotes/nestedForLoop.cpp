#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  char letter = 'A';

  //int 'i' in the outer for-loop prints the number of rows
  // int 's' in the inner for-loop prints the number of spaces 

  for(int i = 0; i < 5; i++)
    {
      for(int s = 0; s < i; s++)
	{
	  cout << "_";
	}
      cout << letter << endl;
      letter++; //stores the incremented value of the letter, untill it's couted again
    }

  return 0;
}
