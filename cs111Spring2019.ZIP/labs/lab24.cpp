/******************************************************************************
Justin Bush
CS 111 Castillo
4/15/19
Modify Lab 23 so that the radius variable in class circle is private.  Write a setter and getter function for radius, as well as a default constructor that initializes it to 0 and a constructor that takes one parameter for radius.  If radius is given as a negative in a call to the setter or the constructor set it to 0 instead.

Create a program that defines a class called circle.  Circle should have a member variable called radius that is used to store the radius of the circle.  Circle should also have a member function called calcArea that calculates the area of the circle using the formula area = pi*r^2.  Area should NOT be stored in a member variable of circle to avoid stale data.

Use a global constant for PI and set it to 3.14159.

In main, instantiate (declare/create) and use circle objects as needed to prove that all of your functions, including both constructors, work properly (construct a test case for your class in main).
******************************************************************************/
#include <iostream>
using namespace std;

//********************I'M CONFUSED. DO I WRITE THE FUNCTIONS IN THE CLASS, OR DO I WRITE THEM AS PROTOTYPES AND THEN WRITE THE FUNCTIONS AFTER MAIN????????
//********************I can do one or the other
class circle
{
private:
  double radius;

public:
  void setRadius(double passedRadius);
  double getRadius();
  double calcArea();
  circle(); //default constructor (no parameters)
  circle(double initialRadius); //constructor with a parameter for the inital radius 
};

const double pi = 3.14159;

int main()
{
  circle c1, c2; //the default constructor is called twice, because two objects, c1 and c2 were made from the "object", circle
  double r; //radius, for pass by value

  cout << "Enter the radius for the first circle: ";
  cin >> r;
  c1.setRadius(r);
  cout << "The radius is " << c1.getRadius() << " and the area is " << c1.calcArea()<< endl << endl;
  
  cout << "Enter the radius for the second circle: ";
  cin >> r;
  c2.setRadius(r);
  cout << "The radius is " << c2.getRadius() << " and the area is " << c2.calcArea() << endl << endl;

  cout << "Here, I have made a third circle, c3, and called it with the overloaded constructor as follows: 'circle c3(5.5)" << endl;
  //Just for how to use the overloaded constructor:
  circle c3(5.5); //c3 uses the circle(double initialRadius) function, to be usable
  cout << "The radius for c3 is: " << c3.getRadius() << " and the area of the third circle is: " << c3.calcArea() << endl;

  return 0;
}

void circle::setRadius(double passedRadius)
{
  if(passedRadius >= 0)
    radius = passedRadius;
  else
    cout << "Error. Radius cannot be negative." << endl;
}

double circle::getRadius()
{
  return radius;
}

double circle::calcArea()
{
  return pi * (radius * radius);
}

circle::circle() //default constructor (no parameters)
{
  cout << "Called default constructor of the circle; means two objects from the class 'circle' (c1 and c2 in this case) was used in the main" << endl;
  cout << "Also, radius = 0" << endl << endl;
  radius = 0;
}

circle::circle(double initialRadius) //constructor with a parameter for the initial radius
{
  cout << "Called overloaded constructor of rectangle, and setRadius(initialRadius)" << endl << endl;
  setRadius(initialRadius);
}
