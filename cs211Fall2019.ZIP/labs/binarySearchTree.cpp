/*
12/5/19
- displayInOrder: displays node values in order
- numLeafNodes: counts and returns the number of leaf nodes in the tree
- treeHeight: returns the height of the tree. The height of the tree is the
 number of levels it contains: an overloaded assignment operator and a 
copy constructor
Notes:
- These public functions call some recursive private functions to get the 
job done. You need to implement these functions too.
- the Overloaded Assignment Operator has IntBinaryTree as return type to 
allow cascaded assignments. You will need to return a reference to the 
calling object by saying: return*this;
   
Remember every object in C++ has access to its own address through an 
important pointer called this pointer. The this pointer is an implicit 
parameter to all non-static member functions. Therefore, this may be used, 
inside a member function, to refer to the invoking object. 
*/
#include <iostream>
using namespace std;

class IntBinaryTree
{
  private:
  struct TreeNode
  {
    int value; // The value in the node
    TreeNode *left; // Pointer to left child node
    TreeNode *right; // Pointer to right child node
  };
  
  TreeNode *root; // Pointer to the root node

  //Private member functions
  void insert(TreeNode *&nodePtr, TreeNode *&newNode); 
  void destroySubTree(TreeNode *nodePtr);
  void deleteNode(int num, TreeNode *&nodePtr);
  void makeDeletion(TreeNode *&nodePtr);
  void displayInOrder(TreeNode *nodePtr) const;
  int countLeafNodes(TreeNode *&nodePtr);
  int getTreeHeight(TreeNode *nodePtr);
  TreeNode *copyTree(TreeNode* nodePtr);

  public:
  IntBinaryTree() { root = nullptr; } //Constructor
  IntBinaryTree(const IntBinaryTree &tree); //Copy constructor
  ~IntBinaryTree() { destroySubTree(root); } //destructor

  void insertNode(int num);   //Binary tree operations
  bool searchNode(int num);
  void remove(int num);
  void displayInOrder() const { displayInOrder(root); }
  int numLeafNodes();
  int treeHeight();
  IntBinaryTree operator = (const IntBinaryTree & ); //Overloaded Assignment operator
};

//********************************************************
int main()
{ 
  IntBinaryTree tree, tree1, tree2; //Create 3 binary trees to hold integers

  //Show the initial height, without any nodes
  cout << "Height: " << tree.treeHeight() << endl << endl;  

  cout << "Inserting nodes.\n";  //Insert some nodes into the tree.
  tree.insertNode(5);
  tree.insertNode(8);
  tree.insertNode(3);
  tree.insertNode(12);
  tree.insertNode(9);
  cout << endl;

  cout << "Here are the values in the tree:\n"; //Display the nodes.
  tree.displayInOrder();
  cout << endl;

  cout << "Height: " << tree.treeHeight() << endl; //Display tree height
  cout << endl;
  
  //display number of leaf nodes in tree.
  cout << "Number of leaf nodes: " << tree.numLeafNodes() << endl; 
  
  cout << "Deleting 8...\n"; //Delete some nodes.
  tree.remove(8);
  cout << "Deleting 12...\n";
  tree.remove(12);
  cout << endl;

  cout << "Now, here are the nodes:\n"; //Display nodes that are left.
  tree.displayInOrder();
  cout << endl;

  cout << "Height: " << tree.treeHeight() << endl; //Display tree height
  cout << endl;

  //Display the number of leaf nodes in tree.
  cout << "Number of leaf nodes: " << tree.numLeafNodes() << endl;

  tree1.insertNode(55); //Insert some nodes into tree1.
  tree1.insertNode(5);
  tree1.insertNode(8);

  cout << "\nHere are the nodes of tree1:\n"; //Display the nodes in tree1.
  tree1.displayInOrder();
  cout << endl;
  
  tree2 = tree1; //Assign tree1 to tree2.

  cout << "Now, here are the nodes of tree2:\n"; //display the nodes in tree2.
  tree2.displayInOrder();
  cout << endl;

  tree1.insertNode(10); //modify tree 1 by adding 3 nodes to tree1
  tree1.insertNode(3);
  tree1.insertNode(12);

  // Display the nodes in tree1.
  cout << "\nHere are the nodes of tree1 after adding 3 nodes:\n";
  tree1.displayInOrder();
  cout << endl;

  // Display the nodes in tree2.
  cout << "\nHere are the nodes of tree2:\n";
  tree2.displayInOrder();
  cout << endl;
  
  IntBinaryTree tree3 = tree1; //define another IntBinaryTree object and 
                               //initialize it with tree1. This will invoke 
                               //the copy constructor

  cout << "Now, here are the nodes of tree3:\n"; //Display nodes in tree3
  tree3.displayInOrder();
  cout << endl;

  tree1.remove(5); //Remove one node from tree1

  //Display the nodes in tree1.
  cout << "\nHere are the nodes of tree1 after removing node 5:\n";
  tree1.displayInOrder();
  cout << endl;

  cout << "Now, here are the nodes of tree3:\n"; //Display nodes in tree3.
  tree3.displayInOrder();
  cout << endl;
  return 0;
}

//Copy Constructor, which takes a reference parameter to an object of the 
//class
//Calls the copyTree function
IntBinaryTree::IntBinaryTree(const IntBinaryTree &tree)
{
  root = nullptr;
  copyTree(tree.root);
}

//Assignment Operator
//Hint: destroy all nodes in the old tree then use the copyTree function
IntBinaryTree IntBinaryTree::operator= (const IntBinaryTree &tree)
{
  if(this != &tree) //if the pointer to the calling ojbect is not the same 
                    //as the reference of the source object
    {
      destroySubTree(root);//
      root = nullptr; //root points to nullptr, so there is no memory leak,
                      // since the roots in the sub tree are destroyed
      copyTree(tree.root); //sends in the root of the source object/tree 
                           //I'm trying to copy
    }
  return *this; //returns the actual content of the calling object
}

// copyTree Function: called by copy constructor and
// Assignment operator function. This function copies all tree nodes
// by visiting the root nodes first (pre-order traversal)
IntBinaryTree::TreeNode *IntBinaryTree::copyTree(TreeNode *nodePtr)
{
  if(nodePtr != nullptr) // if the node pointer is NOT pointing to anything
    {
      insertNode(nodePtr->value); //
      copyTree(nodePtr->left); //
      copyTree(nodePtr->right); //
    }
  return nodePtr; //to return to the top of the fuction
}

//***********************************************************
// insert accepts a TreeNode pointer and a pointer to a node.
// The function inserts the node into the tree pointed to by
// the TreeNode pointer. This function is called recursively.
void IntBinaryTree::insert(TreeNode *&nodePtr, TreeNode *&newNode)
{
  if(nodePtr == nullptr)
    nodePtr = newNode; //Insert the node.
  else if(newNode->value < nodePtr->value)
    insert(nodePtr->left, newNode); //Search the left branch
  else
    insert(nodePtr->right, newNode);//Search the right branch
}

//**********************************************************
// insertNode creates a new node to hold num as its value,
// and passes it to the insert function.
void IntBinaryTree::insertNode(int num)
{
  TreeNode *newNode = nullptr; //Pointer to a new node.

  //Create a new node and store num in it.
  newNode = new TreeNode;
  newNode->value = num;
  newNode->left = newNode->right = nullptr;

  insert(root, newNode); //Insert the node.
}

//***************************************************
//destroySubTree is called by the destructor.
//it deletes all nodes in the tree.
void IntBinaryTree::destroySubTree(TreeNode *nodePtr)
{
  if(nodePtr)
    {
      if(nodePtr->left)
	destroySubTree(nodePtr->left);
      if (nodePtr->right)
	destroySubTree(nodePtr->right);
      else
	delete nodePtr;
    }
}

//***************************************************
// searchNode determines if a value is present in
// the tree. If so, the function returns true.
// Otherwise, it returns false.
bool IntBinaryTree::searchNode(int num)
{
  bool status = false;
  TreeNode *nodePtr = root;
  while(nodePtr) //while nodePtr points to a node
    {
      //(*nodePtr).value is the same as nodePtr->value
      if(nodePtr->value == num) //if the nodePtr's value is equivalent to num
	status = true; 
      else if(num < nodePtr->value) //else if num is less than nodePtr's value 
	nodePtr = nodePtr->left; //nodePtr is assigned nodePtr's left value
      else
	nodePtr = nodePtr->right; //nodePtr is assigned nodePtr's right value
    }
  return status; //return false
}

//**********************************************
// remove calls deleteNode to delete the
// node whose value member is the same as num.
void IntBinaryTree::remove(int num)
{
  deleteNode(num, root);
}
//********************************************
// deleteNode deletes the node whose value
// member is the same as num.
void IntBinaryTree::deleteNode(int num, TreeNode *&nodePtr)
{
  if(num < nodePtr->value) 
    deleteNode(num, nodePtr->left);
  else if(num > nodePtr->value)
    deleteNode(num, nodePtr->right);
  else
    makeDeletion(nodePtr);
}

//***********************************************************
// makeDeletion takes a reference to a pointer to the node
// that is to be deleted. The node is removed and the
// branches of the tree below the node are reattached.
void IntBinaryTree::makeDeletion(TreeNode *&nodePtr)
{
  //Define a temporary pointer to use in reattaching the left subtree.
  TreeNode *tempNodePtr = nullptr; //tempNodePtr points to nullptr
  if(nodePtr == nullptr) //if tree is empty, basically, if nodePtr points 
                         //to nothing
    cout << "Cannot delete empty node.\n";
  else if (nodePtr->right == nullptr)
    {
      tempNodePtr = nodePtr;
      nodePtr = nodePtr->left; // Reattach the left child
      delete tempNodePtr;
    }
  else if (nodePtr->left == nullptr)
    {
      tempNodePtr = nodePtr;
      nodePtr = nodePtr->right; // Reattach the right child
      delete tempNodePtr;
    }
  else // If the node has two children.
    {
      tempNodePtr = nodePtr->right; //Move one node the right.
      
      while(tempNodePtr->left) //Go to the end left node.
	  tempNodePtr = tempNodePtr->left;
      
      tempNodePtr->left = nodePtr->left; // Reattach the left subtree.
      tempNodePtr = nodePtr; //tempNodePtr and nodePtr point to same spot
      
      nodePtr = nodePtr->right; // Reattach the right subtree.
      delete tempNodePtr;
    }
}

//****************************************************************
// The displayInOrder member function displays the values
// in the subtree pointed to by nodePtr, via inorder traversal.
void IntBinaryTree::displayInOrder(TreeNode *nodePtr) const
{
  if(nodePtr = nullptr) //if nodePtr points to nullptr
    return; //return to main
  else
    {
      displayInOrder(nodePtr->left); 
      cout << nodePtr->value << " ";
      displayInOrder(nodePtr->right);
    }
}

//********************************************************
// numNodes Function: calls countLeafNodes and returns the number
// of leaf nodes in the tree
int IntBinaryTree::numLeafNodes()
{
  return countLeafNodes(root);
}

//****************************************************************
// The countLeafNodes function uses recursion to count the number
// of leaf nodes in the tree. This function is called by the public
// member function numLeafNodes. It visits all the root nodes first
// (pre-order traversal)
int IntBinaryTree::countLeafNodes(TreeNode *&nodePtr)
{
  if(nodePtr = nullptr) //if nodePtr points to nullptr
    return 0; //return 0 means the if statement is false
  else 
    {
      //if nodePtr's left and right values are equivalent to nullptr
      if(nodePtr->left == nullptr && nodePtr->right == nullptr)
	return 1; //return 1 means the if statement is true 
      else 
	return countLeafNodes(nodePtr->left) + countLeafNodes(nodePtr->right);
    } 
}

//*************************************************************
// Function TreeHeight
// Calls getTreeHeight and displays the height or depth of tree.
int IntBinaryTree::treeHeight()
{
  return getTreeHeight(root);
}

//*************************************************************
// Function getTreeHeight
// This function uses recursion to count the height of
// the tree.
int IntBinaryTree::getTreeHeight(TreeNode* nodePtr)
{
  if(!nodePtr) //if nodePtr points to nullptr
    return 0;
  else
    {
      int treeLeft = getTreeHeight(nodePtr->left);
      int treeRight = getTreeHeight(nodePtr->right);
      
      if(treeLeft > treeRight)
	return (treeLeft + 1);
      else
	return (treeRight + 1);
    }    
}
