/**
3/8/19
 **/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  int x = 7;
  int y = 3;
  
  double z = ((double)x/y); //only type-cast one of the values that I want to convert from an int to a double

  cout << endl << "7/3" << " = " << fixed << setprecision(2) << z << endl;

  return 0;
}
