/******************************
Justin Bush
CS 211 
Lab 8 Program 2
Write a recursive function multiply that takes two integers x and y. The function should return
the value of x times y.
You may test your function by entering two integers:
- 4 and 7 
- 1 and 5
- 0 and 2
- 8 and 0
***********************************/
#include<iostream>
using namespace std;

int multiply(int a, int b);

int main()
{
  int x, y;

  cout << "Enter two numbers: " << endl;
  cout << "First number:" << " ";
  cin >> x;
  cout << "Second number:" << " ";
  cin >> y;

  cout << "x * y = " << multiply(x,y) << endl;

  return 0;
}

int multiply(int a, int b)
{
  if(a!=0 && b!=0)
    {
      return multiply(a-1,b)+b;
    }
  else 
	{
          return 0;
	}
}
