/*****************************************
Justin Bush
****************************************/
#ifndef STUDENT_H
#define STUDENT_H
#include<iostream>

using namespace std;

class Student
{
private:
  string name;
  const long studentID;
  string major; //CS, MATH, PHYS, etc
  string classification; //graduate or undergraduate
  int units; //total units enrolled
  float tuition;
  static int totalNumofStudents;
  static int nextStudentID;
 
public:
  Student(); //default constructor
  Student(string theName, string theMajor, string theClassification, int theUnits);
  ~Student(); //deconstructor
  void print() const;
  void setData();
};

#endif
