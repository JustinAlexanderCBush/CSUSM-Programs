#include <iostream>
#include <iomanip> 
using namespace std;

int main()
{
  for(int i = 3; i <= 12; i = i + 2)
    {
      for(int j = 0; j < 5; j++)
	{
	  cout << setw(3) << i * j;
	}
      cout << endl;
    }

  return 0;
}
