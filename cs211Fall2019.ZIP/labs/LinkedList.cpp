#include<iostream>
#include"LinkedList.h"
#include"Node.h"
using namespace std;

LinkedList::LinkedList() //default constructor sets head to nullptr
{
  head = nullptr; 
}

/***
This function creates a node, sets its data to the values sent as arguments, and inserts the new node at the beginning of the linked list (before the first node)
***/
void LinkedList::append(string pName, string phone)
{
  Node *newNode; //to point to a new node
  Node *nodePtr; //to move through the list

  //allocate a new node and store pName and phone there
  newNode = new Node; //newNode is pointing to the newly declared Node object
  newNode->name = pName; //setting newNode's name to pName.  *****Arrow means dereferencing
  newNode->phoneNumber = phone; //setting Newnode's phoneNumber variable to phone
  newNode->next = nullptr; //setting newNode's next variable to point to nullptr
 
  if(!head)
    head = newNode;
  else //otherwise, insert newNode at end
    {
      nodePtr = head; //  nodePtr points to head node
      while(nodePtr->next) //while nodePtr traverses the list   ****this while loop condition checks if there is a next node to point to
	{
	  nodePtr = nodePtr->next; //****THIS MAKES nodePtr MOVE to the next node
	}
      nodePtr->next = newNode; //insert newNode as last node
    }
}

void LinkedList::print() //this func traverses list printing data in each node
{
  Node *nodePtr; //to move through list
 
  nodePtr = head; //position nodePtr at head of list
  while(nodePtr) //while nodePtr points to a node, traverse the list
    {
      cout << nodePtr->name << " " << nodePtr->phoneNumber << endl; //display phone numbers in this node
      nodePtr = nodePtr->next; //move to next node
    }
}

/*****
This function creates a node, sets its data to the values sent as arguments, and inserts the new node at the beginning of the linked list (before the first node)
 *****/
void LinkedList::insertAtBegin(string pName, string phone)
{
  Node *newNode; //a new node

  newNode = new Node; //allocate a new node
  newNode->name = pName; //store pName in it
  newNode->phoneNumber = phone; //store phone in it

  newNode->next = head;
  head = newNode;
}

/****
This function searches for a particular person’s record, whose name is pName in the list and prints the person’s corresponding phone number if it exists. If that person does not exist, the function prints an error message
****/
void LinkedList::searchByName(string pName)
{
   Node *nodePtr; //to move through list
   bool flag = false;

   nodePtr = head; //position nodePtr at head of list
   while(nodePtr != NULL) //&& flag = false) //while nodePtr points to a node, traverse the list
     {
       if(nodePtr->name == pName)
	 {
	   cout << nodePtr->name << endl;
	   cout << nodePtr->phoneNumber << endl;//display phone number in this node
	   flag = true;
	 } 
       nodePtr = nodePtr->next; //increments to next node 
     } 
   
   if(flag == false)
    cout << "This person's phone number doesn't exist." << endl;   
}

/*
 Have the destructor call another private function, destroy, that does the deleting (you need to implement that function too)
 */
LinkedList::~LinkedList() 
{
  destroy();
}

void LinkedList::destroy()
{
  Node *nodePtr; //to traverse the list
  Node *nextNode; //to point to the next node

  nodePtr = head; //position nodePtr at head of list

  while(nodePtr != nullptr) //while nodePtr is not at ned of list
    {
      nextNode = nodePtr->next; //save a point to next node
      delete nodePtr; //delete current node
      nodePtr = nextNode; //position nodePtr at next node
    }
}

LinkedList::LinkedList(const LinkedList &source) //copy constructor performs a DEEP copy of list source
{
  Node *nodePtr = nullptr;
  head = nullptr;
  nodePtr = source.head;
  
  while(nodePtr)
    {
      append(nodePtr->name, nodePtr->phoneNumber);
      nodePtr = nodePtr->next;
    }
}

/*****
The overloaded operator == returns true if two lists are the same, false otherwise. In other words, if both lists have the same number of nodes and the same node values (in the same order)
 ****/
bool LinkedList::operator == (const LinkedList &L1) 
{
  Node *nodePtr = head;
  Node *nodePtr2 = L1.head;

  while(nodePtr != NULL && nodePtr2 != NULL)
    {
      if(nodePtr->name != nodePtr2->name)
	{
	  if(nodePtr->phoneNumber != nodePtr2->phoneNumber)
	    return false;
	}

      nodePtr = nodePtr->next;
      nodePtr2 = nodePtr2->next;
    }

  if(nodePtr || nodePtr2)
    return false;

  return true;
}

  
