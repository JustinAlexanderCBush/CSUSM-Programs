/*****************************************************************
Justin Bush
CS 111 Castillo 3/27/19
Modify Lab 19 so that instead of closing we ask the user if they want more trees after drawing their request, and if they enter “Y” or ‘y’ repeat the process (enter number and height, then draw). After drawing each “batch” of trees also tell the user how many trees have been drawn overall. Use a static variable in drawTrees to track this information.
Write a function called treeTop that prints the top of a tree. It should take no parameters and return void. Write a second function called treeTrunk that prints the trunk of a tree. It should take one integer as a parameter for height (how many lines tall the trunk is), and also have a return type of void. Finally, create a function called drawTrees that takes two integer parameters, one for height and one for number of trees to draw. drawTrees should use treeTop and treeTrunk.
Have the user enter the height of the trees (same for all) and number of trees to draw.  Remember that to draw a backslash you need two backslashes.
****************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

void treeTop();
void treeTrunk(int height); 
int drawTrees(int height, int number);

int main()
{
  int ht, num, totalTreesDrawn; //'h' refers to height and 'num' refers to the number
  char answer; //'num' refers to the number of trees the user wants to print

  do
    {
      cout << "Enter tree height: ";
      cin >> ht;    
      cout << "Enter number of trees: ";
      cin >> num;
     
      totalTreesDrawn = drawTrees(ht, num);

      cout << "Total number of trees drawn: " << totalTreesDrawn;
      cout << "\nDo you want to draw more trees?: ";
      cin >> answer;
      cout << endl;
    } while(answer == 'y' || answer == 'Y');
 
  return 0;
}

void treeTop()
{
  cout << setw(4) << "^" << endl;
  cout << setw(5) << "/ \\" << endl;
  cout << setw(6) << "/   \\" << endl;
  cout << setw(1) << "/_____\\" << endl;
}

void treeTrunk(int ht) //'ht' refers to the height of the tree
{
  for(int i = 0; i < ht; i++)
      cout << right << setw(5) << "| |" << endl;
}

int drawTrees(int height, int number) 
{
  static int total = 0; //when drawTrees is called, the variable 'total' does NOT reset to 0, but it stays incremented (see for-loop below)
  for(int i = 0; i < number; i++)
    {
      treeTop();
      treeTrunk(height);
      total++; 
      cout << endl;
    }
  return total;
}
