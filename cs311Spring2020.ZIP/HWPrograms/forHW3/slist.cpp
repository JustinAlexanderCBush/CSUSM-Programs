// CS311 Yoshii Complete all functions with their comments

// ====================================================
//HW#: HW3P1 slist  inheriting from llist
//Your name: Justin Bush
//Complier:  g++
//File type: slist.cpp implementation file
//=====================================================

using namespace std;
#include<iostream>
#include"slist.h" 

// ** Make sure llist constructor and destructors have couts in them
 

// do not change this one
//Purpose: Default constructor
//Parameters: none
slist::slist()
{ 
  cout << "slist constructor:" << endl;
}

// positions always start at 1
//Purpose: to search for a specific number (key)
//Parameters: the key, with typedef called el_t
int slist::search(el_t key)
{
  Node* P = Front;
  int position = 1;
  while(P != NULL)
    {
      if(P->Elem == key)
	return position;

      P = P->Next;
      position++;
    }
  return 0;
}

// don't forget to throw OutOfRange for bad pos
//Purpose: to replace an element of the list
//Parameters: the element to be replaced, and the position to replace it
void slist::replace(el_t element, int pos)
{
  if(pos < 1 || pos > Count)
    throw OutOfRange();
  
  else
    {
      Node* P = Front;
      moveTo(pos, P);
      P->Elem = element;
    }
}

//Purpose: to overload the == operator
//Parameters: the other list, than the one being compared to
bool slist::operator==(const slist& OtherOne)
{
  // if not the same length, return false
  // if the same lengths,
         //check each node to see if the elements are the same
  if(Count != OtherOne.Count)
    return false;
  
  else
    {
      Node* nodePtr = Front;
      Node* nodePtr2 = OtherOne.Front;
      while(nodePtr != NULL)
	{
	  if(nodePtr->Elem == nodePtr2->Elem)
	    {
	      nodePtr = nodePtr->Next;
	      nodePtr2 = nodePtr2->Next;
	    }
	  else
	    return false;
	}
      return true;
    }
}
