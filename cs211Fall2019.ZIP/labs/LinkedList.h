#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include"Node.h"
using namespace std;

class LinkedList
{
 private:
  Node *head; //head pointer points to beginning of linked list
  
 public:
  LinkedList(); //default constructor sets the head to nullptr
  void append(string pName, string phone);
  void print();
  void insertAtBegin(string pName, string phone);
  void searchByName(string pName);
  ~LinkedList(); //destructor deletes all nodes in the list and sets head back to nullptr
  void destroy(); //to be used with the destructor
  LinkedList(const LinkedList &source); //copy constructor performs a DEEP copy of list source
  bool operator == (const LinkedList &L1); //overloaded == operator
};
 
#endif
