/*************************
Justin Bush
10/9/2019
************************/
#ifndef RATIONALNUMBER_H
#define RATIONALNUMBER_H
using namespace std;

class RationalNumber
{
  //standalone friend func that overloads << operator and prints a rational num in form of numerator/denominator
  friend ostream& operator << (ostream& os, const RationalNumber& r);

  //standalone friend func that overloads >> operator and prompts the user for a rational num (numerator and denominator)
  friend istream& operator >> (istream& is, RationalNumber& r);

  //standalone friend func that overloads postfix increment operator(++) for RationalNumber class. 
  friend RationalNumber operator++(RationalNumber& r, int dummy);

 private:
  int numerator; 
  int denominator;

 public:
  RationalNumber(int n = 0, int d = 1); //default constructor

  //member func that overloads subtraction operator(-) for RationalNumber class. 
  RationalNumber operator-(const RationalNumber& r);

};

#endif
