#include <iostream>
using namespace std;

int main()
{
  string fullName, address, major;
  char gender;

  cout << "Enter your full name: "; //enter two spaces before and after full name
  getline(cin, fullName); //grabs entire full name, including the 4 extra spaces
  cout << "=>" << fullName << "<=" << endl;

  cout << "Enter your gender (m or f): ";
  cin >> gender; //enter two spaces after entering the gender
  cout << "=>" << gender << "<=" << endl;

  cin.ignore(2, '\n'); //ignores two spaces after the gender was entered if the user pressed space after entering their gender
  cout << "Enter your address: ";
  getline(cin, address); //grabs the entire full address
  cout << "=>" << address << "<=" << endl;

  cout << "Enter your major: ";
  getline(cin, major); //grabs the entire full address
  cout << "=>" << major << "<=" << endl;

  return 0;
}
