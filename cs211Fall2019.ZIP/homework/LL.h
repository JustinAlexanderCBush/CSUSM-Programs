#ifndef LL_H
#define LL_H
#include"Node.h" //Allows me to access the public Node class functions
using namespace std;

class LL
{ 
 private:
  Node *head; //head pointer points to beginning of linked list

 public:
  LL(); //default constructor
  void append(string pName, string phone);
  void readFromArrays(string nArr[], string pArr[], int size);
  void insert(string pName, string phone);
  void insertAtPos(string pName, string phone, int pos);
  void print();
  void printReverse();
  void searchByName(string pName);
  void updateNumber(string pName, string newPhone);
  void removeRecord(string pName);
  ~LL(); //destructor deletes all nodes in the list and sets head back to nullptr
  void destroy(); //to be used with the destructor
  LL(const LL &source); //copy constructor performs a copy of list named source
  LL& operator =(const LL &source);
  void reverse();
};

#endif
