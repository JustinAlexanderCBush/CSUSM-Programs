/************************************
Justin Bush 
CS 211 lab 8 program 3
Write a recursive function numChars that counts the number of times a specific character appears in a string. For example:
- the character ‘l’ appears 4 times in string “Hello Bello”
- the character ‘a’ appears 0 times in string “Hello Bello”
- the character ‘I’ appears once in string “I”…
You may test your function by counting the number of ‘l’, ‘a’, ‘h’ occurrences in the string “Hello Bello”.
***********************************/
#include<iostream>
#include<string>
using namespace std;

int numChars(char search, string str, int subscript);

int main()
{
  string s = "Hello Bello";
  
  cout << "The letter 'l' appears " << numChars('l', s, 0) << " times." << endl;
  cout << "The letter 'a' appears " << numChars('a', s, 0) << " times." << endl;
  cout << "The letter 'I' appears " << numChars('I', s, 0) << " times." << endl;

  return 0;
} 

int numChars(char search, string str, int subscript)
{
  //int counter = 0;
  if(subscript >= str.length())
    return 0; //base case: end of the string was reached
  else if(str[subscript] == search)
    return 1 + numChars(search, str, subscript + 1);
  else
    return numChars(search, str, subscript + 1);
}

