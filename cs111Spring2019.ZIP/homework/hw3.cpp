/******************************************************************************
Justin Bush 
CS 111 Castillo
4/19/19
Homework 3
Create four functions for addition, subtraction, multiplication, and division that each accept an array of doubles (remember that arrays are always passed by reference without needing an &) as well as an operand of type double passed by value.  Each function will perform its’ operation on each element of the array using the operand.
Example: Operation is addition, array contents are [2.5, 4.5, 6.5, 8.5, 10.5], operand is 7, the array would be changed to contain [9.5, 11.5, 13.5, 15.5, 17.5].
Hint: Remember that arrays are always passed by reference, so your return types for these functions should be void.
Create a fifth function that prints the contents of the array to the screen, one element per line.  This function should accept an array of doubles as its’ only argument.  The print function should not modify the contents of the array in any way – declare the parameter as const to ensure that this is the case (note that you could not do this with the four other functions since they need to modify the array).  The print function should also return void.
In main ask the user to enter the values to store in the array.  Print the array using your print function.  Have the user select an operation to perform on the array by typing +, - , * or /, then enter an operand.  Perform the given function on the array using the given operand and then print the array contents using your print function again.
Use a global int constant for the size of the array – set it to 5.  If the global constant is changed in the code your program should still work properly.
Make sure nothing in your code results in junk values or causes a segmentation fault.
******************************************************************************/
#include <iostream>
using namespace std;

void addition(double ar[], double op); //'op' refers to the operand
void subtraction(double ar[], double op);
void multiplication(double ar[], double op);
void division(double ar[], double op);
void printArray(const double ar[]); 
		
const int SIZE = 5; //global variable of five for the size of the double array

int main()
{
  char selection;
  double array[SIZE];
  double operand;

  cout << "Enter the values you want to store into the array." << endl;
  
  for(int i  = 0; i < SIZE; i++)
    cin >> array[i];
    
  cout << "\nThe array you entered: ";
  printArray(array); 

  cout << "\nEnter an operand (a number): ";
  cin >> operand;

  cout << "\nType either '+,' '-,' '*,' or '/' to perform it's corresponding operation. : ";
  cin >> selection;
  if(selection == '+')
    {
      addition(array, operand);
      printArray(array);
      cout << endl;
    }
  else if(selection == '-')
    {
      subtraction(array, operand);
      printArray(array);
      cout << endl;
    }
  else if(selection == '*')
    {
      multiplication(array, operand);
      printArray(array);
      cout << endl;
    }
  else //selection == '/'
    {
      division(array, operand);
      printArray(array);
      cout << endl;
    }

  return 0;
}

void addition(double ar[], double op)
{
  for(int i = 0; i < SIZE; i++)
    ar[i] += op;
}

void subtraction(double ar[], double op)
{
  for(int i = 0; i < SIZE; i++)
    ar[i] -= op;  
}

void multiplication(double ar[], double op)
{
  for(int i = 0; i < SIZE; i++)
    ar[i] *= op;
}

void division(double ar[], double op)
{
  for(int i = 0; i < SIZE; i++)
    ar[i] /= op; 
}

void printArray(const double ar[])
{
  for(int i = 0; i < SIZE; i++)
    cout << ar[i] << " ";
}

