//==========================================
// HW#: HW7 DFS client using dgraph.h
// Name: Justin Bush
// File type: client hw7client.cpp 
//Algorithm/Design: Update dgraph.h and dgraph.cpp files so that I can implement the DFS information for the graph   
//==========================================

// ** Be sure to include dgraph, slist and stack
#include<iostream>
#include"dgraph.h"
#include"stack.h"
using namespace std;

// This client uses the dgraph class and stack class
// to do depth first traversal of the graph stored in table.txt
int main()
{
  // ** copy here the algorithm (read carefully) in the HW7
  // assignment sheet and use that has the comments. 
  dgraph TableObj;
  stack adjacentStack;
  slist adjacentList;
  char vertexTemp;
  int traverse = 2;
  
  TableObj.fillTable();
  TableObj.displayGraph();

  TableObj.visit(1, 'A');

  cout << "\nDFS in progress ..." << endl;
  cout << "----------------------------" << endl << endl;
  
  cout << "vistited A" << endl;
  adjacentList = TableObj.findAdjacency('A');
  while(!adjacentList.isEmpty() )
    {
      adjacentList.deleteRear(vertexTemp);
      adjacentStack.push(vertexTemp);
    } //end of while loop

  adjacentStack.displayAll();
  cout << endl;

  while(!adjacentStack.isEmpty() )
    {
      cout << "Removing a vertex from the stack" << endl;
      adjacentStack.pop(vertexTemp);
      cout << "Vertex Name: " << vertexTemp << endl;
    
      //checking if temp has veen previously visited
      if(!TableObj.isMarked(vertexTemp) == 1)
	{
	  TableObj.visit(traverse, vertexTemp);
	  cout << "The vertex: " << vertexTemp << " has now been visisted." << endl;
	  adjacentList = TableObj.findAdjacency(vertexTemp);
	  
	  //from slist to stack
	  while(!adjacentList.isEmpty() )
	    {
	      adjacentList.deleteRear(vertexTemp);
	      cout << "Pushing " << vertexTemp << " (is adjacent) into stack" << endl;
	      adjacentStack.push(vertexTemp);
	    }
	  cout << "Stack is: " << endl;
	  adjacentStack.displayAll();
	  cout << endl;
	  traverse++;
	}
      else //else, if it has been already visited
	
	  cout << "Vertex " << vertexTemp << " has already been visited before" << endl;	
    } //end of while loop

  cout << "\n\nGraph after DFS: " << endl;
  cout << "---------------------" << endl << endl;

  //displaying resulting graph
  TableObj.displayGraph();


  return 0;

}
