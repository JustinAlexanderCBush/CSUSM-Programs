/***********
4/10/19
***********/
#include <iostream>

using namespace std;


class Rectangle //class definition
{
public: //access specifier that can be accessed by funcs OUTSIDE the class
  double calcArea(); //function that returns area of rectangle
  void setWidth(double passedWidth); //function that sets width of rect.
  void setLength(double passedLength); //function that sets length of rect.
  double getWidth(); //function that returns width of rect.
  double getLength(); //function that returns length of rect.

  Rectangle(); // default constructor (no parameters)

  //constructor with two parameters for length and width
  Rectangle(double passedWidth, double passedLength);

private: //access specifier that can only be called by or accessed by funcs that re memebers of the class
  double length; //variable to store length
  double width; //variable to store width
};

//functions of class Rectangle
//we need setter funcs(mutators: a member func that stores a value in a private member variable, or changes its value in some way) and getter funcs because length and width are private
double Rectangle::getWidth()
{
  return width;
}

double Rectangle::getLength()
{
  return length;
}


void Rectangle::setWidth(double passedWidth)
{
  if(passedWidth >= 0) //input validation prevents negative width
    {
      width = passedWidth;
    }
  else
    {
      cout << "invalid!  Width cannot be negative" << endl;
    }
}

void Rectangle::setLength(double passedLength)
{
  if(passedLength >= 0) //input validation prevents negative length
    {
      length = passedLength;
    }
  else
    {
      cout << "invalid!  Length cannot be negative" << endl;
    }
}


double Rectangle::calcArea()
{
  return length * width;
}
//Default constructor for Rectangle (constructor that takes no parameters)
Rectangle::Rectangle()
{
  //no parameters so use reasonable default values.
  length = 0;
  width = 0;
}

//Constructor for Rectangle that accepts two parameters for length and width
Rectangle::Rectangle(double passedLength, double passedWidth)
{
  //don't do this!  no input validation this way!
  //length = passedLength;
  //width = passedWidth;

  //default values in case passed input is invalid
  length = 0;
  width = 0;

  //This allows us to use the input validation we already wrote in our setters
  setLength(passedLength);
  setWidth(passedWidth);
}


int main()
{
  Rectangle r1; //calls default constructor of Rectangle
  //default constructor sets length and width to 0
  
  //illegal!  length and width are private.
  // cout << "R1's length is " << r1.length << endl;
  // cout << "R1's width is " << r1.width << endl;

  cout << "R1's length is " << r1.getLength() << endl;
  cout << "R1's width is " << r1.getWidth() << endl;
  cout << "R1's area is " << r1.calcArea() << endl;
  cout << endl;

  // r1.length = 5; //illegal! length is private
  // r1.width = -3; //illegal! width is private

  //set dimensions of rectangle
  r1.setWidth(7);
  r1.setLength(5);
  

  cout << "R1's length is " << r1.getLength() << endl;
  cout << "R1's width is " << r1.getWidth() << endl;
  cout << "R1's area is " << r1.calcArea() << endl;
  cout << endl;

  //r2 is a separate rectangle object from r1
  Rectangle r2(3.2,5.1); //calls Rectangle constructor with 2 parameters.
  //sets width to 3.2 and length to 5.1 - be sure to give parameters in 
  //the correct order!


  cout << "R2's length is " << r2.getLength() << endl;
  cout << "R2's width is " << r2.getWidth() << endl;
  cout << "R2's area is " << r2.calcArea() << endl;
  cout << endl;

  return 0;
}
