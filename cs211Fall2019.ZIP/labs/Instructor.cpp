/********************************
Justin Bush
********************************/
#include<iostream>
#include "Instructor.h"
#include "Course.h" //so I can access the Course class member variables/funcs
using namespace std;

Instructor::Instructor() //default constructor
{
  firstName = "";
  lastName = "";
  gender = 'M', 'F';
  employeeID = 00000;
  officeNum = "";
  studentCourses[3];
}

Instructor::Instructor(string fName, string lName, char gen, long empID, string offNum, Course courses[])
{
  setInstructor(fName, lName, gen, empID, offNum, courses);       
}

void Instructor::setInstructor(string fName, string lName, char gen, long empID, string offNum, Course courses[])
{ 
  firstName = fName;
  lastName = lName;
  gender = gen;
  employeeID = empID;
  officeNum = offNum;
  
  studentCourses[0] = courses[0];
  studentCourses[1] = courses[1];
  studentCourses[2] = courses[2];
}

void Instructor::printInstructor()
{
  cout << firstName << " " << lastName << " " << gender << " " << employeeID << " " << officeNum << " " << endl;
  for(int i = 0; i < 3; i++)
    { 
      cout << studentCourses[i].courseNumber << studentCourses[i].courseName << studentCourses[i].numberOfCredits << endl;
    }
}
