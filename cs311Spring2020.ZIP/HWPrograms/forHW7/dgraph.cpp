//CS311 Yoshii dgraph.cpp 
// INSTRUCTION:
//  Complete all the functions you listed in dgraph.h
//  Comment the file completely using How to Comment file.
//  Use HW6-help.docx to finish the functions.
//-------------------------------------------------------

//======================================================
// HW#: HW6 dgraph
// Name: Justin Bush
// File Type: implementation dgraph.cpp
//========================================================

using namespace std;
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include "dgraph.h"

//Purpose: constructor
//Parameters: None
dgraph::dgraph() 
{
  // initialize vertexName (blank) and visit numbers (0)    
  // initialize countUsed to be 0
  for(int i = 0; i < SIZE; i++)
    {
      Gtable[i].vertexName = ' ';
      Gtable[i].visit = 0;
    }
  countUsed = 0;
}

//Purpose: destructor
//Parameters: None
dgraph::~dgraph()   // do we have to delete all nodes of slists in table??
// Question: If we do not do this, will the llist destructor be called automatically??? Try it.
{
  //nothing is needed here
}

//Purpose: To read information from file and adds the data to the graph
//Parameters: None
void dgraph::fillTable()  // be sure to read from a specified file
{
  string fname;
  cout << "Enter a file name: ";
  cin >> fname;
  char x; 
  ifstream fin (fname.c_str(), ios::in); // declare and open fname
  while(fin >> Gtable[countUsed].vertexName)
    {
      fin >> Gtable[countUsed].outDegree;
      //to read and fill out the output of the out dgree portion of thee table
      for(int i = 0; i < Gtable[countUsed].outDegree; i++)
	{
	  fin >> x;
	  (Gtable[countUsed].adjacentOnes).addRear(x);
	}
      countUsed++;
    }
  fin.close();

}

//Purpose: To display the graph with the information read from table.txt
//Parameters: None
void dgraph::displayGraph() // be sure to display
{// in a really nice table format -- all columns but no unused rows 
  cout << "\n" << left << "Vertex\tOut\t\t Visit\t Adj\n";
  cout << "---------------------------------------------" << endl;
  for(int i = 0; i < countUsed; i++)
    {
      cout << Gtable[i].vertexName << "\t";
      cout << Gtable[i].outDegree << "\t\t";
      cout << Gtable[i].visit << "\t";
      (Gtable[i].adjacentOnes).displayAll();
    }
}

//Purpose: Returns the out degree of the vertex
//Parameters: The name (letter) of the vertex that the user enters
int dgraph::findOutDegree(char V)// throws exception
{
  for(int i = 0; i < countUsed; i++)
    {
      if(Gtable[i].vertexName == V)
	return (Gtable[i].outDegree);
    }
  throw BadVertex();
  
}

//Purpose: Returns the linked list of the adjacent vertices of the vertex
//Parameters: The name (letter) of the vertex that the user enters
slist dgraph::findAdjacency(char V)// throws exception
{
  for(int i = 0; i < countUsed; i++)
    {
      if(Gtable[i].vertexName == V)
	return Gtable[i].adjacentOnes;
    }
  
  throw BadVertex();
}


//Purpose: Enters the given visit number for a given vertex. This will indicate
     //the order in which verteces were visited 
//Parameters: The given visit number and the given vertex
void dgraph::visit(int visitNum, char V)
{
  int givenLocation = int(V) - 65;
  Gtable[givenLocation].visit = visitNum;
}


//Purpose: Returns true if a given vertex was already visited. 0 means NOT 
     //visited, so return false
//Parameters: The given vertex
bool dgraph::isMarked(char V)
{
  int checkLocation = int(V) - 65;
  if(Gtable[checkLocation].visit == 0)
    return 0;
  else
    return 1;
}
