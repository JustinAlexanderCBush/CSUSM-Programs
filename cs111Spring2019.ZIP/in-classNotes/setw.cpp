//for 3/8/19
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  char A, B, C, D, E; 

  cout << "A" << 


  for(int i = 1; i <= 5; i++)
    {
      for(int j = 
    }

  return 0;
}
