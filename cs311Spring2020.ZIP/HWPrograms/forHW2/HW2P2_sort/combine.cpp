#include <iostream>
#include <vector>
using namespace std;
//--------------------------------------------
//CS311 HW2P2 Combine 
//Name: Justin Bush
//Compiler: g++ -std=c++11
//--------------------------------------------

//combine two sorted lists A and B into R
//displays comparison every time it is done
void combine(vector<int> A, vector<int> B, vector<int> &R);

int main()
{  
  vector<int> L1; //declared vector of type int, named L1
  vector<int> L2; //declared vector of type int, named L2
  vector<int> L3; //declared vector of type int, named L3
  int N;  //how many elements in each of L1 and L2.
  int e;  //for each element
  
  cout << "How many elements in each list?" << endl;
  cin >> N;
  
  cout << "List1"  << endl;
  for(int i = 1; i <=N; i++)
    { 
      cout << "element :"; 
      cin >> e; 
      L1.push_back(e); //push_back member func add the element e to a full vector
    } 
  
  cout << "List2"  << endl; 
  
  for(int i = 1; i <=N; i++)
    { 
      cout << "element :"; 
      cin >> e; 
      L2.push_back(e);
    } 
  

  // call combine here to combine L1 and L2 into L3
  combine(L1, L2, L3);
  
    cout << "The result is: ";
  
  for(int i = 0; i < N*2; i++)
    cout << L3[i]; 
  
  cout << endl;

}// end of main

void combine(vector<int> A, vector<int> B, vector<int> &R)
{
  int a = 0;
  int b = 0;
  int r = 0;
  int i = ( A.size() + B.size() )/2;

  R.resize( A.size() + B.size() );

  do
    {
  cout << "comparison" << endl;
  // be careful -- R comes in as an empty vector with no slots
  if( (A[a] < B[b]) && (a <= i-1) )
    {
      R[r] = A[a];
      a += 1; //or, a = a + 1
    }
  else if( (B[b] < A[a]) && (b <= i-1) )
    {
      R[r] = B[b];
      b += 1; //or, b = b + 1 
    }
  else
    {
      if(B[b] > R[r-1])
	{
	  R[r] = B[b];
	  b += 1; //or, b = b + 1
	}
      else if(A[a] > R[r-1])
	{
	  R[r] = A[a];
	  a += 1; //or, a = a + 1
	}
    }
  
  r++;
  
    }while(r < R.size() );
}
