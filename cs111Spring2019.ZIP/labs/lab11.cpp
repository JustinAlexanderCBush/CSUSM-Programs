/************************************************************************
Justin Bush
CS 111
Castillo 
2/22/19
Create an array of 1000 double datatype elements, store 7.5 times the array slot number as the value in each array slot.
After creating and filling the entire array, ask the user to enter an integer between 0 and 999 – print the value of that element of the array (if the user entered 121 you would print the contents of array slot 121 which would be 907.5).
Input validation: Do not check out of range values! (i.e. do NOT do anything that may cause a segmentation fault)  Instead inform the user that the value is out of range. You must use a named constant for the array size of 1000.
************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  const int SIZE = 1000; //array of size 1000
  double ar[SIZE];
  int num; //used for the array slot value
  
  for(int i = 0; i < SIZE; i++) 
    ar[i]= 7.5 * i;
  
  cout << "Enter an array slot number: ";
  cin >> num;

  if(num >= 0 && num <= 1000)
    cout << "The value in array slot " << num << " is " << ar[num] << endl;
  else //the integer is not within the range of the array
    cout << "Value out of range." << endl;

  return 0;
}
