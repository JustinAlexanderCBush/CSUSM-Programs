/*******************************************************
Justin Bush 
9/6/19
Castillo
*******************************************************/
#include<vector>
#include<iostream>
#include<fstream>
//#include<algorithm>
using namespace std;

void readData(int A[], int B[], int C[]);
void printArray(int A[]);
void reverseArray(int A[]);
int longestSequence(int A[]);

const int SIZE = 10; //global variable; this can be used in functions as well, and int SIZE = 10 will be in scope for said functions

int main()
{
  int a[SIZE], b[SIZE], c[SIZE];
  int d, e, f; //for calling funcs with pass by value

  readData(a, b, c);

  cout << "Array A: "; 
  printArray(a);
  cout << "Reverse array A: ";
  reverseArray(a);
  printArray(a);
  cout << endl;


  cout << "Array B: ";
  printArray(b);
  e = longestSequence(b);
  cout << "Reverse array B: ";
  reverseArray(b);
  printArray(b);
  //  cout << "The longest sequence in Array B is: " << e << endl;
  cout << endl;

  cout << "Array C: ";
  printArray(c);
  f = longestSequence(c);
  cout << "Reverse array C: ";
  reverseArray(c);
  printArray(c);
  // cout << "The longest sequence in Array C is: " << f << endl;
  cout << endl;

 
  d = longestSequence(a);
  cout << "The longest sequence in Array A is: " << d << endl;


  //e = longestSequence(b);
  cout << "The longest sequence in Array B is: " << e << endl;
 
  //f = longestSequence(c);
  cout << "The longest sequence in Array C is: " << f << endl;

  return 0;
}

void readData(int A[], int B[], int C[])
{
  ifstream fin;
  fin.open("arrays.txt");
  
  if(!fin)
    cout << "This file does not exist" << endl;
  else //the input file exists
    {
      for(int i = 0; i < SIZE; i++)
	fin >> A[i];
      for(int i = 0; i < SIZE; i++)
	fin >> B[i];
      for(int i = 0; i < SIZE; i++)
	fin >> C[i];
    }
  
  fin.close();
}

void printArray(int A[])
{
  for(int i = 0; i < SIZE; i++)
      cout << A[i] << " ";

  cout << endl; //separates each of the A, B and C arrays
 }

void reverseArray(int A[])
{
  int temp = 0;
  int j = (SIZE - 1); //j is the index value for reversing the array

  for(int i = 0; i < SIZE/2; i++)
    {
      temp = A[i];
      A[i] = A[j];
      A[j] = temp;
      j--;
    }

}

int longestSequence(int A[])
{
  int longestSeq = 0;
  int counter = 1;
  for(int i = 0; i < SIZE; i++)
    {
      if(counter > longestSeq) //keeps track of the highest sequence that's been counted for  
	longestSeq = counter;
      if(A[i]+1 == A[i+1])
	{
	  // cout << "A[i] + 1 is :" << A[i] + 1 << "and A[i+1] is " << A[i+1] << endl;
	  //cout <<"counter is: " << counter;
	  counter++;
	  
	}
      else if(A[i] == A[i+1]);
      else
	counter = 1; //keeps track of the CURRENT sequence
      
    }
  return longestSeq;
}

